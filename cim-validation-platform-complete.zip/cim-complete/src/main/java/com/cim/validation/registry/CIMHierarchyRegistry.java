package com.cim.validation.registry;

import com.cim.model.mongo.CimClassDefinition;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class CIMHierarchyRegistry {

    private final Map<String, CimClassDefinition> registry = new ConcurrentHashMap<>();

    public void load(List<CimClassDefinition> definitions) {
        registry.clear();
        definitions.forEach(d -> registry.put(d.getClassName(), d));
    }

    public boolean isLoaded()                       { return !registry.isEmpty(); }
    public int size()                               { return registry.size(); }
    public boolean isKnownClass(String className)   { return className != null && registry.containsKey(className); }
    public CimClassDefinition getDefinition(String className) { return registry.get(className); }

    public List<String> getFullChain(String className) {
        List<String> chain = new ArrayList<>();
        chain.add(className);
        CimClassDefinition def = registry.get(className);
        if (def != null) chain.addAll(def.getAncestors());
        return chain;
    }

    public boolean isInChain(String objectType, String declaringClass) {
        if (objectType == null || declaringClass == null) return false;
        if (objectType.equals(declaringClass)) return true;
        CimClassDefinition def = registry.get(objectType);
        return def != null && def.getAncestors().contains(declaringClass);
    }

    public PathValidationResult validateAttributePath(String objectType,
                                                       String attributeTag) {
        if (objectType == null || attributeTag == null)
            return PathValidationResult.unknownType(objectType, attributeTag);

        if (!registry.containsKey(objectType))
            return PathValidationResult.unknownType(objectType, attributeTag);

        int dot = attributeTag.lastIndexOf('.');
        if (dot < 0) return PathValidationResult.vendorExtension(objectType, attributeTag);

        String declaringClass = attributeTag.substring(0, dot);
        String attrName       = attributeTag.substring(dot + 1);

        // Check if namespace is vendor extension
        if (declaringClass.contains(":") || declaringClass.contains("/"))
            return PathValidationResult.vendorExtension(objectType, attributeTag);

        if (isInChain(objectType, declaringClass))
            return PathValidationResult.valid(objectType, attributeTag, declaringClass);

        return PathValidationResult.invalid(objectType, attributeTag, declaringClass);
    }
}
