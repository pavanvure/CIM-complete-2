# CIM Validation Platform

End-to-end Spring Boot application for parsing, storing, and validating
IEC 61970/61968 Common Information Model (CIM17) power system data files.

---

## End-to-End Flow

```
Client uploads file
       │
       ▼
┌─────────────────────────────────────────────────────────────────┐
│  FORMAT DETECTION (AdapterRegistry)                             │
│  Checks file content + extension                                │
│  → RDF/XML  (.rdf, .xml)      IEC standard CIM serialization    │
│  → JSON-LD  (.json)           Modern CIM / GridAPPS-D           │
│  → Milsoft CSV (.csv, .txt)   WindMil export (2 layouts)        │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  PARSING  (Format Adapter)                                      │
│  Converts native format → List<CIMObject>  (COMMON MODEL)       │
│  • All objects have same structure regardless of source format  │
│  • Cross-references resolved within file                        │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  MONGODB STORAGE  (cim_objects collection)                      │
│  Every parsed CIMObject saved as CimObjectRecord                │
│  • category: PHYSICAL or LOGICAL                                │
│  • attributes map + references map                              │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  VALIDATION PIPELINE  (4 stages)                                │
│                                                                 │
│  Stage 1 — Physical Filter                                      │
│    Split objects: PHYSICAL (real equipment) vs LOGICAL (model)  │
│    ACLineSegment, Breaker → PHYSICAL                            │
│    Terminal, ConnectivityNode → LOGICAL (skip business rules)   │
│                                                                 │
│  Stage 2 — Attribute Path Validation                            │
│    For each tag "DeclaringClass.attribute":                     │
│    Is DeclaringClass in the inheritance chain of object's type? │
│    "ConductingEquipment.BaseVoltage" on ACLineSegment → VALID   │
│    "ConductingEquipment.BaseVoltage" on BaseVoltage → INVALID   │
│    Loads chain from MongoDB cim_standard at runtime             │
│                                                                 │
│  Stage 3 — Reference Resolution                                 │
│    Does rdf:resource target exist in this file?                 │
│    Is the target's CIM type compatible with the reference?      │
│                                                                 │
│  Stage 4 — Business Rules  (PHYSICAL objects only)             │
│    ACLineSegment: BaseVoltage required, Container required,     │
│                   Conductor.length required, impedance check    │
│    BaseVoltage:   nominalVoltage required > 0                   │
│    Switch family: BaseVoltage recommended                       │
│    EnergyConsumer: BaseVoltage required                         │
│    SynchronousMachine: BaseVoltage + GeneratingUnit required    │
│                                                                 │
│  Stage 5 — Cross-Object Consistency                             │
│    mRID uniqueness across all objects                           │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  MONGODB STORAGE  (validation_findings + validation_jobs)       │
│  Every finding saved with severity, stage, object, message      │
└─────────────────────────────────────────────────────────────────┘
```

---

## MongoDB Collections

| Collection           | Purpose                              |
|----------------------|--------------------------------------|
| `cim_standard`       | CIM17 class hierarchy (Admin loads)  |
| `validation_jobs`    | One doc per uploaded file            |
| `cim_objects`        | All parsed CIM objects (common data) |
| `validation_findings`| All findings (errors/warnings/info)  |

---

## REST API

### Upload & Validate
```
POST /api/validate              Upload + validate (sync)
POST /api/validate/async        Upload + validate (async, large files)
```

### Query Results
```
GET  /api/jobs                              Recent jobs
GET  /api/jobs/{jobId}                      Job status
GET  /api/jobs/{jobId}/objects              All parsed CIM objects
GET  /api/jobs/{jobId}/objects?type=ACLineSegment
GET  /api/jobs/{jobId}/objects?category=PHYSICAL
GET  /api/jobs/{jobId}/objects?name=CALCME
GET  /api/jobs/{jobId}/objects/stats        Type breakdown
GET  /api/jobs/{jobId}/findings             All findings
GET  /api/jobs/{jobId}/findings?severity=ERROR
GET  /api/jobs/{jobId}/findings?stage=BUSINESS_RULE
GET  /api/jobs/{jobId}/findings/summary     Error/warning counts
```

### Admin — CIM Standard
```
POST /api/admin/cim/reload?version=CIM17    Reload hierarchy
GET  /api/admin/cim/classes                 List all CIM classes
GET  /api/admin/cim/classes/{name}          Get class + ancestors
GET  /api/admin/cim/chain/ACLineSegment     Inheritance chain
POST /api/admin/cim/validate-path           Interactive path check
GET  /api/admin/cim/stats                   Registry stats
```

---

## Quick Start

### Prerequisites
- Java 17+
- MongoDB 6.x running on localhost:27017
- Maven 3.8+

### Run
```bash
# Start MongoDB
mongod --dbpath /data/db

# Build and run
./mvnw spring-boot:run
```

### Test with sample files
```bash
# RDF/XML
curl -X POST http://localhost:8080/api/validate \
     -F "file=@src/test/resources/samples/sample_rdf.xml" \
     -H "X-User: admin"

# JSON-LD
curl -X POST http://localhost:8080/api/validate \
     -F "file=@src/test/resources/samples/sample_jsonld.json" \
     -H "X-User: admin"

# Milsoft CSV
curl -X POST http://localhost:8080/api/validate \
     -F "file=@src/test/resources/samples/sample_milsoft.csv" \
     -H "X-User: admin"

# Check inheritance chain
curl http://localhost:8080/api/admin/cim/chain/ACLineSegment

# Validate a path interactively
curl -X POST http://localhost:8080/api/admin/cim/validate-path \
     -H "Content-Type: application/json" \
     -d '{"objectType":"ACLineSegment","attributeTag":"ConductingEquipment.BaseVoltage"}'
```

---

## Project Structure

```
src/main/java/com/cim/
├── CIMPlatformApplication.java          Main class
├── adapter/
│   ├── CIMFormatAdapter.java            Adapter interface
│   ├── RdfXmlAdapter.java               IEC RDF/XML parser
│   ├── JsonLdAdapter.java               JSON-LD parser
│   ├── MilsoftCsvAdapter.java           Milsoft WindMil CSV parser
│   └── AdapterRegistry.java             Auto-detects format
├── model/
│   ├── cim/CIMObject.java               COMMON MODEL (format-agnostic)
│   └── mongo/MongoDocuments.java        MongoDB document types
├── pipeline/
│   ├── result/PipelineFinding.java      One validation finding
│   └── stage/ValidationPipeline.java   All 5 pipeline stages
├── validation/
│   ├── registry/CIMHierarchyRegistry.java   Inheritance chain lookup
│   ├── registry/PathValidationResult.java   VALID/INVALID/VENDOR/UNKNOWN
│   └── rules/BusinessRuleEngine.java        Pluggable per-class rules
├── service/
│   ├── CIMStandardService.java          Seeds MongoDB on startup
│   ├── ValidationService.java           End-to-end orchestrator
│   ├── ValidationSummary.java           Response DTO
│   └── QueryService.java                MongoDB query methods
├── repository/
│   ├── CimClassRepository.java
│   └── ValidationRepositories.java
├── controller/
│   ├── ValidationController.java        Upload + query endpoints
│   └── AdminController.java             CIM standard management
└── config/GlobalExceptionHandler.java
```

---

## Add a New Format

1. Create a class implementing `CIMFormatAdapter`
2. Add `@Component`
3. Implement `supports()`, `parse()`, `getFormatName()`
4. Done — `AdapterRegistry` auto-discovers it via Spring DI

## Add a New Business Rule

1. Create a class implementing `ClassRule` (inner interface in BusinessRuleEngine)
2. Add `@Component`
3. Implement `appliesTo(String cimType)` and `validate(CIMObject, String jobId)`
4. Done — `BusinessRuleEngine` auto-discovers it

---

## Standards
- IEC 61970-301 CIM Base (Equipment Package)
- IEC 61968-11 CIM Extensions for Distribution
- PNNL-34946 CIM17v40 Developer's Guide
