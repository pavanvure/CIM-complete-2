package com.cim.model.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.*;

// ═══════════════════════════════════════════════════════════════════
// CimClassDefinition — CIM class hierarchy loaded from OWL
// ═══════════════════════════════════════════════════════════════════
@Document(collection = "cim_standard_owl")
public class CimClassDefinition {
    @Id private String id;
    @Indexed(unique = true)
    private String       className;
    private String       parentClass;
    private List<String> ancestors    = new ArrayList<>();
    private List<String> ownAttributes= new ArrayList<>();
    private String       category;      // PHYSICAL or LOGICAL
    private boolean      required;      // true=PHYSICAL, false=LOGICAL
    private String       cimPackage;
    private String       cimVersion;
    private String       description;
    private Instant      loadedAt;

    public CimClassDefinition() {}

    public CimClassDefinition(String className, String parentClass,
                               List<String> ancestors, List<String> ownAttributes,
                               String category, String cimVersion) {
        this.className     = className;
        this.parentClass   = parentClass;
        this.ancestors     = ancestors != null ? ancestors : new ArrayList<>();
        this.ownAttributes = ownAttributes != null ? ownAttributes : new ArrayList<>();
        this.category      = category;
        this.cimVersion    = cimVersion;
        this.required      = "PHYSICAL".equals(category);
        this.loadedAt      = Instant.now();
    }

    public boolean isAncestorOrSelf(String name) {
        return className.equals(name) || ancestors.contains(name);
    }

    public String  getId()                         { return id; }
    public String  getClassName()                  { return className; }
    public void    setClassName(String v)          { this.className = v; }
    public String  getParentClass()                { return parentClass; }
    public void    setParentClass(String v)        { this.parentClass = v; }
    public List<String> getAncestors()             { return ancestors; }
    public void    setAncestors(List<String> v)    { this.ancestors = v; }
    public List<String> getOwnAttributes()         { return ownAttributes; }
    public void    setOwnAttributes(List<String> v){ this.ownAttributes = v; }
    public String  getCategory()                   { return category; }
    public void    setCategory(String v)           { this.category = v; }
    public boolean isRequired()                    { return required; }
    public void    setRequired(boolean v)          { this.required = v; }
    public String  getCimPackage()                 { return cimPackage; }
    public void    setCimPackage(String v)         { this.cimPackage = v; }
    public String  getCimVersion()                 { return cimVersion; }
    public void    setCimVersion(String v)         { this.cimVersion = v; }
    public String  getDescription()                { return description; }
    public void    setDescription(String v)        { this.description = v; }
    public Instant getLoadedAt()                   { return loadedAt; }
    public void    setLoadedAt(Instant v)          { this.loadedAt = v; }
}

// ═══════════════════════════════════════════════════════════════════
// ValidationJob — one record per imported file
// ═══════════════════════════════════════════════════════════════════
@Document(collection = "validation_jobs")
class ValidationJob {
    @Id private String id;
    @Indexed(unique = true)
    private String  jobId;
    private String  fileName;
    private String  fileFormat;
    private String  status;        // PENDING, RUNNING, RESOLVED, FAILED
    private String  submittedBy;
    private String  networkVersion; // user-supplied: "2024-Q1", "SUMMER-PEAK"
    private String  fileHash;       // SHA-256 for duplicate detection
    private int     totalObjects;
    private int     physicalObjects;
    private int     logicalObjects;
    private String  errorMessage;
    private long    processingMs;
    private Instant submittedAt;
    private Instant completedAt;

    public ValidationJob() {}

    public ValidationJob(String jobId, String fileName, String fileFormat,
                          String submittedBy, String networkVersion) {
        this.jobId          = jobId;
        this.fileName       = fileName;
        this.fileFormat     = fileFormat;
        this.submittedBy    = submittedBy;
        this.networkVersion = networkVersion;
        this.status         = "PENDING";
        this.submittedAt    = Instant.now();
    }

    public String  getId()                       { return id; }
    public String  getJobId()                    { return jobId; }
    public void    setJobId(String v)            { this.jobId = v; }
    public String  getFileName()                 { return fileName; }
    public void    setFileName(String v)         { this.fileName = v; }
    public String  getFileFormat()               { return fileFormat; }
    public void    setFileFormat(String v)       { this.fileFormat = v; }
    public String  getStatus()                   { return status; }
    public void    setStatus(String v)           { this.status = v; }
    public String  getSubmittedBy()              { return submittedBy; }
    public void    setSubmittedBy(String v)      { this.submittedBy = v; }
    public String  getNetworkVersion()           { return networkVersion; }
    public void    setNetworkVersion(String v)   { this.networkVersion = v; }
    public String  getFileHash()                 { return fileHash; }
    public void    setFileHash(String v)         { this.fileHash = v; }
    public int     getTotalObjects()             { return totalObjects; }
    public void    setTotalObjects(int v)        { this.totalObjects = v; }
    public int     getPhysicalObjects()          { return physicalObjects; }
    public void    setPhysicalObjects(int v)     { this.physicalObjects = v; }
    public int     getLogicalObjects()           { return logicalObjects; }
    public void    setLogicalObjects(int v)      { this.logicalObjects = v; }
    public String  getErrorMessage()             { return errorMessage; }
    public void    setErrorMessage(String v)     { this.errorMessage = v; }
    public long    getProcessingMs()             { return processingMs; }
    public void    setProcessingMs(long v)       { this.processingMs = v; }
    public Instant getSubmittedAt()              { return submittedAt; }
    public void    setSubmittedAt(Instant v)     { this.submittedAt = v; }
    public Instant getCompletedAt()              { return completedAt; }
    public void    setCompletedAt(Instant v)     { this.completedAt = v; }
}

// ═══════════════════════════════════════════════════════════════════
// CimObjectRecord — one record per parsed CIM object
// ═══════════════════════════════════════════════════════════════════
@Document(collection = "cim_objects")
@CompoundIndexes({
    @CompoundIndex(name = "idx_jobid",          def = "{'jobId':1}"),
    @CompoundIndex(name = "idx_jobid_rdfid",    def = "{'jobId':1,'rdfId':1}"),
    @CompoundIndex(name = "idx_jobid_cimtype",  def = "{'jobId':1,'cimType':1}"),
    @CompoundIndex(name = "idx_jobid_category", def = "{'jobId':1,'category':1}"),
    @CompoundIndex(name = "idx_jobid_required", def = "{'jobId':1,'isRequired':1}")
})
class CimObjectRecord {
    @Id private String id;
    private String jobId;
    private String rdfId;
    private String mrid;
    private String cimType;
    private String name;
    private String category;       // PHYSICAL or LOGICAL
    private boolean isRequired;    // true=PHYSICAL default, changeable via API
    private String sourceFormat;
    private String sourceFile;
    private String orgId;
    private String version;        // networkVersion from import
    private Map<String, String> attributes    = new LinkedHashMap<>();
    private Map<String, String> references    = new LinkedHashMap<>();
    private Map<String, String> resolvedRefIds= new LinkedHashMap<>();
    private Instant createdAt;

    public String  getId()                            { return id; }
    public void    setId(String v)                    { this.id = v; }
    public String  getJobId()                         { return jobId; }
    public void    setJobId(String v)                 { this.jobId = v; }
    public String  getRdfId()                         { return rdfId; }
    public void    setRdfId(String v)                 { this.rdfId = v; }
    public String  getMrid()                          { return mrid; }
    public void    setMrid(String v)                  { this.mrid = v; }
    public String  getCimType()                       { return cimType; }
    public void    setCimType(String v)               { this.cimType = v; }
    public String  getName()                          { return name; }
    public void    setName(String v)                  { this.name = v; }
    public String  getCategory()                      { return category; }
    public void    setCategory(String v)              { this.category = v; }
    public boolean isRequired()                       { return isRequired; }
    public void    setRequired(boolean v)             { this.isRequired = v; }
    public String  getSourceFormat()                  { return sourceFormat; }
    public void    setSourceFormat(String v)          { this.sourceFormat = v; }
    public String  getSourceFile()                    { return sourceFile; }
    public void    setSourceFile(String v)            { this.sourceFile = v; }
    public String  getOrgId()                         { return orgId; }
    public void    setOrgId(String v)                 { this.orgId = v; }
    public String  getVersion()                       { return version; }
    public void    setVersion(String v)               { this.version = v; }
    public Map<String,String> getAttributes()         { return attributes; }
    public void    setAttributes(Map<String,String> v){ this.attributes = v; }
    public Map<String,String> getReferences()         { return references; }
    public void    setReferences(Map<String,String> v){ this.references = v; }
    public Map<String,String> getResolvedRefIds()     { return resolvedRefIds; }
    public void    setResolvedRefIds(Map<String,String> v){ this.resolvedRefIds = v; }
    public Instant getCreatedAt()                     { return createdAt; }
    public void    setCreatedAt(Instant v)            { this.createdAt = v; }
}
