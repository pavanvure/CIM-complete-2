package com.cim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * CIM Validation Platform — End-to-End Flow:
 *
 *  1. Admin seeds MongoDB with CIM17 class hierarchy
 *  2. Client uploads file (RDF/XML, JSON-LD, Milsoft CSV, custom)
 *  3. FormatDetector picks the right adapter
 *  4. Adapter parses file → List<CIMObject> (common model)
 *  5. Pipeline runs 4 stages:
 *       Stage 1 — Physical filter (skip logical nodes)
 *       Stage 2 — Attribute path validation (inheritance chain check)
 *       Stage 3 — Reference resolution (rdf:resource links)
 *       Stage 4 — Business rules (per-class required fields)
 *  6. Results saved to MongoDB (3 collections)
 *  7. REST API exposes results
 */
@SpringBootApplication
@EnableAsync
public class CIMPlatformApplication {
    public static void main(String[] args) {
        SpringApplication.run(CIMPlatformApplication.class, args);
    }
}
