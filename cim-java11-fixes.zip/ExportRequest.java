package com.cim.model.mongo;

import java.util.List;

/**
 * Request parameters for a Neo4j export operation.
 *
 * Replaces the Java 16 record syntax (not compatible with Java 11).
 * This is a plain Java 11 POJO with constructor, getters, and no setters
 * (immutable by convention).
 */
public class ExportRequest {

    public enum ExportMode {
        /** Export ALL objects in the job */
        ALL,
        /** Export only category=PHYSICAL objects */
        PHYSICAL_ONLY,
        /** Export only isRequired=true objects */
        REQUIRED_ONLY,
        /** Export only the cimTypes specified in the cimTypes list */
        CUSTOM
    }

    private final String       jobId;
    private final ExportMode   mode;
    private final List<String> cimTypes;   // used when mode=CUSTOM
    private final boolean      clearFirst; // delete existing nodes before export

    public ExportRequest(String jobId, ExportMode mode,
                          List<String> cimTypes, boolean clearFirst) {
        this.jobId      = jobId;
        this.mode       = mode;
        this.cimTypes   = cimTypes != null ? cimTypes : java.util.Collections.emptyList();
        this.clearFirst = clearFirst;
    }

    public String       getJobId()      { return jobId; }
    public ExportMode   getMode()       { return mode; }
    public List<String> getCimTypes()   { return cimTypes; }
    public boolean      isClearFirst()  { return clearFirst; }

    @Override
    public String toString() {
        return "ExportRequest{jobId='" + jobId + "', mode=" + mode
                + ", cimTypes=" + cimTypes + ", clearFirst=" + clearFirst + "}";
    }
}
