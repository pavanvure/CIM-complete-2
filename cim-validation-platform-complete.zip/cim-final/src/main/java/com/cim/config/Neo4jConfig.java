package com.cim.config;

import org.neo4j.driver.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Neo4jConfig {

    private static final Logger log = LoggerFactory.getLogger(Neo4jConfig.class);

    @Value("${neo4j.uri:bolt://localhost:7687}")
    private String uri;

    @Value("${neo4j.username:neo4j}")
    private String username;

    @Value("${neo4j.password:password}")
    private String password;

    /**
     * Direct Neo4j Bolt driver — used for bulk UNWIND export.
     * Separate from Spring Data Neo4j driver for fine-grained control.
     */
    @Bean
    public Driver neo4jDriver() {
        try {
            Driver driver = GraphDatabase.driver(uri,
                    AuthTokens.basic(username, password),
                    Config.builder()
                            .withMaxConnectionPoolSize(20)
                            .withConnectionAcquisitionTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                            .build());
            driver.verifyConnectivity();
            log.info("Neo4j connected: {}", uri);
            return driver;
        } catch (Exception e) {
            log.warn("Neo4j not available ({}). Export will fail until connected.", e.getMessage());
            // Return driver anyway — export endpoint will handle errors gracefully
            return GraphDatabase.driver(uri, AuthTokens.basic(username, password));
        }
    }
}
