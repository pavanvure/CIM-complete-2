package com.cim.controller;

import com.cim.repository.CimClassRepository;
import com.cim.service.CIMStandardService;
import com.cim.validation.registry.CIMHierarchyRegistry;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

/**
 * Admin REST API — CIM Standard Management
 *
 * POST /api/admin/cim/upload-owl             — single OWL file
 * POST /api/admin/cim/upload-owl/multiple    — multiple CPSM profiles
 * POST /api/admin/cim/reload                 — reload from configured path
 * GET  /api/admin/cim/classes                — list all classes
 * GET  /api/admin/cim/classes/{name}         — one class detail
 * GET  /api/admin/cim/chain/{name}           — inheritance chain
 * POST /api/admin/cim/validate-path          — test attribute path
 * GET  /api/admin/cim/stats                  — registry stats
 */
@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    private final CIMStandardService   standardService;
    private final CIMHierarchyRegistry registry;
    private final CimClassRepository   classRepo;

    public AdminController(CIMStandardService standardService,
                           CIMHierarchyRegistry registry,
                           CimClassRepository classRepo) {
        this.standardService = standardService;
        this.registry        = registry;
        this.classRepo       = classRepo;
    }

    @PostMapping("/cim/upload-owl")
    public ResponseEntity<?> uploadOwl(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value="version", defaultValue="CIM17") String version) {
        if (file.isEmpty()) return ResponseEntity.badRequest()
                .body(Map.of("error","OWL file is empty."));
        try {
            var result = standardService.loadFromUploadedOwl(file, version);
            return ResponseEntity.ok(Map.of(
                "status","OK","cimVersion",result.cimVersion(),
                "totalClasses",result.totalClasses(),
                "physicalClasses",result.physicalClasses(),
                "logicalClasses",result.logicalClasses()
            ));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error","Failed: "+e.getMessage()));
        }
    }

    @PostMapping("/cim/upload-owl/multiple")
    public ResponseEntity<?> uploadMultipleOwls(
            @RequestParam("files") List<MultipartFile> files,
            @RequestParam(value="version", defaultValue="CIM17-CPSM") String version) {
        if (files == null || files.isEmpty()) return ResponseEntity.badRequest()
                .body(Map.of("error","No OWL files provided."));
        try {
            var result = standardService.loadFromMultipleUploads(files, version);
            return ResponseEntity.ok(Map.of(
                "status","OK","cimVersion",result.cimVersion(),
                "totalClasses",result.totalClasses(),
                "filesProcessed",files.stream().map(f->f.getOriginalFilename()).toList()
            ));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error","Failed: "+e.getMessage()));
        }
    }

    @PostMapping("/cim/reload")
    public ResponseEntity<?> reload(
            @RequestParam(value="version", defaultValue="") String version) {
        try {
            var result = standardService.reload(version);
            return ResponseEntity.ok(Map.of("status","OK",
                    "cimVersion",result.cimVersion(),"totalClasses",result.totalClasses()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error",e.getMessage()));
        }
    }

    @GetMapping("/cim/classes")
    public ResponseEntity<?> listClasses(
            @RequestParam(required=false) String category) {
        var classes = category != null
                ? classRepo.findByCategory(category.toUpperCase())
                : classRepo.findAll();
        return ResponseEntity.ok(Map.of("totalClasses",classes.size(),"classes",classes));
    }

    @GetMapping("/cim/classes/{name}")
    public ResponseEntity<?> getClass(@PathVariable String name) {
        var def = registry.getDefinition(name);
        if (def == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(Map.of(
            "className",    def.getClassName(),
            "parentClass",  def.getParentClass() != null ? def.getParentClass() : "ROOT",
            "ancestors",    def.getAncestors(),
            "ownAttributes",def.getOwnAttributes(),
            "category",     def.getCategory() != null ? def.getCategory() : "UNKNOWN",
            "required",     def.isRequired(),
            "cimPackage",   def.getCimPackage() != null ? def.getCimPackage() : "Unknown",
            "cimVersion",   def.getCimVersion(),
            "description",  def.getDescription() != null ? def.getDescription() : ""
        ));
    }

    @GetMapping("/cim/chain/{className}")
    public ResponseEntity<?> getChain(@PathVariable String className) {
        if (!registry.isKnownClass(className)) return ResponseEntity.notFound().build();
        var chain = registry.getFullChain(className);
        return ResponseEntity.ok(Map.of("className",className,"chain",chain,"depth",chain.size()));
    }

    @PostMapping("/cim/validate-path")
    public ResponseEntity<?> validatePath(@RequestBody Map<String,String> body) {
        String type = body.get("objectType"), tag = body.get("attributeTag");
        if (type == null || tag == null) return ResponseEntity.badRequest()
                .body(Map.of("error","Both objectType and attributeTag required."));
        var result = registry.validateAttributePath(type, tag);
        return ResponseEntity.ok(Map.of(
            "objectType",type,"attributeTag",tag,
            "status",result.getStatus().name(),"valid",result.isValid(),
            "explanation",result.getExplanation(),
            "chain",registry.getFullChain(type)
        ));
    }

    @GetMapping("/cim/stats")
    public ResponseEntity<?> stats() {
        boolean loaded = registry.isLoaded();
        return ResponseEntity.ok(Map.of(
            "registryLoaded",loaded,"totalClasses",registry.size(),
            "physicalClasses",classRepo.findByCategory("PHYSICAL").size(),
            "logicalClasses", classRepo.findByCategory("LOGICAL").size(),
            "note",loaded ? "Registry ready." : "Upload OWL via POST /api/admin/cim/upload-owl"
        ));
    }
}
