package com.cim.service;

import com.cim.adapter.AdapterRegistry;
import com.cim.adapter.CIMFormatAdapter;
import com.cim.model.cim.CIMObject;
import com.cim.model.mongo.*;
import com.cim.pipeline.result.PipelineFinding;
import com.cim.pipeline.stage.ValidationPipeline;
import com.cim.repository.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * Main orchestrator for the end-to-end validation flow:
 *
 *  1. Detect format  → AdapterRegistry
 *  2. Parse file     → List<CIMObject>  (common model)
 *  3. Save objects   → MongoDB cim_objects
 *  4. Run pipeline   → List<PipelineFinding>
 *  5. Save findings  → MongoDB validation_findings
 *  6. Update job     → MongoDB validation_jobs
 *  7. Return summary
 */
@Service
public class ValidationService {

    private final AdapterRegistry            adapterRegistry;
    private final ValidationPipeline         pipeline;
    private final ValidationJobRepository    jobRepo;
    private final CimObjectRecordRepository  objectRepo;
    private final ValidationFindingRepository findingRepo;

    public ValidationService(AdapterRegistry adapterRegistry,
                              ValidationPipeline pipeline,
                              ValidationJobRepository jobRepo,
                              CimObjectRecordRepository objectRepo,
                              ValidationFindingRepository findingRepo) {
        this.adapterRegistry = adapterRegistry;
        this.pipeline        = pipeline;
        this.jobRepo         = jobRepo;
        this.objectRepo      = objectRepo;
        this.findingRepo     = findingRepo;
    }

    // ── Synchronous (small files) ─────────────────────────────────────────

    public ValidationSummary validateSync(MultipartFile file,
                                           String submittedBy) throws Exception {
        String jobId = UUID.randomUUID().toString();
        return execute(jobId, file.getOriginalFilename(),
                       file.getBytes(), submittedBy);
    }

    // ── Asynchronous (large files) ────────────────────────────────────────

    @Async
    public CompletableFuture<ValidationSummary> validateAsync(MultipartFile file,
                                                               String submittedBy) throws Exception {
        String jobId = UUID.randomUUID().toString();

        // Create PENDING job immediately so client can poll
        ValidationJob job = new ValidationJob(
                jobId, file.getOriginalFilename(), "DETECTING", submittedBy);
        jobRepo.save(job);

        ValidationSummary summary =
                execute(jobId, file.getOriginalFilename(), file.getBytes(), submittedBy);
        return CompletableFuture.completedFuture(summary);
    }

    // ── Core execution ────────────────────────────────────────────────────

    private ValidationSummary execute(String jobId, String fileName,
                                       byte[] bytes, String submittedBy) throws Exception {
        long start = System.currentTimeMillis();

        // ── Step 1: Detect format ─────────────────────────────────────────
        CIMFormatAdapter adapter;
        try {
            byte[] sample = Arrays.copyOf(bytes, Math.min(512, bytes.length));
            adapter = adapterRegistry.detect(sample, fileName);
        } catch (IllegalArgumentException e) {
            return failJob(jobId, fileName, "UNKNOWN", submittedBy,
                           e.getMessage(), System.currentTimeMillis() - start);
        }

        String format = adapter.getFormatName();

        // Create/update job record
        ValidationJob job = jobRepo.findByJobId(jobId)
                .orElse(new ValidationJob(jobId, fileName, format, submittedBy));
        job.setFileFormat(format);
        job.setStatus("RUNNING");
        jobRepo.save(job);

        // ── Step 2: Parse → Common model ─────────────────────────────────
        List<CIMObject> objects;
        try {
            objects = adapter.parse(
                    new java.io.ByteArrayInputStream(bytes), fileName);
        } catch (Exception e) {
            return failJob(jobId, fileName, format, submittedBy,
                           "Parse error: " + e.getMessage(),
                           System.currentTimeMillis() - start);
        }

        // ── Step 3: Save parsed objects to MongoDB ────────────────────────
        List<CimObjectRecord> records = objects.stream()
                .map(o -> toRecord(o, jobId))
                .collect(Collectors.toList());
        objectRepo.saveAll(records);

        // ── Step 4: Run validation pipeline ──────────────────────────────
        List<PipelineFinding> findings = pipeline.run(objects, jobId);

        // ── Step 5: Save findings to MongoDB ─────────────────────────────
        List<ValidationFinding> findingDocs = findings.stream()
                .map(this::toFindingDoc)
                .collect(Collectors.toList());
        findingRepo.saveAll(findingDocs);

        // ── Step 6: Update job with counts ───────────────────────────────
        long elapsed = System.currentTimeMillis() - start;
        long errors  = findings.stream().filter(PipelineFinding::isError).count();
        long warnings= findings.stream().filter(PipelineFinding::isWarning).count();
        long infos   = findings.stream().filter(PipelineFinding::isInfo).count();

        long physical = objects.stream()
                .filter(o -> !isLogical(o.getCimType())).count();
        long logical  = objects.size() - physical;

        job.setStatus(errors > 0 ? "FAILED" : "DONE");
        job.setTotalObjects(objects.size());
        job.setPhysicalObjects((int) physical);
        job.setLogicalObjects((int) logical);
        job.setErrorCount((int) errors);
        job.setWarningCount((int) warnings);
        job.setInfoCount((int) infos);
        job.setCompletedAt(Instant.now());
        job.setProcessingMs(elapsed);
        jobRepo.save(job);

        return new ValidationSummary(jobId, fileName, format,
                objects.size(), (int) physical, (int) logical,
                (int) errors, (int) warnings, (int) infos,
                errors > 0 ? "FAILED" : "PASSED", elapsed);
    }

    // ── Helper: map CIMObject → MongoDB record ────────────────────────────

    private CimObjectRecord toRecord(CIMObject obj, String jobId) {
        CimObjectRecord r = new CimObjectRecord();
        r.setJobId(jobId);
        r.setRdfId(obj.getRdfId());
        r.setMrid(obj.getMrid());
        r.setCimType(obj.getCimType());
        r.setName(obj.getName());
        r.setCategory(isLogical(obj.getCimType()) ? "LOGICAL" : "PHYSICAL");
        r.setSourceFormat(obj.getSourceFormat());
        r.setSourceFile(obj.getSourceFile());
        r.setOrgId(obj.getOrgId());
        r.setVersion(obj.getVersion());
        r.setAttributes(new LinkedHashMap<>(obj.getAttributes()));
        r.setReferences(new LinkedHashMap<>(obj.getReferences()));
        r.setCreatedAt(Instant.now());
        return r;
    }

    // ── Helper: map PipelineFinding → MongoDB document ────────────────────

    private ValidationFinding toFindingDoc(PipelineFinding f) {
        return new ValidationFinding(
                f.getJobId(),
                f.getSeverity().name(),
                f.getStage(),
                f.getObjectType(),
                f.getObjectId(),
                f.getObjectName(),
                f.getAttributeTag(),
                f.getMessage(),
                f.getResolvedPath(),
                f.getSourceFormat()
        );
    }

    // ── Helper: fail job ──────────────────────────────────────────────────

    private ValidationSummary failJob(String jobId, String fileName,
                                       String format, String submittedBy,
                                       String errorMessage, long elapsed) {
        ValidationJob job = jobRepo.findByJobId(jobId)
                .orElse(new ValidationJob(jobId, fileName, format, submittedBy));
        job.setStatus("FAILED");
        job.setErrorMessage(errorMessage);
        job.setCompletedAt(Instant.now());
        job.setProcessingMs(elapsed);
        jobRepo.save(job);
        return new ValidationSummary(jobId, fileName, format,
                0, 0, 0, 1, 0, 0, "FAILED", elapsed);
    }

    private static final Set<String> LOGICAL_TYPES = Set.of(
        "ConnectivityNode","TopologicalNode","TopologicalIsland","Terminal",
        "ACDCTerminal","Measurement","Accumulator","Analog","Discrete",
        "AccumulatorValue","AnalogValue","DiscreteValue","LoadGroup",
        "ConformLoadGroup","NonConformLoadGroup","LoadArea","SubLoadArea",
        "EnergyArea","RegulatingControl","RegulationSchedule","TapChangerControl",
        "BranchGroup","Name","NameType","Location","PowerCutZone"
    );
    private boolean isLogical(String t) { return LOGICAL_TYPES.contains(t); }
}
