package com.cim.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.core.convert.*;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;

@Configuration
public class MongoConfig {
    // U+FF0E replaces dots in map keys (CIM uses "ClassName.attr" pattern)
    public static final String DOT_REPLACEMENT = "\uff0e";

    @Bean
    public MappingMongoConverter mappingMongoConverter(
            MongoDatabaseFactory factory, MongoMappingContext context) {
        DbRefResolver dbRef = new DefaultDbRefResolver(factory);
        MappingMongoConverter conv = new MappingMongoConverter(dbRef, context);
        conv.setMapKeyDotReplacement(DOT_REPLACEMENT);
        conv.setTypeMapper(new DefaultMongoTypeMapper(null));
        return conv;
    }
}
