package com.cim.service;

import com.cim.model.mongo.CimClassDefinition;
import org.apache.jena.rdf.model.*;
import org.apache.jena.vocabulary.OWL;
import org.apache.jena.vocabulary.RDF;
import org.apache.jena.vocabulary.RDFS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.*;
import java.util.*;

/**
 * Parses CIM OWL files using Apache Jena.
 * Supports CPSM multi-profile format (CoreEquipment + Operation + ShortCircuit).
 *
 * CPSM file structure:
 *   rdf:type = owl:Class          → CIM class
 *   rdfs:label                    → class name
 *   rdfs:subClassOf               → parent (skips self-references)
 *   uml:hasStereotype             → abstract/concrete/enumeration
 *   owl:Restriction + onProperty  → "ClassName.attrName" → attribute mapping
 */
@Component
public class CIMOwlParser {

    private static final Logger log = LoggerFactory.getLogger(CIMOwlParser.class);
    private static final String NS_UML = "http://langdale.com.au/2005/UML#";
    private static final Property PROP_HAS_STEREOTYPE =
            ResourceFactory.createProperty(NS_UML, "hasStereotype");

    private static final Set<String> LOGICAL_STEREO =
            Set.of("abstract","Abstract","Primitive","CIMDatatype","enumeration","Enumeration","Compound");
    private static final Set<String> LOGICAL_PKG =
            Set.of("Topology","Meas","StateVariables","LoadModel","Contingency",
                   "InfWork","InfAssets","InfLocations","InfOperations","DiagramLayout");
    private static final Set<String> PHYSICAL_PKG =
            Set.of("Wires","Generation","Substation","Protection","ControlArea","DC");
    private static final Set<String> LOGICAL_NAMES =
            Set.of("Terminal","ACDCTerminal","DCTerminal","ConnectivityNode",
                   "TopologicalNode","TopologicalIsland","BusNameMarker");

    // Built-in CIM17 core hierarchy — fills gaps in CPSM profiles
    private static final Map<String, String> CIM_CORE_PARENTS = new LinkedHashMap<>();
    static {
        CIM_CORE_PARENTS.put("IdentifiedObject",        null);
        CIM_CORE_PARENTS.put("PowerSystemResource",     "IdentifiedObject");
        CIM_CORE_PARENTS.put("Equipment",               "PowerSystemResource");
        CIM_CORE_PARENTS.put("ConductingEquipment",     "Equipment");
        CIM_CORE_PARENTS.put("Conductor",               "ConductingEquipment");
        CIM_CORE_PARENTS.put("ACLineSegment",            "Conductor");
        CIM_CORE_PARENTS.put("Switch",                   "ConductingEquipment");
        CIM_CORE_PARENTS.put("ProtectedSwitch",          "Switch");
        CIM_CORE_PARENTS.put("Breaker",                  "ProtectedSwitch");
        CIM_CORE_PARENTS.put("Recloser",                 "ProtectedSwitch");
        CIM_CORE_PARENTS.put("LoadBreakSwitch",          "ProtectedSwitch");
        CIM_CORE_PARENTS.put("Fuse",                     "Switch");
        CIM_CORE_PARENTS.put("Disconnector",             "Switch");
        CIM_CORE_PARENTS.put("EnergyConnection",         "ConductingEquipment");
        CIM_CORE_PARENTS.put("RegulatingCondEq",         "EnergyConnection");
        CIM_CORE_PARENTS.put("ShuntCompensator",         "RegulatingCondEq");
        CIM_CORE_PARENTS.put("LinearShuntCompensator",   "ShuntCompensator");
        CIM_CORE_PARENTS.put("RotatingMachine",          "RegulatingCondEq");
        CIM_CORE_PARENTS.put("SynchronousMachine",       "RotatingMachine");
        CIM_CORE_PARENTS.put("AsynchronousMachine",      "RotatingMachine");
        CIM_CORE_PARENTS.put("PowerTransformer",         "ConductingEquipment");
        CIM_CORE_PARENTS.put("EnergyConsumer",           "EnergyConnection");
        CIM_CORE_PARENTS.put("ConformLoad",              "EnergyConsumer");
        CIM_CORE_PARENTS.put("NonConformLoad",           "EnergyConsumer");
        CIM_CORE_PARENTS.put("ConnectivityNodeContainer","PowerSystemResource");
        CIM_CORE_PARENTS.put("EquipmentContainer",       "ConnectivityNodeContainer");
        CIM_CORE_PARENTS.put("Line",                     "EquipmentContainer");
        CIM_CORE_PARENTS.put("Substation",               "EquipmentContainer");
        CIM_CORE_PARENTS.put("VoltageLevel",             "EquipmentContainer");
        CIM_CORE_PARENTS.put("Bay",                      "EquipmentContainer");
        CIM_CORE_PARENTS.put("GeographicalRegion",       "IdentifiedObject");
        CIM_CORE_PARENTS.put("SubGeographicalRegion",    "IdentifiedObject");
        CIM_CORE_PARENTS.put("BaseVoltage",              "IdentifiedObject");
        CIM_CORE_PARENTS.put("GeneratingUnit",           "Equipment");
        CIM_CORE_PARENTS.put("WindGeneratingUnit",       "GeneratingUnit");
        CIM_CORE_PARENTS.put("SolarGeneratingUnit",      "GeneratingUnit");
        CIM_CORE_PARENTS.put("PowerElectronicsConnection","RegulatingCondEq");
        CIM_CORE_PARENTS.put("PowerElectronicsUnit",     "Equipment");
        CIM_CORE_PARENTS.put("BatteryUnit",              "PowerElectronicsUnit");
        CIM_CORE_PARENTS.put("PhotoVoltaicUnit",         "PowerElectronicsUnit");
        CIM_CORE_PARENTS.put("Location",                 "IdentifiedObject");
        CIM_CORE_PARENTS.put("PositionPoint",            "IdentifiedObject");
        CIM_CORE_PARENTS.put("CoordinateSystem",         "IdentifiedObject");
        CIM_CORE_PARENTS.put("Terminal",                 "ACDCTerminal");
        CIM_CORE_PARENTS.put("ACDCTerminal",             "IdentifiedObject");
        CIM_CORE_PARENTS.put("ConnectivityNode",         "IdentifiedObject");
        CIM_CORE_PARENTS.put("TopologicalNode",          "IdentifiedObject");
        CIM_CORE_PARENTS.put("TopologicalIsland",        "IdentifiedObject");
    }

    private static class ClassInfo {
        final String name, parentName, stereotype, description;
        ClassInfo(String n,String p,String s,String d){name=n;parentName=p;stereotype=s;description=d;}
    }

    public List<CimClassDefinition> parse(InputStream in, String version) throws Exception {
        return parse(in, version, "uploaded.owl");
    }

    public List<CimClassDefinition> parse(InputStream in, String version,
                                           String fileName) throws Exception {
        log.info("Parsing OWL: {} version={}", fileName, version);
        long start = System.currentTimeMillis();
        Model model = ModelFactory.createDefaultModel();
        model.read(in, null, "RDF/XML");
        log.info("  Loaded {} triples", model.size());
        return buildDefinitions(model, version, start);
    }

    public List<CimClassDefinition> parseMultiple(Map<String, InputStream> streams,
                                                    String version) throws Exception {
        log.info("Merging {} OWL files version={}", streams.size(), version);
        long start = System.currentTimeMillis();
        Model merged = ModelFactory.createDefaultModel();
        for (Map.Entry<String, InputStream> e : streams.entrySet()) {
            Model fm = ModelFactory.createDefaultModel();
            fm.read(e.getValue(), null, "RDF/XML");
            log.info("  {} → {} triples", e.getKey(), fm.size());
            merged.add(fm);
        }
        return buildDefinitions(merged, version, start);
    }

    private List<CimClassDefinition> buildDefinitions(Model model,
                                                       String version, long start) {
        Map<String, ClassInfo> classMap = new LinkedHashMap<>();
        Map<String, List<String>> attrMap = new LinkedHashMap<>();

        model.listSubjectsWithProperty(RDF.type, OWL.Class)
             .forEachRemaining(r -> { ClassInfo ci = extractClass(r); if(ci!=null) classMap.putIfAbsent(ci.name,ci); });
        model.listSubjectsWithProperty(RDF.type, RDFS.Class)
             .forEachRemaining(r -> { ClassInfo ci = extractClass(r); if(ci!=null) classMap.putIfAbsent(ci.name,ci); });

        model.listSubjectsWithProperty(RDF.type, OWL.Restriction)
             .forEachRemaining(r -> {
                 Statement s = r.getProperty(OWL.onProperty);
                 if (s == null) return;
                 String local = localName(s.getObject().toString());
                 if (local == null || !local.contains(".")) return;
                 int dot = local.lastIndexOf('.');
                 String cls  = local.substring(0, dot);
                 String attr = local.substring(dot + 1);
                 if (!cls.isBlank() && !attr.isBlank()) {
                     List<String> attrs = attrMap.computeIfAbsent(cls, k -> new ArrayList<>());
                     if (!attrs.contains(attr)) attrs.add(attr);
                     classMap.computeIfAbsent(cls, k -> new ClassInfo(cls,null,null,null));
                 }
             });

        // Build parent map: OWL data + built-in fallback
        Map<String, String> parentMap = new LinkedHashMap<>(CIM_CORE_PARENTS);
        classMap.forEach((name, ci) -> {
            if (ci.parentName != null && !ci.parentName.equals(name))
                parentMap.put(name, ci.parentName);
        });

        List<CimClassDefinition> defs = new ArrayList<>();
        classMap.forEach((name, ci) -> {
            List<String> attrs = new ArrayList<>();
            List<String> raw = attrMap.get(name);
            if (raw != null) for (String a : raw) if (!attrs.contains(a)) attrs.add(a);

            String category = determineCategory(ci.stereotype, null, name);
            CimClassDefinition def = new CimClassDefinition(
                    name, parentMap.get(name),
                    computeAncestors(name, parentMap),
                    attrs, category, version);
            def.setCimPackage("Core");
            def.setDescription(ci.description);
            defs.add(def);
        });

        log.info("OWL build complete: {} classes ({} with attrs) in {}ms",
                defs.size(), defs.stream().filter(d->!d.getOwnAttributes().isEmpty()).count(),
                System.currentTimeMillis()-start);
        return defs;
    }

    private ClassInfo extractClass(Resource r) {
        String name = null;
        Statement ls = r.getProperty(RDFS.label);
        if (ls != null) name = ls.getString().trim();
        if ((name == null || name.isBlank()) && r.isURIResource()) name = localName(r.getURI());
        if (name == null || name.isBlank()) return null;

        String parentName = null;
        Statement ss = r.getProperty(RDFS.subClassOf);
        if (ss != null) {
            RDFNode p = ss.getObject();
            if (p.isURIResource()) {
                String pn = localName(p.asResource().getURI());
                if (pn != null && !pn.equals(name) && !"Thing".equals(pn)) parentName = pn;
            }
        }

        String stereotype = null;
        Statement st = r.getProperty(PROP_HAS_STEREOTYPE);
        if (st != null) {
            RDFNode n = st.getObject();
            stereotype = n.isURIResource() ? localName(n.asResource().getURI()) : n.asLiteral().getString().trim();
        }

        String desc = null;
        Statement cs = r.getProperty(RDFS.comment);
        if (cs != null) desc = cs.getString().trim();

        return new ClassInfo(name, parentName, stereotype, desc);
    }

    private List<String> computeAncestors(String cls, Map<String,String> pm) {
        List<String> chain = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        String cur = pm.get(cls);
        while (cur != null && !visited.contains(cur)) {
            chain.add(cur); visited.add(cur); cur = pm.get(cur);
        }
        return chain;
    }

    private String determineCategory(String stereotype, String pkg, String name) {
        if (stereotype != null && LOGICAL_STEREO.contains(stereotype)) return "LOGICAL";
        if (pkg != null && LOGICAL_PKG.contains(pkg)) return "LOGICAL";
        if (pkg != null && PHYSICAL_PKG.contains(pkg)) return "PHYSICAL";
        if (name != null) {
            if (LOGICAL_NAMES.contains(name)) return "LOGICAL";
            if (name.endsWith("Value")||name.endsWith("Schedule")||name.endsWith("Island")
                    ||name.startsWith("Sv")||name.endsWith("Kind")||name.endsWith("Type")) return "LOGICAL";
        }
        return "PHYSICAL";
    }

    String localName(String uri) {
        if (uri == null || uri.isBlank()) return null;
        int idx = Math.max(uri.lastIndexOf('#'), uri.lastIndexOf('/'));
        return (idx >= 0 && idx < uri.length()-1) ? uri.substring(idx+1) : uri;
    }
}
