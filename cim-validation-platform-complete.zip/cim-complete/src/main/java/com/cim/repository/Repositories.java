package com.cim.repository;

import com.cim.model.mongo.CimClassDefinition;
import com.cim.model.mongo.CimObjectRecord;
import com.cim.model.mongo.ValidationJob;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

// ── CIM Standard ──────────────────────────────────────────────────
@Repository
public interface CimClassRepository extends MongoRepository<CimClassDefinition, String> {
    Optional<CimClassDefinition> findByClassName(String className);
    List<CimClassDefinition> findByCategory(String category);
    List<CimClassDefinition> findByCimVersion(String cimVersion);
    void deleteAllByCimVersion(String cimVersion);
}

// ── Validation Jobs ───────────────────────────────────────────────
@Repository
interface ValidationJobRepository extends MongoRepository<ValidationJob, String> {
    Optional<ValidationJob> findByJobId(String jobId);
    List<ValidationJob> findTop10ByOrderBySubmittedAtDesc();
    List<ValidationJob> findByNetworkVersion(String networkVersion);
    List<ValidationJob> findByFileHashAndNetworkVersionAndStatusIn(
            String fileHash, String networkVersion, List<String> statuses);
    List<ValidationJob> findByFileNameAndNetworkVersionAndStatusIn(
            String fileName, String networkVersion, List<String> statuses);
    List<ValidationJob> findByStatus(String status);
}

// ── CIM Objects ───────────────────────────────────────────────────
@Repository
interface CimObjectRecordRepository extends MongoRepository<CimObjectRecord, String> {
    Page<CimObjectRecord> findByJobId(String jobId, Pageable pageable);
    List<CimObjectRecord> findByJobIdAndCimType(String jobId, String cimType);
    List<CimObjectRecord> findByJobIdAndCategory(String jobId, String category);
    List<CimObjectRecord> findByJobIdAndIsRequired(String jobId, boolean isRequired);
    List<CimObjectRecord> findByJobIdAndCategoryAndIsRequired(
            String jobId, String category, boolean isRequired);
    long countByJobId(String jobId);
    long countByJobIdAndCategory(String jobId, String category);
    long countByJobIdAndIsRequired(String jobId, boolean isRequired);
    void deleteByJobId(String jobId);
}
