package com.cim.service;

import com.cim.model.mongo.*;
import com.cim.repository.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Retrieves parsed CIM objects and validation findings from MongoDB.
 * Powers the GET endpoints of the REST API.
 */
@Service
public class QueryService {

    private final ValidationJobRepository    jobRepo;
    private final CimObjectRecordRepository  objectRepo;
    private final ValidationFindingRepository findingRepo;

    public QueryService(ValidationJobRepository jobRepo,
                        CimObjectRecordRepository objectRepo,
                        ValidationFindingRepository findingRepo) {
        this.jobRepo     = jobRepo;
        this.objectRepo  = objectRepo;
        this.findingRepo = findingRepo;
    }

    // ── Jobs ──────────────────────────────────────────────────────────────

    public Optional<ValidationJob> getJob(String jobId) {
        return jobRepo.findByJobId(jobId);
    }

    public List<ValidationJob> getRecentJobs(int limit) {
        return jobRepo.findTop10ByOrderBySubmittedAtDesc();
    }

    // ── CIM Objects (the common data) ─────────────────────────────────────

    public Page<CimObjectRecord> getObjects(String jobId, int page, int size) {
        return objectRepo.findByJobId(jobId,
                PageRequest.of(page, size, Sort.by("cimType")));
    }

    public List<CimObjectRecord> getObjectsByType(String jobId, String cimType) {
        return objectRepo.findByJobIdAndCimType(jobId, cimType);
    }

    public List<CimObjectRecord> getPhysicalObjects(String jobId) {
        return objectRepo.findByJobIdAndCategory(jobId, "PHYSICAL");
    }

    public List<CimObjectRecord> getLogicalObjects(String jobId) {
        return objectRepo.findByJobIdAndCategory(jobId, "LOGICAL");
    }

    public List<CimObjectRecord> searchByName(String jobId, String name) {
        return objectRepo.searchByName(jobId, name);
    }

    public List<CimObjectRecordRepository.TypeCountResult> getTypeBreakdown(String jobId) {
        return objectRepo.countByType(jobId);
    }

    public Map<String, Object> getObjectStats(String jobId) {
        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("total",    objectRepo.countByJobId(jobId));
        stats.put("physical", objectRepo.findByJobIdAndCategory(jobId,"PHYSICAL").size());
        stats.put("logical",  objectRepo.findByJobIdAndCategory(jobId,"LOGICAL").size());
        stats.put("byType",   getTypeBreakdown(jobId));
        return stats;
    }

    // ── Validation Findings ───────────────────────────────────────────────

    public Page<ValidationFinding> getFindings(String jobId, int page, int size) {
        return findingRepo.findByJobId(jobId,
                PageRequest.of(page, size, Sort.by("severity")));
    }

    public List<ValidationFinding> getFindingsBySeverity(String jobId, String severity) {
        return findingRepo.findByJobIdAndSeverity(jobId, severity.toUpperCase());
    }

    public List<ValidationFinding> getFindingsByStage(String jobId, String stage) {
        return findingRepo.findByJobIdAndStage(jobId, stage.toUpperCase());
    }

    public List<ValidationFinding> getFindingsByObjectType(String jobId, String type) {
        return findingRepo.findByJobIdAndObjectType(jobId, type);
    }

    public Map<String, Object> getFindingSummary(String jobId) {
        Map<String, Object> summary = new LinkedHashMap<>();
        summary.put("total",    findingRepo.countByJobId(jobId));
        summary.put("errors",   findingRepo.countByJobIdAndSeverity(jobId, "ERROR"));
        summary.put("warnings", findingRepo.countByJobIdAndSeverity(jobId, "WARNING"));
        summary.put("info",     findingRepo.countByJobIdAndSeverity(jobId, "INFO"));
        return summary;
    }
}
