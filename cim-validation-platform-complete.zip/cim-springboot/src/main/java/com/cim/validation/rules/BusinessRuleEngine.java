package com.cim.validation.rules;

import com.cim.model.cim.CIMObject;
import com.cim.pipeline.result.PipelineFinding;
import org.springframework.stereotype.Component;

import java.util.*;

// ═══════════════════════════════════════════════════════════════════════════
// RULE ENGINE
// ═══════════════════════════════════════════════════════════════════════════

@Component
public class BusinessRuleEngine {

    private final List<ClassRule> rules;

    public BusinessRuleEngine(List<ClassRule> rules) {
        this.rules = rules;
    }

    public List<PipelineFinding> validate(CIMObject obj, String jobId) {
        List<PipelineFinding> findings = new ArrayList<>(universalRules(obj, jobId));
        for (ClassRule rule : rules) {
            if (rule.appliesTo(obj.getCimType())) {
                findings.addAll(rule.validate(obj, jobId));
            }
        }
        return findings;
    }

    private List<PipelineFinding> universalRules(CIMObject obj, String jobId) {
        List<PipelineFinding> f = new ArrayList<>();
        if (obj.getMrid() == null || obj.getMrid().isBlank()) {
            f.add(PipelineFinding.error(jobId, "BUSINESS_RULE", obj,
                    "IdentifiedObject.mRID", "mRID is required on every CIM object.", null));
        }
        String name = obj.getAttribute("IdentifiedObject.name");
        if (name == null || name.isBlank()) {
            f.add(PipelineFinding.warning(jobId, "BUSINESS_RULE", obj,
                    "IdentifiedObject.name", "Name is missing — recommended.", null));
        }
        return f;
    }
}


// ═══════════════════════════════════════════════════════════════════════════
// RULE INTERFACE
// ═══════════════════════════════════════════════════════════════════════════

interface ClassRule {
    boolean appliesTo(String cimType);
    List<PipelineFinding> validate(CIMObject obj, String jobId);
}

// ── Shared helpers ─────────────────────────────────────────────────────────
abstract class BaseRule implements ClassRule {
    protected void requireRef(CIMObject obj, String jobId,
                               List<PipelineFinding> f, String key, String msg) {
        if (!obj.hasReference(key)) {
            f.add(PipelineFinding.error(jobId, "BUSINESS_RULE", obj, key, msg, null));
        } else if (!obj.hasResolved(key)) {
            f.add(PipelineFinding.error(jobId, "BUSINESS_RULE", obj, key,
                    key + " reference unresolved — target not in file.", null));
        } else {
            CIMObject t = obj.getResolved(key);
            f.add(PipelineFinding.info(jobId, "BUSINESS_RULE", obj, key,
                    "OK → [" + t.getCimType() + "] " + t.getName(), null));
        }
    }

    protected void requireNumeric(CIMObject obj, String jobId,
                                   List<PipelineFinding> f, String key) {
        String v = obj.getAttribute(key);
        if (v == null || v.isBlank()) return;
        try { Double.parseDouble(v.trim()); }
        catch (NumberFormatException e) {
            f.add(PipelineFinding.error(jobId, "BUSINESS_RULE", obj, key,
                    key + " must be numeric. Found: '" + v + "'", null));
        }
    }
}


// ═══════════════════════════════════════════════════════════════════════════
// RULE: ACLineSegment
// ═══════════════════════════════════════════════════════════════════════════

@Component
class ACLineSegmentRule extends BaseRule {

    private static final String[] IMPEDANCE_ATTRS = {
        "ACLineSegment.r","ACLineSegment.x","ACLineSegment.bch",
        "ACLineSegment.r0","ACLineSegment.x0","ACLineSegment.b0ch",
        "ACLineSegment.gch","ACLineSegment.g0ch","ACLineSegment.x2"
    };

    @Override public boolean appliesTo(String t) { return "ACLineSegment".equals(t); }

    @Override
    public List<PipelineFinding> validate(CIMObject obj, String jobId) {
        List<PipelineFinding> f = new ArrayList<>();
        requireRef(obj, jobId, f, "ConductingEquipment.BaseVoltage",
                "ACLineSegment MUST reference a BaseVoltage.");
        requireRef(obj, jobId, f, "Equipment.EquipmentContainer",
                "ACLineSegment MUST reference an EquipmentContainer (Line).");

        // Conductor.length is required in all 4 impedance methods
        String len = obj.getAttribute("Conductor.length");
        if (len == null || len.isBlank()) {
            f.add(PipelineFinding.warning(jobId, "BUSINESS_RULE", obj,
                    "Conductor.length", "Conductor.length is required in all impedance methods.", null));
        } else requireNumeric(obj, jobId, f, "Conductor.length");

        // Check at least one impedance method is present
        boolean hasMethod1 = Arrays.stream(IMPEDANCE_ATTRS)
                .anyMatch(a -> { String v = obj.getAttribute(a); return v != null && !v.isBlank(); });
        boolean hasMethod2 = obj.hasReference("ACLineSegment.PerLengthImpedance");
        boolean hasMethod4 = obj.hasReference("ACLineSegment.WireAssemblyInfo");

        if (!hasMethod1 && !hasMethod2 && !hasMethod4) {
            f.add(PipelineFinding.warning(jobId, "BUSINESS_RULE", obj,
                    "impedance", "No impedance method found. Expected: direct r/x attrs OR "
                    + "PerLengthSequenceImpedance ref OR WireAssemblyInfo ref.", null));
        }

        for (String attr : IMPEDANCE_ATTRS) requireNumeric(obj, jobId, f, attr);
        return f;
    }
}


// ═══════════════════════════════════════════════════════════════════════════
// RULE: BaseVoltage
// ═══════════════════════════════════════════════════════════════════════════

@Component
class BaseVoltageRule extends BaseRule {
    @Override public boolean appliesTo(String t) { return "BaseVoltage".equals(t); }

    @Override
    public List<PipelineFinding> validate(CIMObject obj, String jobId) {
        List<PipelineFinding> f = new ArrayList<>();
        String v = obj.getAttribute("BaseVoltage.nominalVoltage");
        if (v == null || v.isBlank()) {
            f.add(PipelineFinding.error(jobId, "BUSINESS_RULE", obj,
                    "BaseVoltage.nominalVoltage", "nominalVoltage is required.", null));
        } else {
            try {
                double d = Double.parseDouble(v.trim());
                if (d <= 0) f.add(PipelineFinding.error(jobId, "BUSINESS_RULE", obj,
                        "BaseVoltage.nominalVoltage", "nominalVoltage must be > 0. Found: " + d, null));
                else f.add(PipelineFinding.info(jobId, "BUSINESS_RULE", obj,
                        "BaseVoltage.nominalVoltage", "OK → " + d + " kV", null));
            } catch (NumberFormatException e) {
                f.add(PipelineFinding.error(jobId, "BUSINESS_RULE", obj,
                        "BaseVoltage.nominalVoltage", "Not numeric: '" + v + "'", null));
            }
        }
        return f;
    }
}


// ═══════════════════════════════════════════════════════════════════════════
// RULE: PowerTransformer
// ═══════════════════════════════════════════════════════════════════════════

@Component
class PowerTransformerRule extends BaseRule {
    @Override public boolean appliesTo(String t) { return "PowerTransformer".equals(t); }

    @Override
    public List<PipelineFinding> validate(CIMObject obj, String jobId) {
        List<PipelineFinding> f = new ArrayList<>();
        if (!obj.hasReference("Equipment.EquipmentContainer")) {
            f.add(PipelineFinding.warning(jobId, "BUSINESS_RULE", obj,
                    "Equipment.EquipmentContainer",
                    "PowerTransformer should reference an EquipmentContainer (Substation).", null));
        }
        return f;
    }
}


// ═══════════════════════════════════════════════════════════════════════════
// RULE: Switch family
// Per PNNL-34946 Section 8: Fuse does NOT inherit from ProtectedSwitch
// ═══════════════════════════════════════════════════════════════════════════

@Component
class SwitchFamilyRule extends BaseRule {
    private static final Set<String> SWITCH_TYPES = Set.of(
        "Breaker","Recloser","LoadBreakSwitch","Disconnector",
        "Fuse","Sectionaliser","Jumper","GroundDisconnector","Switch"
    );

    @Override public boolean appliesTo(String t) { return SWITCH_TYPES.contains(t); }

    @Override
    public List<PipelineFinding> validate(CIMObject obj, String jobId) {
        List<PipelineFinding> f = new ArrayList<>();
        if (!obj.hasReference("ConductingEquipment.BaseVoltage")) {
            f.add(PipelineFinding.warning(jobId, "BUSINESS_RULE", obj,
                    "ConductingEquipment.BaseVoltage",
                    obj.getCimType() + " should reference a BaseVoltage.", null));
        }
        return f;
    }
}


// ═══════════════════════════════════════════════════════════════════════════
// RULE: EnergyConsumer / ConformLoad / NonConformLoad
// ═══════════════════════════════════════════════════════════════════════════

@Component
class EnergyConsumerRule extends BaseRule {
    private static final Set<String> LOAD_TYPES = Set.of(
        "EnergyConsumer","ConformLoad","NonConformLoad","StationSupply"
    );

    @Override public boolean appliesTo(String t) { return LOAD_TYPES.contains(t); }

    @Override
    public List<PipelineFinding> validate(CIMObject obj, String jobId) {
        List<PipelineFinding> f = new ArrayList<>();
        requireRef(obj, jobId, f, "ConductingEquipment.BaseVoltage",
                obj.getCimType() + " MUST reference a BaseVoltage.");
        requireNumeric(obj, jobId, f, "EnergyConsumer.p");
        requireNumeric(obj, jobId, f, "EnergyConsumer.q");
        return f;
    }
}


// ═══════════════════════════════════════════════════════════════════════════
// RULE: SynchronousMachine / AsynchronousMachine
// ═══════════════════════════════════════════════════════════════════════════

@Component
class RotatingMachineRule extends BaseRule {
    private static final Set<String> MACHINE_TYPES = Set.of(
        "SynchronousMachine","AsynchronousMachine"
    );

    @Override public boolean appliesTo(String t) { return MACHINE_TYPES.contains(t); }

    @Override
    public List<PipelineFinding> validate(CIMObject obj, String jobId) {
        List<PipelineFinding> f = new ArrayList<>();
        requireRef(obj, jobId, f, "ConductingEquipment.BaseVoltage",
                obj.getCimType() + " MUST reference a BaseVoltage.");
        if (!obj.hasReference("RotatingMachine.GeneratingUnit")
                && !obj.hasReference("SynchronousMachine.GeneratingUnit")) {
            f.add(PipelineFinding.warning(jobId, "BUSINESS_RULE", obj,
                    "GeneratingUnit",
                    obj.getCimType() + " should reference a GeneratingUnit.", null));
        }
        return f;
    }
}


// ═══════════════════════════════════════════════════════════════════════════
// RULE: Substation
// ═══════════════════════════════════════════════════════════════════════════

@Component
class SubstationRule extends BaseRule {
    @Override public boolean appliesTo(String t) { return "Substation".equals(t); }

    @Override
    public List<PipelineFinding> validate(CIMObject obj, String jobId) {
        List<PipelineFinding> f = new ArrayList<>();
        if (!obj.hasReference("Substation.Region")
                && !obj.hasReference("SubGeographicalRegion.Substations")) {
            f.add(PipelineFinding.warning(jobId, "BUSINESS_RULE", obj,
                    "Substation.Region",
                    "Substation should reference a SubGeographicalRegion.", null));
        }
        return f;
    }
}
