package com.cim.service;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.model.mongo.Neo4jExportJob;
import com.cim.model.mongo.ExportRequest;
import com.cim.model.mongo.ExportRequest.ExportMode;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.repository.Neo4jExportJobRepository;
import com.cim.repository.ValidationJobRepository;
import com.cim.util.MapKeySanitizer;
import org.neo4j.driver.*;
import org.neo4j.driver.exceptions.Neo4jException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
// @Async moved to Neo4jExportExecutor — separate bean to avoid proxy bypass
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 * Neo4j Export Service
 *
 * Exports CIM objects from MongoDB to Neo4j matching the EXISTING topology structure:
 *
 * NODE STRUCTURE (matches existing Neo4j):
 *   Labels:      :ACLineSegment only — matches existing Neo4j topology structure
 *   Properties:  ACLineSegment.r, ACLineSegment.x  ← DOT notation preserved
 *                version, orgId                    ← top-level
 *                mrid, rdfId, name, uri            ← standard fields
 *
 * RELATIONSHIP STRUCTURE (matches existing Neo4j):
 *   Type:        Terminal.ConductingEquipment      ← DOT notation preserved
 *   e.g.         (Terminal)-[:Terminal.ConductingEquipment]->(ACLineSegment)
 *
 * Java 11 + Neo4j Driver 4.4.x:
 *   session.writeTransaction(tx -> { ... return null; })
 *   No APOC. No yield. No switch expressions.
 */
@Service
public class Neo4jExportService {

    private static final Logger log = LoggerFactory.getLogger(Neo4jExportService.class);

    @Value("${cim.neo4j.export.batch-size:500}")
    private int batchSize;

    @Value("${cim.neo4j.export.create-constraints:true}")
    private boolean createConstraints;

    private final Driver                    driver;
    private final MongoTemplate             mongo;
    private final CimObjectRecordRepository objectRepo;
    private final Neo4jExportJobRepository  exportRepo;
    private final ValidationJobRepository   jobRepo;

    // Injected via setter to avoid circular dependency
    // Neo4jExportExecutor depends on Neo4jExportService, so we use @Autowired setter
    private Neo4jExportExecutor executor;

    @org.springframework.beans.factory.annotation.Autowired
    public void setExecutor(Neo4jExportExecutor executor) {
        this.executor = executor;
    }

    public Neo4jExportService(Driver driver, MongoTemplate mongo,
                               CimObjectRecordRepository objectRepo,
                               Neo4jExportJobRepository exportRepo,
                               ValidationJobRepository jobRepo) {
        this.driver     = driver;
        this.mongo      = mongo;
        this.objectRepo = objectRepo;
        this.exportRepo = exportRepo;
        this.jobRepo    = jobRepo;
    }

    // ── Start export ──────────────────────────────────────────────────────

    public Neo4jExportJob startExport(ExportRequest req) {
        String exportId = UUID.randomUUID().toString();
        String version = jobRepo.findByJobId(req.getJobId())
                .map(j -> j.getNetworkVersion() != null ? j.getNetworkVersion() : "unknown")
                .orElse("unknown");
        String orgId = jobRepo.findByJobId(req.getJobId())
                .map(j -> j.getOrgId() != null ? j.getOrgId() : "")
                .orElse("");

        Neo4jExportJob job = new Neo4jExportJob(
                exportId, req.getJobId(), version, orgId, req.getMode().name());
        exportRepo.save(job);
        // Call executor (different bean) so Spring proxy triggers @Async
        // This is truly asynchronous — returns immediately, client polls status
        executor.runAsync(req, job);
        return job;
    }

    /**
     * Called by Neo4jExportExecutor.runAsync() on a separate thread.
     * public so executor can call it. NOT @Async itself — async is on executor.
     */
    public void runExport(ExportRequest req, Neo4jExportJob job) {
        try {
            job.setStatus("RUNNING");
            exportRepo.save(job);
            long start = System.currentTimeMillis();

            if (createConstraints) ensureConstraints();
            if (req.isClearFirst()) clearExistingNodes(job.getNetworkVersion(), job.getOrgId());

            int[] counts = exportAllObjects(req, job);

            job.setStatus("DONE");
            job.setNodesExported(counts[0]);
            job.setRelsExported(counts[1]);
            job.setCompletedAt(Instant.now());
            job.setProcessingMs(System.currentTimeMillis() - start);
            exportRepo.save(job);

            log.info("Neo4j export done: exportId={} version={} orgId={} nodes={} rels={} in {}ms",
                    job.getExportId(), job.getNetworkVersion(), job.getOrgId(),
                    counts[0], counts[1], System.currentTimeMillis() - start);

        } catch (Exception e) {
            log.error("Neo4j export failed: {}", e.getMessage(), e);
            job.setStatus("FAILED");
            job.setErrorMessage(e.getMessage());
            job.setCompletedAt(Instant.now());
            exportRepo.save(job);
        }
    }

    // ── Constraints / Indexes ─────────────────────────────────────────────

    private void ensureConstraints() {
        // Each DDL statement needs its OWN session+transaction in Neo4j
        // Mixing multiple CREATE INDEX in one transaction causes a lock hang
        String[] indexes = {
            // nodeKey — composite unique identifier for MERGE
            // Cannot use a label here since each node has its own cimType label
            // Use lookup index on nodeKey across all nodes (no label filter)
            "CREATE LOOKUP INDEX node_lookup IF NOT EXISTS FOR (n) ON EACH labels(n)",
            // We rely on Neo4j's built-in node label index + property scan
            // The nodeKey property is always unique per node — no collisions
        };
        for (String ddl : indexes) {
            try (Session s = driver.session()) {
                s.run(ddl);  // DDL — no explicit transaction needed, auto-committed
                log.debug("Index ensured: {}", ddl.substring(13, 30));
            } catch (Exception e) {
                log.warn("Index note (may already exist): {}", e.getMessage());
            }
        }
        log.info("Neo4j indexes checked");
    }

    // ── Clear existing nodes for version + orgId ──────────────────────────

    private void clearExistingNodes(String version, String orgId) {
        // DETACH DELETE all at once on 1.9M nodes causes transaction timeout
        // Use batched delete: 1000 nodes per transaction until none remain
        log.info("Clearing Neo4j nodes for version={} orgId={} (batched)", version, orgId);
        long totalDeleted = 0;
        int  batchDeleteSize = 1000;
        while (true) {
            try (Session s = driver.session()) {
                // Returns count of deleted nodes in this batch
                org.neo4j.driver.Result result = s.writeTransaction(tx ->
                    tx.run(
                        "MATCH (n {version: $v, orgId: $o}) " +
                        "WITH n LIMIT $limit " +
                        "DETACH DELETE n " +
                        "RETURN count(n) AS deleted",
                        Values.parameters("v", version, "o", orgId,
                                          "limit", batchDeleteSize))
                );
                long deleted = result.single().get("deleted").asLong();
                totalDeleted += deleted;
                if (deleted == 0) break; // no more nodes to delete
                log.info("Cleared batch: {} nodes (total so far: {})", deleted, totalDeleted);
            } catch (Exception e) {
                log.warn("Clear batch error: {}", e.getMessage());
                break;
            }
        }
        log.info("Cleared {} Neo4j nodes for version={} orgId={}", totalDeleted, version, orgId);
    }

    // ── Main export loop ──────────────────────────────────────────────────

    private int[] exportAllObjects(ExportRequest req, Neo4jExportJob job) {
        int totalNodes = 0, totalRels = 0, page = 0;

        // ── PASS 1: Export ALL nodes first ────────────────────────────
        // All nodes must exist before relationships are created.
        // Previously: nodes + rels were exported together per page batch.
        // Problem: ACLineSegment on page 5, BaseVoltage on page 12 →
        //   when page 5 ran MATCH for BaseVoltage it didn't exist yet
        //   → MATCH returned nothing → relationship silently dropped.
        // Fix: two separate passes guarantees all targets exist first.
        log.info("Neo4j export Pass 1 — nodes starting");
        while (true) {
            Page<CimObjectRecord> pageResult = getPage(req, page);
            if (pageResult.isEmpty()) break;

            List<CimObjectRecord> records = pageResult.getContent();
            totalNodes += writeNodeBatch(records,
                    job.getNetworkVersion(), job.getOrgId());

            if (page % 10 == 0) {
                log.info("Neo4j node progress: page={} nodes={}", page, totalNodes);
                job.setNodesExported(totalNodes);
                exportRepo.save(job);
            }
            page++;
        }
        log.info("Neo4j export Pass 1 complete — {} nodes", totalNodes);

        // ── PASS 2: Export ALL relationships ──────────────────────────
        // All nodes now exist in Neo4j → every MATCH will succeed.
        log.info("Neo4j export Pass 2 — relationships starting");
        page = 0;
        while (true) {
            Page<CimObjectRecord> pageResult = getPage(req, page);
            if (pageResult.isEmpty()) break;

            List<CimObjectRecord> records = pageResult.getContent();
            List<Map<String, Object>> relBatch = buildRelBatch(records);
            if (!relBatch.isEmpty()) {
                totalRels += writeRelBatch(relBatch);
            }

            if (page % 10 == 0) {
                log.info("Neo4j rel progress: page={} rels={}", page, totalRels);
                job.setRelsExported(totalRels);
                exportRepo.save(job);
            }
            page++;
        }
        log.info("Neo4j export Pass 2 complete — {} rels", totalRels);

        return new int[]{totalNodes, totalRels};
    }

    // ── Node batch write ──────────────────────────────────────────────────
    /**
     * Writes nodes matching EXISTING Neo4j topology structure.
     *
     * Each node gets:
     *   Label:      cimType only (e.g. :ACLineSegment)
     *   Properties: dot-notation attribute keys (ACLineSegment.r, NOT ACLineSegment_r)
     *               version and orgId as top-level properties
     *               uri = source file reference
     *
     * Groups by cimType so each Cypher has the label statically.
     * No APOC required.
     */
    private int writeNodeBatch(List<CimObjectRecord> records,
                                String version, String orgId) {
        if (records.isEmpty()) return 0;

        // Group by cimType
        Map<String, List<Map<String, Object>>> byType = new LinkedHashMap<>();
        for (CimObjectRecord rec : records) {
            String label = sanitizeLabel(rec.getCimType());
            Map<String, Object> props = toNodeProps(rec, version, orgId);
            byType.computeIfAbsent(label, k -> new ArrayList<>()).add(props);
        }

        int written = 0;
        // FIX: Reuse ONE session for all cimType groups in this batch
        // Previously: new session per cimType = connection overhead per type
        try (Session s = driver.session()) {
            for (Map.Entry<String, List<Map<String, Object>>> entry : byType.entrySet()) {
                String label = entry.getKey();
                List<Map<String, Object>> batch = entry.getValue();

                // FIX: MERGE on rdfId ONLY — single indexed property
                // rdfId has index cim_rdfid_idx → O(log n) lookup regardless of size
                // Previously MERGE on {mrid, version, orgId} = 3-prop scan
                // = O(n) degradation as node count grows past 50K
                // MERGE on nodeKey (rdfId|version|orgId) — single indexed property
                // Prevents same rdfId from different versions colliding in Neo4j.
                // e.g. DB140/_abc123 and DB141/_abc123 → two separate nodes.
                String cypher =
                    "UNWIND $batch AS p " +
                    "MERGE (n:" + label + " {nodeKey: p.nodeKey}) " +
                    "SET n += p";

                final String fc = cypher;
                final List<Map<String, Object>> fb = batch;
                try {
                    s.writeTransaction(tx -> {
                        tx.run(fc, Values.parameters("batch", fb));
                        return null;
                    });
                    written += batch.size();
                } catch (Neo4jException e) {
                    log.warn("Node write failed for {}: {}", label, e.getMessage());
                }
            }
        } catch (Exception e) {
            log.warn("Session error in writeNodeBatch: {}", e.getMessage());
        }
        return written;
    }

    // ── Relationship batch ────────────────────────────────────────────────
    /**
     * Relationships use DOT notation to match existing topology:
     *   (Terminal)-[:Terminal.ConductingEquipment]->(ACLineSegment)
     *   (ACLineSegment)-[:Equipment.EquipmentContainer]->(Line)
     *
     * The relationship type is the original reference key (e.g. "Terminal.ConductingEquipment")
     * with only characters that are invalid in Neo4j relationship types replaced.
     * Neo4j DOES support dots in relationship types with backtick escaping.
     */
    private List<Map<String, Object>> buildRelBatch(List<CimObjectRecord> records) {
        List<Map<String, Object>> relBatch = new ArrayList<>();
        for (CimObjectRecord rec : records) {
            if (rec.getResolvedRefIds() == null || rec.getResolvedRefIds().isEmpty()) continue;

            String v = rec.getVersion() != null ? rec.getVersion() : "";
            String o = rec.getOrgId()   != null ? rec.getOrgId()   : "";
            String srcRdfId = rec.getRdfId() != null ? rec.getRdfId() : "";

            // Decode keys: U+FF0E → dot
            Map<String, String> decoded = MapKeySanitizer.decodeKeys(rec.getResolvedRefIds());
            for (Map.Entry<String, String> e : decoded.entrySet()) {
                String tgtRdfId = e.getValue() != null ? e.getValue() : "";
                Map<String, Object> rel = new LinkedHashMap<>();
                rel.put("sourceRdfId",  srcRdfId);
                rel.put("targetRdfId",  tgtRdfId);
                // nodeKey matches the MERGE key used when creating nodes
                // version+orgId scope ensures DB140 rels don't connect to DB141 nodes
                rel.put("sourceNodeKey", srcRdfId + "|" + v + "|" + o);
                rel.put("targetNodeKey", tgtRdfId + "|" + v + "|" + o);
                rel.put("relType",       e.getKey());
                rel.put("version",       v);
                rel.put("orgId",         o);
                relBatch.add(rel);
            }
        }
        return relBatch;
    }

    private int writeRelBatch(List<Map<String, Object>> batch) {
        if (batch.isEmpty()) return 0;

        // Group by relationship type
        Map<String, List<Map<String, Object>>> byRel = new LinkedHashMap<>();
        for (Map<String, Object> r : batch) {
            String relType = (String) r.get("relType");
            byRel.computeIfAbsent(relType, k -> new ArrayList<>()).add(r);
        }

        int total = 0;
        for (Map.Entry<String, List<Map<String, Object>>> e : byRel.entrySet()) {
            String relType      = e.getKey();
            List<Map<String, Object>> relBatch = e.getValue();

            // Backtick-escape relationship type to allow dot notation
            // This produces: MERGE (src)-[:`Terminal.ConductingEquipment`]->(tgt)
            // matching exactly what is in your existing Neo4j topology
            String escapedType  = "`" + relType.replace("`", "") + "`";
            // MATCH using nodeKey (rdfId|version|orgId) — version-scoped
            // This ensures relationships only connect nodes of the SAME version.
            // src and tgt from DB140 connect to each other.
            // src and tgt from DB141 connect to each other.
            // No cross-version relationships created.
            String cypher =
                "UNWIND $batch AS r " +
                "MATCH (src {nodeKey: r.sourceNodeKey}) " +
                "MATCH (tgt {nodeKey: r.targetNodeKey}) " +
                "MERGE (src)-[:" + escapedType + " {version: r.version, orgId: r.orgId}]->(tgt)";

            try (Session s = driver.session()) {
                final String fc = cypher;
                final List<Map<String, Object>> fb = relBatch;
                s.writeTransaction(tx -> {
                    tx.run(fc, Values.parameters("batch", fb));
                    return null;
                });
                total += relBatch.size();
            } catch (Neo4jException ex) {
                log.warn("Rel write failed for {}: {}", relType, ex.getMessage());
            }
        }
        return total;
    }

    // ── Node properties — matching existing Neo4j structure ───────────────

    private Map<String, Object> toNodeProps(CimObjectRecord rec,
                                             String version, String orgId) {
        Map<String, Object> props = new LinkedHashMap<>();

        String v = version != null ? version : "";
        String o = orgId   != null ? orgId   : "";
        String r = rec.getRdfId() != null ? rec.getRdfId() : "";

        // nodeKey — composite unique identifier: rdfId|version|orgId
        // Used as the MERGE key so same rdfId in different versions
        // creates SEPARATE nodes, not an overwrite of the existing node.
        // Single string property = single index lookup = O(log n) performance.
        props.put("nodeKey", r + "|" + v + "|" + o);

        // Standard identity fields
        props.put("mrid",    rec.getMrid()   != null ? rec.getMrid()   : r);
        props.put("rdfId",   r);
        props.put("name",    rec.getName()   != null ? rec.getName()   : "");
        props.put("cimType", rec.getCimType()!= null ? rec.getCimType(): "Unknown");

        // version and orgId as TOP-LEVEL properties (matches existing topology)
        props.put("version", v);
        props.put("orgId",   o);

        // uri — source file reference
        props.put("uri", rec.getSourceFile() != null ? rec.getSourceFile() : "");

        // CIM attributes — USE DOT NOTATION to match existing topology
        // EXISTING:  ACLineSegment.r = "0.11109"   ← dot preserved
        // NOT:       ACLineSegment_r = "0.11109"   ← underscore (wrong)
        if (rec.getAttributes() != null) {
            // decodeKeys restores U+FF0E → dot giving "ACLineSegment.r" etc.
            Map<String, String> decoded = MapKeySanitizer.decodeKeys(rec.getAttributes());
            for (Map.Entry<String, String> e : decoded.entrySet()) {
                // Skip if value is null or empty to keep nodes clean
                if (e.getKey() != null && e.getValue() != null && !e.getValue().isBlank()) {
                    props.put(e.getKey(), e.getValue());
                }
            }
        }

        return props;
    }

    // ── getPage — Java 11 if/else, no switch expression ──────────────────

    private Page<CimObjectRecord> getPage(ExportRequest req, int page) {
        PageRequest pr = PageRequest.of(page, batchSize);

        if (req.getMode() == ExportMode.ALL) {
            return objectRepo.findByJobId(req.getJobId(), pr);

        } else if (req.getMode() == ExportMode.PHYSICAL_ONLY) {
            Query q = new Query(Criteria.where("jobId").is(req.getJobId())
                    .and("category").is("PHYSICAL")).with(pr);
            List<CimObjectRecord> list = mongo.find(q, CimObjectRecord.class);
            return new org.springframework.data.domain.PageImpl<>(list, pr, list.size());

        } else if (req.getMode() == ExportMode.REQUIRED_ONLY) {
            Query q = new Query(Criteria.where("jobId").is(req.getJobId())
                    .and("isRequired").is(true)).with(pr);
            List<CimObjectRecord> list = mongo.find(q, CimObjectRecord.class);
            return new org.springframework.data.domain.PageImpl<>(list, pr, list.size());

        } else if (req.getMode() == ExportMode.CUSTOM) {
            Query q = new Query(Criteria.where("jobId").is(req.getJobId())
                    .and("cimType").in(req.getCimTypes())).with(pr);
            List<CimObjectRecord> list = mongo.find(q, CimObjectRecord.class);
            return new org.springframework.data.domain.PageImpl<>(list, pr, list.size());

        } else if (req.getMode() == ExportMode.TOPOLOGY) {
            // PHYSICAL equipment + key LOGICAL connectors for complete graph
            // Terminal + ConnectivityNode are needed so equipment relationships
            // can be traversed in Neo4j. Without them, ACLineSegment has
            // resolved refs to Terminal but Terminal nodes don't exist
            // → MATCH fails → relationship silently dropped.
            java.util.List<String> topTypes = java.util.Arrays.asList(
                "Terminal", "ConnectivityNode", "TopologicalNode", "TopologicalIsland"
            );
            Query q = new Query(
                new Criteria().orOperator(
                    Criteria.where("jobId").is(req.getJobId())
                             .and("category").is("PHYSICAL"),
                    Criteria.where("jobId").is(req.getJobId())
                             .and("cimType").in(topTypes)
                )
            ).with(pr);
            List<CimObjectRecord> list = mongo.find(q, CimObjectRecord.class);
            return new org.springframework.data.domain.PageImpl<>(list, pr, list.size());

        } else {
            return objectRepo.findByJobId(req.getJobId(), pr);
        }
    }

    // ── Label sanitizer ───────────────────────────────────────────────────

    /** Sanitize label — letters/digits/underscore only */
    private String sanitizeLabel(String t) {
        if (t == null || t.isBlank()) return "Unknown";
        return t.replaceAll("[^A-Za-z0-9_]", "_");
    }

    // ── Cleanup existing :CIMObject labels ───────────────────────────────

    /**
     * Removes the :CIMObject secondary label from all existing nodes.
     * Call once via POST /api/admin/neo4j/cleanup-labels after deploying this fix.
     * This makes existing nodes consistent with the new single-label structure.
     *
     * Cypher equivalent:
     *   MATCH (n:CIMObject) REMOVE n:CIMObject
     */
    public long removeCimObjectLabels() {
        long total = 0;
        while (true) {
            try (Session s = driver.session()) {
                org.neo4j.driver.Result r = s.writeTransaction(tx ->
                    tx.run("MATCH (n:CIMObject) " +
                           "WITH n LIMIT 1000 " +
                           "REMOVE n:CIMObject " +
                           "RETURN count(n) AS removed")
                );
                long removed = r.single().get("removed").asLong();
                total += removed;
                if (removed == 0) break;
                log.info("Removed :CIMObject label from {} nodes (total: {})", removed, total);
            } catch (Exception e) {
                log.warn("Label removal error: {}", e.getMessage());
                break;
            }
        }
        log.info("Cleanup complete — :CIMObject label removed from {} nodes", total);
        return total;
    }

    // ── Status ────────────────────────────────────────────────────────────

    public Optional<Neo4jExportJob> getExportStatus(String exportId) {
        return exportRepo.findByExportId(exportId);
    }

    public List<Neo4jExportJob> getRecentExports() {
        return exportRepo.findTop10ByOrderByStartedAtDesc();
    }
}
