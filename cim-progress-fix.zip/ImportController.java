package com.cim.controller;

import com.cim.model.mongo.ValidationJob;
import com.cim.repository.ValidationJobRepository;
import com.cim.service.ImportService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ImportController {

    private static final long LARGE = 50L * 1024 * 1024;

    private final ImportService           importService;
    private final ValidationJobRepository jobRepo;

    public ImportController(ImportService importService,
                              ValidationJobRepository jobRepo) {
        this.importService = importService;
        this.jobRepo       = jobRepo;
    }

    /**
     * POST /api/import
     * Params: file (required), networkVersion (required), X-User header
     *
     * Duplicate detection: same SHA-256 hash + same version → 409
     * Small file (≤50MB): synchronous → returns when RESOLVED
     * Large file (>50MB): async → returns 202 with jobId for polling
     */
    @PostMapping("/import")
    public ResponseEntity<?> importFile(
            @RequestParam("file") MultipartFile file,
            @RequestParam("networkVersion") String networkVersion,
            @RequestHeader(value = "X-User", defaultValue = "anonymous") String user) {

        if (file.isEmpty())
            return ResponseEntity.badRequest().body(Map.of("error", "File is empty."));
        if (networkVersion == null || networkVersion.isBlank())
            return ResponseEntity.badRequest().body(Map.of(
                "error", "networkVersion is required.",
                "hint",  "e.g. '2024-Q1', 'SUMMER-PEAK-v2'"));

        String version = networkVersion.trim();
        byte[] bytes; String hash;
        try { bytes = file.getBytes(); hash = ImportService.sha256(bytes); }
        catch (Exception e) { return ResponseEntity.internalServerError()
                .body(Map.of("error", "Cannot read file: " + e.getMessage())); }

        // Duplicate check
        List<String> active = List.of("PENDING","RUNNING","RESOLVED");
        List<ValidationJob> dup = jobRepo.findByFileHashAndNetworkVersionAndStatusIn(
                hash, version, active);
        if (!dup.isEmpty()) {
            ValidationJob ex = dup.get(0);
            return ResponseEntity.status(409).body(Map.of(
                "error",          "Duplicate import rejected.",
                "reason",         "Same file+version already " + ex.getStatus() + ".",
                "existingJobId",  ex.getJobId(),
                "existingStatus", ex.getStatus(),
                "hint",           "Use a different networkVersion or DELETE the existing job."
            ));
        }

        String format = detectFormat(bytes, file.getOriginalFilename());
        String jobId  = UUID.randomUUID().toString();
        ValidationJob job = new ValidationJob(jobId, file.getOriginalFilename(),
                format, user, version);
        job.setFileHash(hash);
        jobRepo.save(job);

        try {
            if (file.getSize() <= LARGE) {
                importService.processAndResolve(
                        new java.io.ByteArrayInputStream(bytes),
                        file.getOriginalFilename(), format, jobId, version);
                ValidationJob done = jobRepo.findByJobId(jobId).orElse(job);
                return ResponseEntity.ok(Map.of(
                    "jobId", jobId, "status", done.getStatus(),
                    "networkVersion", version, "totalObjects", done.getTotalObjects(),
                    "links", links(jobId)));
            } else {
                importService.processAndResolveAsync(
                        file.getInputStream(), file.getOriginalFilename(),
                        format, jobId, version);
                return ResponseEntity.accepted().body(Map.of(
                    "jobId", jobId, "status", "PROCESSING",
                    "networkVersion", version,
                    "fileSizeMb", String.format("%.1f", file.getSize() / 1048576.0),
                    "links", links(jobId)));
            }
        } catch (Exception e) {
            job.setStatus("FAILED"); job.setErrorMessage(e.getMessage());
            jobRepo.save(job);
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage(), "jobId", jobId));
        }
    }

    @GetMapping("/jobs")
    public ResponseEntity<?> listJobs(
            @RequestParam(required = false) String networkVersion) {
        return ResponseEntity.ok(networkVersion != null && !networkVersion.isBlank()
                ? jobRepo.findByNetworkVersion(networkVersion.trim())
                : jobRepo.findTop10ByOrderBySubmittedAtDesc());
    }

    @GetMapping("/jobs/{jobId}")
    public ResponseEntity<?> getJob(@PathVariable String jobId) {
        return jobRepo.findByJobId(jobId).map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/jobs/{jobId}/progress")
    public ResponseEntity<?> progress(@PathVariable String jobId) {
        return importService.getTracker(jobId)
                .map(t -> ResponseEntity.ok(t.snapshot()))
                .orElseGet(() -> jobRepo.findByJobId(jobId)
                        .map(j -> ResponseEntity.ok(Map.of(
                            "jobId",           jobId,
                            "status",          j.getStatus(),
                            "networkVersion",  j.getNetworkVersion() != null ? j.getNetworkVersion() : "",
                            "totalObjects",    j.getTotalObjects(),
                            "physicalObjects", j.getPhysicalObjects(),
                            "logicalObjects",  j.getLogicalObjects(),
                            // processingMs is fixed at completion — never grows
                            "elapsedMs",       j.getProcessingMs(),
                            "elapsedFormatted",formatMs(j.getProcessingMs()),
                            "finished",        true,
                            "stage",           j.getStatus()
                        ))).orElse(ResponseEntity.notFound().build()));
    }

    @DeleteMapping("/jobs/{jobId}")
    public ResponseEntity<?> deleteJob(@PathVariable String jobId) {
        return jobRepo.findByJobId(jobId).map(j -> {
            jobRepo.delete(j);
            return ResponseEntity.ok(Map.of(
                "message", "Job " + jobId + " deleted.",
                "hint",    "You can now re-import the same file+version."));
        }).orElse(ResponseEntity.notFound().build());
    }

    private String formatMs(long ms) {
        long s=ms/1000, h=s/3600, m=(s%3600)/60, sec=s%60;
        if(h>0) return h+"h "+m+"m "+sec+"s";
        if(m>0) return m+"m "+sec+"s";
        return sec+"s";
    }

    private String detectFormat(byte[] bytes, String name) {
        String h = new String(bytes, 0, Math.min(512, bytes.length));
        if (h.contains("rdf:RDF") || h.contains("xmlns:cim")) return "RDF_XML";
        if (h.contains("@context") || h.contains("@graph")) return "JSON_LD";
        if (name != null && name.toLowerCase().endsWith(".csv")) return "MILSOFT_CSV";
        return "RDF_XML";
    }

    private Map<String, String> links(String jobId) {
        return Map.of(
            "progress",  "/api/jobs/" + jobId + "/progress",
            "objects",   "/api/jobs/" + jobId + "/objects",
            "stats",     "/api/jobs/" + jobId + "/objects/stats",
            "required",  "/api/jobs/" + jobId + "/objects/required/summary",
            "pathIssues","/api/jobs/" + jobId + "/objects/path-issues"
        );
    }
}
