package com.cim.service;

import com.cim.model.cim.CIMObject;
import com.cim.model.mongo.CimObjectRecord;
import com.cim.model.mongo.ValidationJob;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.repository.ValidationJobRepository;
import com.cim.streaming.ProgressTracker;
import com.cim.streaming.StreamingRdfXmlParser;
import com.cim.streaming.StreamingReferenceResolver;
import com.cim.util.MapKeySanitizer;
import com.cim.validation.registry.CIMHierarchyRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

/**
 * ImportService — parse → save → resolve references. No validation.
 *
 * Flow:
 *   1. Save file to disk (/tmp/cim-uploads/)
 *   2. Stream parse → CIMObjects
 *   3. Save all objects to MongoDB (with version + isRequired)
 *   4. Resolve cross-references via MongoDB $lookup aggregation
 *   5. Status = RESOLVED
 */
@Service
public class ImportService {

    private static final Logger log = LoggerFactory.getLogger(ImportService.class);

    @Value("${cim.streaming.chunk-size:500}")
    private int chunkSize;

    @Value("${cim.upload.temp-dir:/tmp/cim-uploads}")
    private String tempDir;

    @Value("${cim.streaming.log-every:10000}")
    private int logEvery;

    private final StreamingRdfXmlParser      rdfParser;
    private final StreamingReferenceResolver referenceResolver;
    private final CimObjectRecordRepository  objectRepo;
    private final ValidationJobRepository    jobRepo;
    private final CIMHierarchyRegistry       registry;

    private final Map<String, ProgressTracker> trackers = new ConcurrentHashMap<>();

    public ImportService(StreamingRdfXmlParser rdfParser,
                          StreamingReferenceResolver referenceResolver,
                          CimObjectRecordRepository objectRepo,
                          ValidationJobRepository jobRepo,
                          CIMHierarchyRegistry registry) {
        this.rdfParser         = rdfParser;
        this.referenceResolver = referenceResolver;
        this.objectRepo        = objectRepo;
        this.jobRepo           = jobRepo;
        this.registry          = registry;
    }

    // ── Synchronous (small files) ──────────────────────────────────────────

    public void processAndResolve(InputStream in, String fileName,
                                   String format, String jobId,
                                   String networkVersion) throws Exception {
        ProgressTracker progress = new ProgressTracker(jobId, logEvery);
        trackers.put(jobId, progress);
        execute(in, fileName, format, jobId, networkVersion, progress);
    }

    // ── Async (large files) ───────────────────────────────────────────────

    @Async
    public CompletableFuture<Void> processAndResolveAsync(InputStream in,
                                                           String fileName,
                                                           String format,
                                                           String jobId,
                                                           String networkVersion) {
        ProgressTracker progress = new ProgressTracker(jobId, logEvery);
        trackers.put(jobId, progress);
        try {
            execute(in, fileName, format, jobId, networkVersion, progress);
        } catch (Exception e) {
            log.error("Async import failed: {}", e.getMessage());
        }
        return CompletableFuture.completedFuture(null);
    }

    // ── Core pipeline ─────────────────────────────────────────────────────

    private void execute(InputStream in, String fileName, String format,
                          String jobId, String networkVersion,
                          ProgressTracker progress) throws Exception {

        ValidationJob job = jobRepo.findByJobId(jobId).orElseThrow();
        job.setStatus("RUNNING");
        job.setNetworkVersion(networkVersion);
        jobRepo.save(job);

        try {
            // Step 1 & 2: Stream parse + save to MongoDB
            progress.setStage(ProgressTracker.Stage.STREAMING_PARSE,
                    "Streaming " + format + "...");

            Path tempFile = saveToDisk(in, jobId, fileName);
            try {
                streamAndSave(tempFile, fileName, format, jobId,
                              networkVersion, progress);
            } finally {
                deleteTempFile(tempFile);
            }

            // Step 3: Resolve cross-references
            progress.setStage(ProgressTracker.Stage.RESOLVING_REFERENCES,
                    "Resolving cross-references...");
            long resolved = referenceResolver.resolveReferencesInMongo(
                    jobId, chunkSize, progress);
            progress.log("References resolved: " + resolved);

            // Done
            job = jobRepo.findByJobId(jobId).orElse(job);
            job.setStatus("RESOLVED");
            job.setTotalObjects((int) progress.getParsed());
            job.setCompletedAt(Instant.now());
            job.setProcessingMs(System.currentTimeMillis()
                    - job.getSubmittedAt().toEpochMilli());
            jobRepo.save(job);
            progress.done();

            log.info("Import done: job={} version={} objects={} resolved={}",
                    jobId, networkVersion, progress.getParsed(), resolved);

        } catch (Exception e) {
            log.error("Import failed job={}: {}", jobId, e.getMessage());
            job = jobRepo.findByJobId(jobId).orElse(job);
            job.setStatus("FAILED");
            job.setErrorMessage(e.getMessage());
            job.setCompletedAt(Instant.now());
            jobRepo.save(job);
            progress.fail(e.getMessage());
            throw e;
        }
    }

    // ── Stream parse + bulk save ───────────────────────────────────────────

    private void streamAndSave(Path tempFile, String fileName, String format,
                                 String jobId, String networkVersion,
                                 ProgressTracker progress) throws Exception {
        List<CimObjectRecord> batch = new ArrayList<>(chunkSize);

        try (InputStream fis = Files.newInputStream(tempFile)) {
            rdfParser.stream(fis, fileName, obj -> {
                batch.add(toRecord(obj, jobId, networkVersion));
                progress.incrementParsed();
                if (batch.size() >= chunkSize) {
                    objectRepo.saveAll(new ArrayList<>(batch));
                    progress.incrementSaved(batch.size());
                    batch.clear();
                }
            });
        }
        if (!batch.isEmpty()) {
            objectRepo.saveAll(batch);
            progress.incrementSaved(batch.size());
        }
        progress.log("Stream complete. Total objects saved: " + progress.getParsed());
    }

    // ── Record builder ────────────────────────────────────────────────────

    private CimObjectRecord toRecord(CIMObject obj, String jobId,
                                      String networkVersion) {
        CimObjectRecord r = new CimObjectRecord();
        r.setJobId(jobId);
        r.setRdfId(obj.getRdfId());
        r.setMrid(obj.getMrid());
        r.setCimType(obj.getCimType());
        r.setName(obj.getName());

        String category = isLogical(obj.getCimType()) ? "LOGICAL" : "PHYSICAL";
        r.setCategory(category);
        r.setRequired("PHYSICAL".equals(category)); // default: PHYSICAL=true, LOGICAL=false

        r.setSourceFormat(obj.getSourceFormat());
        r.setSourceFile(obj.getSourceFile());
        r.setOrgId(obj.getOrgId());
        r.setVersion(networkVersion);
        r.setAttributes(MapKeySanitizer.encodeKeys(obj.getAttributes()));
        r.setReferences(MapKeySanitizer.encodeKeys(obj.getReferences()));
        r.setCreatedAt(Instant.now());
        return r;
    }

    // ── Progress ──────────────────────────────────────────────────────────

    public Optional<ProgressTracker> getTracker(String jobId) {
        return Optional.ofNullable(trackers.get(jobId));
    }

    // ── Disk helpers ──────────────────────────────────────────────────────

    private Path saveToDisk(InputStream in, String jobId,
                             String fileName) throws IOException {
        Path dir = Paths.get(tempDir);
        Files.createDirectories(dir);
        Path file = dir.resolve(jobId + "_" + fileName);
        Files.copy(in, file, StandardCopyOption.REPLACE_EXISTING);
        return file;
    }

    private void deleteTempFile(Path p) {
        try { Files.deleteIfExists(p); } catch (IOException ignored) {}
    }

    // ── Category helpers ──────────────────────────────────────────────────

    private static final Set<String> LOGICAL_TYPES = Set.of(
        "ConnectivityNode","TopologicalNode","TopologicalIsland","Terminal",
        "ACDCTerminal","DCTerminal","Measurement","Accumulator","Analog","Discrete",
        "AccumulatorValue","AnalogValue","DiscreteValue","LoadGroup",
        "ConformLoadGroup","NonConformLoadGroup","LoadArea","SubLoadArea",
        "EnergyArea","RegulatingControl","RegulationSchedule","TapChangerControl",
        "BranchGroup","Name","NameType","SvVoltage","SvPowerFlow","SvShuntCompensatorSections",
        "SvTapStep","SvStatus","TopologicalIsland","BusNameMarker"
    );

    public static boolean isLogical(String cimType) {
        if (cimType == null) return false;
        return LOGICAL_TYPES.contains(cimType)
                || cimType.endsWith("Kind") || cimType.endsWith("Type")
                || cimType.endsWith("Value") || cimType.startsWith("Sv");
    }
}
