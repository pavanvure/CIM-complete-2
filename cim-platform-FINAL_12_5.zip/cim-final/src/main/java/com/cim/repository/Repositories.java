package com.cim.repository;

import com.cim.model.mongo.*;
import com.cim.model.mongo.NamespaceConfig;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CimClassRepository
        extends MongoRepository<CimClassDefinition, String> {
    Optional<CimClassDefinition> findByClassName(String className);
    List<CimClassDefinition> findByCategory(String category);
    List<CimClassDefinition> findByCimVersion(String version);
    void deleteAllByCimVersion(String version);
}

@Repository
interface ValidationJobRepository
        extends MongoRepository<ValidationJob, String> {
    Optional<ValidationJob> findByJobId(String jobId);
    List<ValidationJob> findTop10ByOrderBySubmittedAtDesc();
    List<ValidationJob> findByNetworkVersion(String networkVersion);
    List<ValidationJob> findByFileHashAndNetworkVersionAndStatusIn(
            String hash, String version, List<String> statuses);
    List<ValidationJob> findByFileNameAndNetworkVersionAndStatusIn(
            String fileName, String version, List<String> statuses);
    List<ValidationJob> findByStatus(String status);
    List<ValidationJob> findByOrgId(String orgId);
    List<ValidationJob> findByNetworkVersionAndOrgId(String version, String orgId);
    List<ValidationJob> findByNetworkVersionAndOrgIdAndStatus(
            String version, String orgId, String status);
}

@Repository
interface CimObjectRecordRepository
        extends MongoRepository<CimObjectRecord, String> {
    Page<CimObjectRecord>  findByJobId(String jobId, Pageable p);
    List<CimObjectRecord>  findByJobIdAndCimType(String jobId, String cimType);
    List<CimObjectRecord>  findByJobIdAndCategory(String jobId, String category);
    List<CimObjectRecord>  findByJobIdAndIsRequired(String jobId, boolean req);
    List<CimObjectRecord>  findByJobIdAndCategoryAndIsRequired(
            String jobId, String cat, boolean req);
    long countByJobId(String jobId);
    long countByJobIdAndCategory(String jobId, String category);
    long countByJobIdAndIsRequired(String jobId, boolean req);
    void deleteByJobId(String jobId);
    List<CimObjectRecord> findByVersionAndOrgId(String version, String orgId);
    long countByJobIdAndCategoryAndIsRequired(String jobId, String cat, boolean req);
}

@Repository
interface Neo4jExportJobRepository
        extends MongoRepository<Neo4jExportJob, String> {
    Optional<Neo4jExportJob> findByExportId(String exportId);
    List<Neo4jExportJob>     findByJobId(String jobId);
    List<Neo4jExportJob>     findTop10ByOrderByStartedAtDesc();
}

// ── Namespace Config ──────────────────────────────────────────────
@Repository
interface NamespaceConfigRepository
        extends MongoRepository<NamespaceConfig, String> {
    Optional<NamespaceConfig> findByPrefix(String prefix);
    List<NamespaceConfig>     findByEnabled(boolean enabled);
    List<NamespaceConfig>     findAll();
    boolean existsByPrefix(String prefix);
}

// ── Neo4j Export Config ──────────────────────────────────────
@Repository
interface Neo4jExportConfigRepository
        extends MongoRepository<Neo4jExportConfig, String> {
    List<Neo4jExportConfig> findByActiveTrue();
    List<Neo4jExportConfig> findByOrgIdAndActiveTrue(String orgId);
    List<Neo4jExportConfig> findByAutoExportTrueAndActiveTrue();
    List<Neo4jExportConfig> findByOrgIdAndAutoExportTrueAndActiveTrue(String orgId);
    Optional<Neo4jExportConfig> findByConfigName(String configName);
}

// ── Neo4j Export ──────────────────────────────────────────────────
@Repository
interface Neo4jExportJobRepository
        extends MongoRepository<Neo4jExportJob, String> {
    Optional<Neo4jExportJob> findByExportId(String exportId);
    List<Neo4jExportJob>     findByJobId(String jobId);
    List<Neo4jExportJob>     findTop10ByOrderByStartedAtDesc();
}
