package com.cim.service;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.model.mongo.Neo4jExportJob;
import com.cim.model.mongo.ExportRequest;
import com.cim.model.mongo.ExportRequest.ExportMode;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.repository.Neo4jExportJobRepository;
import com.cim.repository.ValidationJobRepository;
import com.cim.util.MapKeySanitizer;
import org.neo4j.driver.*;
import org.neo4j.driver.exceptions.Neo4jException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;

/**
 * Neo4j Export Service — Simplified High-Performance Version
 *
 * KEY DESIGN DECISIONS:
 *
 * 1. CREATE CONSTRAINT on rdfId per label (not label-less index)
 *    Neo4j 4.x requires a label on every index/constraint.
 *    Label-less index syntax silently fails → MERGE does full scan → O(n) per MERGE
 *    Constraint per label → MERGE uses it → O(log n) always.
 *    We create constraints lazily: first time we see a cimType label.
 *
 * 2. MERGE on rdfId + version + orgId encoded as nodeKey string
 *    Single string property with per-label constraint = fast lookup.
 *
 * 3. Cursor pagination (_id > lastId) = O(1) per page regardless of page number.
 *    Offset pagination (skip N) = O(N) — was causing slowdown past page 100.
 *
 * 4. One session per page batch (all cimTypes share one connection).
 *
 * 5. Two-pass: all nodes first, then all relationships.
 *    Prevents MATCH failures when source/target nodes in different pages.
 *
 * 6. Batch size 2000 (configurable).
 */
@Service
public class Neo4jExportService {

    private static final Logger log =
            LoggerFactory.getLogger(Neo4jExportService.class);

    @Value("${cim.neo4j.export.batch-size:5000}")
    private int batchSize;

    @Value("${cim.neo4j.export.create-constraints:true}")
    private boolean createConstraints;

    private final Driver                    driver;
    private final MongoTemplate             mongo;
    private final CimObjectRecordRepository objectRepo;
    private final Neo4jExportJobRepository  exportRepo;
    private final ValidationJobRepository   jobRepo;

    // Tracks which labels already have a constraint — avoids redundant DDL
    private final Set<String> constrainedLabels = new HashSet<>();

    private Neo4jExportExecutor executor;

    @org.springframework.beans.factory.annotation.Autowired
    public void setExecutor(Neo4jExportExecutor executor) {
        this.executor = executor;
    }

    public Neo4jExportService(Driver driver, MongoTemplate mongo,
                               CimObjectRecordRepository objectRepo,
                               Neo4jExportJobRepository exportRepo,
                               ValidationJobRepository jobRepo) {
        this.driver     = driver;
        this.mongo      = mongo;
        this.objectRepo = objectRepo;
        this.exportRepo = exportRepo;
        this.jobRepo    = jobRepo;
    }

    // ── Start export (returns immediately) ───────────────────────────────

    public Neo4jExportJob startExport(ExportRequest req) {
        String exportId = UUID.randomUUID().toString();
        String version  = jobRepo.findByJobId(req.getJobId())
                .map(j -> j.getNetworkVersion() != null ? j.getNetworkVersion() : "")
                .orElse("");
        String orgId = jobRepo.findByJobId(req.getJobId())
                .map(j -> j.getOrgId() != null ? j.getOrgId() : "")
                .orElse("");
        Neo4jExportJob job = new Neo4jExportJob(
                exportId, req.getJobId(), version, orgId, req.getMode().name());
        exportRepo.save(job);
        executor.runAsync(req, job);
        return job;
    }

    // ── Called by Neo4jExportExecutor on async thread ─────────────────────

    public void runExport(ExportRequest req, Neo4jExportJob job) {
        try {
            job.setStatus("RUNNING");
            exportRepo.save(job);
            long start = System.currentTimeMillis();
            constrainedLabels.clear();

            if (req.isClearFirst()) {
                clearExistingNodes(job.getNetworkVersion(), job.getOrgId());
            }

            // Step 1: Create shared CIMNode indexes (version, orgId, mrid, nodeKey)
            ensureSharedIndexes();
            // Step 2: Create per-label constraints for fast MERGE in Pass 1
            createAllConstraintsUpfront(req);

            int[] counts = twoPassExport(req, job);

            job.setStatus("DONE");
            job.setNodesExported(counts[0]);
            job.setRelsExported(counts[1]);
            job.setCompletedAt(Instant.now());
            job.setProcessingMs(System.currentTimeMillis() - start);
            exportRepo.save(job);

            log.info("Export DONE: nodes={} rels={} in {}s",
                    counts[0], counts[1],
                    (System.currentTimeMillis() - start) / 1000);

        } catch (Exception e) {
            log.error("Export FAILED: {}", e.getMessage(), e);
            job.setStatus("FAILED");
            job.setErrorMessage(e.getMessage());
            job.setCompletedAt(Instant.now());
            exportRepo.save(job);
        }
    }

    // ── Two-pass: nodes first, then relationships ─────────────────────────

    private int[] twoPassExport(ExportRequest req, Neo4jExportJob job) {
        int totalNodes = 0, totalRels = 0;
        long total = mongo.count(new Query(buildCriteria(req)), "cim_objects");
        boolean useBulkCreate = req.isClearFirst();

        // ── BULK STRATEGY (clearFirst=true) ──────────────────────────────
        // Drop indexes → CREATE (no lookup) → rebuild indexes
        // 10-20x faster than MERGE with live indexes
        // Safe because clearExistingNodes() already removed this version
        if (useBulkCreate) {
            log.info("Bulk import mode: dropping indexes for max throughput");
            dropAllCimIndexes();
        }
        log.info("Pass 1 — {} nodes batch={} mode={}",
                total, batchSize, useBulkCreate ? "CREATE" : "MERGE");

        long start = System.currentTimeMillis();
        String lastId = null; int page = 0;

        // ── PASS 1: Nodes ─────────────────────────────────────────────────
        while (true) {
            List<CimObjectRecord> batch = fetchPage(req, lastId);
            if (batch.isEmpty()) break;
            totalNodes += useBulkCreate
                ? writeNodesCreate(batch, job.getNetworkVersion(), job.getOrgId())
                : writeNodes(batch, job.getNetworkVersion(), job.getOrgId());
            lastId = batch.get(batch.size()-1).getId();
            page++;
            if (page % 20 == 0) {
                long el = System.currentTimeMillis() - start;
                long rate = el > 0 ? totalNodes*1000L/el : 0;
                long eta  = rate > 0 ? (total - totalNodes)/rate/60 : -1;
                log.info("Pass 1: page={} nodes={}/{} rate={}/s eta={}min",
                        page, totalNodes, total, rate, eta);
                job.setNodesExported(totalNodes); exportRepo.save(job);
            }
        }
        log.info("Pass 1 DONE — {} nodes in {}s",
                totalNodes, (System.currentTimeMillis()-start)/1000);

        // ── PASS 2: Relationships ─────────────────────────────────────────
        // If bulk mode: no indexes yet → MATCH will full-scan
        // Rebuild nodeKey index first so MATCH is fast
        if (useBulkCreate) {
            log.info("Rebuilding nodeKey index before relationships...");
            rebuildNodeKeyIndex();
            log.info("nodeKey index ready — starting relationships");
        }

        log.info("Pass 2 — relationships");
        start = System.currentTimeMillis();
        lastId = null; page = 0;

        while (true) {
            List<CimObjectRecord> batch = fetchPage(req, lastId);
            if (batch.isEmpty()) break;
            totalRels += writeRelationships(batch);
            lastId = batch.get(batch.size()-1).getId();
            page++;
            if (page % 20 == 0) {
                long el = System.currentTimeMillis() - start;
                long rate = el > 0 ? totalRels*1000L/el : 0;
                log.info("Pass 2: page={} rels={} rate={}/s", page, totalRels, rate);
                job.setRelsExported(totalRels); exportRepo.save(job);
            }
        }
        log.info("Pass 2 DONE — {} rels in {}s",
                totalRels, (System.currentTimeMillis()-start)/1000);

        // ── PASS 3: Rebuild all remaining indexes ────────────────────────
        if (useBulkCreate) {
            log.info("Pass 3 — rebuilding all indexes...");
            long rs = System.currentTimeMillis();
            ensureSharedIndexes();
            createAllConstraintsUpfront(req);
            log.info("Pass 3 DONE — indexes rebuilt in {}s",
                    (System.currentTimeMillis()-rs)/1000);
        }

        return new int[]{totalNodes, totalRels};
    }

    // ── CREATE (bulk insert, no index overhead) ───────────────────────────

    private int writeNodesCreate(List<CimObjectRecord> records,
                                  String version, String orgId) {
        if (records.isEmpty()) return 0;
        Map<String, List<Map<String,Object>>> byLabel = new LinkedHashMap<>();
        for (CimObjectRecord rec : records) {
            String label = sanitizeLabel(rec.getCimType());
            byLabel.computeIfAbsent(label, k -> new ArrayList<>())
                   .add(buildNodeProps(rec, version, orgId));
        }
        int written = 0;
        try (Session s = driver.session()) {
            for (Map.Entry<String,List<Map<String,Object>>> e : byLabel.entrySet()) {
                String label = e.getKey();
                List<Map<String,Object>> batch = e.getValue();
                final String fc =
                    "UNWIND $batch AS p CREATE (n:" + label + ":CIMNode) SET n = p";
                final List<Map<String,Object>> fb = batch;
                try {
                    s.writeTransaction(tx -> {
                        tx.run(fc, Values.parameters("batch", fb));
                        return null;
                    });
                    written += batch.size();
                } catch (Neo4jException ex) {
                    log.warn("CREATE failed {}: {}", label, ex.getMessage());
                }
            }
        } catch (Exception e) {
            log.warn("Session error writeNodesCreate: {}", e.getMessage());
        }
        return written;
    }

    // ── Drop all CIM indexes/constraints ─────────────────────────────────

    private void dropAllCimIndexes() {
        try (Session s = driver.session()) {
            // Drop named indexes
            Result ri = s.run("SHOW INDEXES WHERE name STARTS WITH 'cim'");
            List<String> idxNames = new ArrayList<>();
            while (ri.hasNext()) idxNames.add(ri.next().get("name").asString());

            // Drop constraints ending with _nodekey
            Result rc = s.run("SHOW CONSTRAINTS WHERE name ENDS WITH '_nodekey'");
            List<String> conNames = new ArrayList<>();
            while (rc.hasNext()) conNames.add(rc.next().get("name").asString());

            for (String n : idxNames) {
                try { s.run("DROP INDEX " + n + " IF EXISTS"); }
                catch (Exception e) { log.debug("Drop idx {}: {}", n, e.getMessage()); }
            }
            for (String n : conNames) {
                try { s.run("DROP CONSTRAINT " + n + " IF EXISTS"); }
                catch (Exception e) { log.debug("Drop con {}: {}", n, e.getMessage()); }
            }
            constrainedLabels.clear();
            log.info("Dropped {} indexes + {} constraints", idxNames.size(), conNames.size());
        } catch (Exception e) {
            log.warn("dropAllCimIndexes: {}", e.getMessage());
        }
    }

    // ── Rebuild nodeKey index before Pass 2 (needed for MATCH) ───────────

    private void rebuildNodeKeyIndex() {
        try (Session s = driver.session()) {
            s.run("CREATE INDEX cim_node_nodekey_idx IF NOT EXISTS " +
                  "FOR (n:CIMNode) ON (n.nodeKey)");
            // Wait for index to come ONLINE
            for (int i = 0; i < 60; i++) {
                Result r = s.run(
                    "SHOW INDEXES WHERE name = 'cim_node_nodekey_idx'");
                if (r.hasNext()) {
                    String state = r.next().get("state").asString();
                    log.info("nodeKey index state: {}", state);
                    if ("ONLINE".equals(state)) break;
                }
                try { Thread.sleep(5000); }
                catch (InterruptedException ignored) { break; }
            }
        } catch (Exception e) {
            log.warn("rebuildNodeKeyIndex: {}", e.getMessage());
        }
    }

    // ── Cursor-based fetch — O(1) per page ────────────────────────────────

    private List<CimObjectRecord> fetchPage(ExportRequest req, String lastId) {
        Criteria criteria = buildCriteria(req);
        if (lastId != null && !lastId.isBlank()) {
            criteria = new Criteria().andOperator(
                    criteria,
                    Criteria.where("_id").gt(
                            new org.bson.types.ObjectId(lastId)));
        }
        return mongo.find(
                new Query(criteria)
                        .limit(batchSize)
                        .with(Sort.by(Sort.Direction.ASC, "_id")),
                CimObjectRecord.class, "cim_objects");
    }

    // ── Write nodes — constraint per label, one session per batch ─────────

    private int writeNodes(List<CimObjectRecord> records,
                            String version, String orgId) {
        if (records.isEmpty()) return 0;

        // Group by sanitized cimType label
        Map<String, List<Map<String, Object>>> byLabel = new LinkedHashMap<>();
        for (CimObjectRecord rec : records) {
            String label = sanitizeLabel(rec.getCimType());
            byLabel.computeIfAbsent(label, k -> new ArrayList<>())
                   .add(buildNodeProps(rec, version, orgId));
        }

        int written = 0;
        // ONE session for all labels in this batch
        try (Session s = driver.session()) {
            for (Map.Entry<String, List<Map<String, Object>>> e : byLabel.entrySet()) {
                String label = e.getKey();
                List<Map<String, Object>> nodeBatch = e.getValue();

                // Ensure constraint exists for this label (lazy, once per label)
                ensureLabelConstraint(s, label);

                // MERGE on nodeKey — uses per-label constraint = O(log n)
                // :CIMNode is a shared routing label added to ALL nodes.
                // This enables a single index on CIMNode.nodeKey used
                // by Pass 2 MATCH statements across all cimTypes.
                // Users query by specific label (:ACLineSegment etc).
                String cypher =
                    "UNWIND $batch AS p " +
                    "MERGE (n:" + label + ":CIMNode {nodeKey: p.nodeKey}) " +
                    "SET n += p";

                try {
                    final String fc = cypher;
                    final List<Map<String, Object>> fb = nodeBatch;
                    s.writeTransaction(tx -> {
                        tx.run(fc, Values.parameters("batch", fb));
                        return null;
                    });
                    written += nodeBatch.size();
                } catch (Neo4jException ex) {
                    log.warn("Node write failed for {}: {}", label, ex.getMessage());
                }
            }
        } catch (Exception e) {
            log.warn("Session error writeNodes: {}", e.getMessage());
        }
        return written;
    }

    // ── Create constraint per label lazily ────────────────────────────────

    /**
     * Creates constraints for ALL distinct cimTypes in one pass BEFORE export starts.
     * Much faster than lazy per-page creation which blocks each batch.
     */
    private void createAllConstraintsUpfront(ExportRequest req) {
        if (!createConstraints) return;
        log.info("Creating constraints for all cimType labels...");
        long start = System.currentTimeMillis();

        // Get distinct cimTypes for this job
        org.springframework.data.mongodb.core.aggregation.Aggregation agg =
            org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation(
                org.springframework.data.mongodb.core.aggregation.Aggregation.match(buildCriteria(req)),
                org.springframework.data.mongodb.core.aggregation.Aggregation.group("cimType"),
                org.springframework.data.mongodb.core.aggregation.Aggregation.project("_id")
            );
        List<org.bson.Document> results = mongo.aggregate(
                agg, "cim_objects", org.bson.Document.class).getMappedResults();

        int created = 0;
        for (org.bson.Document doc : results) {
            Object ct = doc.get("_id");
            if (ct == null) continue;
            String label = sanitizeLabel(ct.toString());
            if (constrainedLabels.contains(label)) continue;
            try (Session s = driver.session()) {
                s.run("CREATE CONSTRAINT " + label + "_nodekey IF NOT EXISTS " +
                      "ON (n:" + label + ") ASSERT n.nodeKey IS UNIQUE");
                constrainedLabels.add(label);
                created++;
            } catch (Exception e) {
                constrainedLabels.add(label); // mark as handled
                log.debug("Constraint note {}: {}", label, e.getMessage());
            }
        }
        log.info("Constraints ready: {} labels in {}ms",
                constrainedLabels.size(), System.currentTimeMillis() - start);
    }

    /** Per-label constraint check — now only called if not already in constrainedLabels */
    private void ensureLabelConstraint(Session s, String label) {
        if (constrainedLabels.contains(label)) return;
        try {
            s.run("CREATE CONSTRAINT " + label + "_nodekey IF NOT EXISTS " +
                  "ON (n:" + label + ") ASSERT n.nodeKey IS UNIQUE");
            constrainedLabels.add(label);
        } catch (Exception e) {
            constrainedLabels.add(label);
        }
    }

    // ── Write relationships — one session per batch ───────────────────────

    private int writeRelationships(List<CimObjectRecord> records) {
        if (records.isEmpty()) return 0;

        // Build all relationships from resolvedRefIds
        Map<String, List<Map<String, Object>>> byRelType = new LinkedHashMap<>();
        for (CimObjectRecord rec : records) {
            if (rec.getResolvedRefIds() == null || rec.getResolvedRefIds().isEmpty())
                continue;
            String v   = rec.getVersion() != null ? rec.getVersion() : "";
            String o   = rec.getOrgId()   != null ? rec.getOrgId()   : "";
            String src = rec.getRdfId()   != null ? rec.getRdfId()   : "";

            MapKeySanitizer.decodeKeys(rec.getResolvedRefIds())
                    .forEach((key, tgt) -> {
                        Map<String, Object> r = new LinkedHashMap<>();
                        r.put("srcKey", src + "|" + v + "|" + o);
                        r.put("tgtKey", tgt + "|" + v + "|" + o);
                        r.put("version", v);
                        r.put("orgId",   o);
                        String relType = "`" + key.replace("`", "") + "`";
                        byRelType.computeIfAbsent(relType, k -> new ArrayList<>()).add(r);
                    });
        }

        int written = 0;
        // ONE session for all relationship types
        try (Session s = driver.session()) {
            for (Map.Entry<String, List<Map<String, Object>>> e : byRelType.entrySet()) {
                String relType = e.getKey();
                List<Map<String, Object>> relBatch = e.getValue();
                // MATCH uses :CIMNode label — single index lookup
                // Much faster than label-less MATCH which scans all nodes
                String cypher =
                    "UNWIND $batch AS r " +
                    "MATCH (src:CIMNode {nodeKey: r.srcKey}) " +
                    "MATCH (tgt:CIMNode {nodeKey: r.tgtKey}) " +
                    "MERGE (src)-[:" + relType +
                    " {version: r.version, orgId: r.orgId}]->(tgt)";
                final String fc = cypher;
                final List<Map<String, Object>> fb = relBatch;
                try {
                    s.writeTransaction(tx -> {
                        tx.run(fc, Values.parameters("batch", fb));
                        return null;
                    });
                    written += relBatch.size();
                } catch (Neo4jException ex) {
                    log.warn("Rel write failed {}: {}", relType, ex.getMessage());
                }
            }
        } catch (Exception e) {
            log.warn("Session error writeRelationships: {}", e.getMessage());
        }
        return written;
    }

    // ── Node properties ───────────────────────────────────────────────────

    private Map<String, Object> buildNodeProps(CimObjectRecord rec,
                                                String version, String orgId) {
        Map<String, Object> p = new LinkedHashMap<>();
        String v = version != null ? version : "";
        String o = orgId   != null ? orgId   : "";
        String r = rec.getRdfId() != null ? rec.getRdfId() : "";

        // nodeKey = unique identifier across versions/orgs
        p.put("nodeKey", r + "|" + v + "|" + o);
        p.put("mrid",    rec.getMrid()    != null ? rec.getMrid()    : r);
        p.put("rdfId",   r);
        p.put("name",    rec.getName()    != null ? rec.getName()    : "");
        p.put("cimType", rec.getCimType() != null ? rec.getCimType() : "Unknown");
        p.put("version", v);
        p.put("orgId",   o);
        p.put("uri",     rec.getSourceFile() != null ? rec.getSourceFile() : "");

        // CIM attributes — dot notation keys (ACLineSegment.r etc)
        if (rec.getAttributes() != null) {
            MapKeySanitizer.decodeKeys(rec.getAttributes()).forEach((k, val) -> {
                if (k != null && val != null && !val.isBlank()) p.put(k, val);
            });
        }
        return p;
    }

    // ── Clear existing nodes (batched) ────────────────────────────────────

    /**
     * Creates all indexes needed for fast export AND fast querying.
     *
     * INDEX STRATEGY:
     *
     * 1. Per-label UNIQUE constraint on nodeKey (for MERGE in Pass 1):
     *    CONSTRAINT ACLineSegment_nodekey ON (n:ACLineSegment) ASSERT n.nodeKey IS UNIQUE
     *    → Makes MERGE (n:ACLineSegment {nodeKey:...}) O(log n)
     *    Created upfront for all cimTypes via createAllConstraintsUpfront()
     *
     * 2. CIMNode.nodeKey index (for MATCH in Pass 2):
     *    INDEX cim_nodekey ON (n:CIMNode) FOR n.nodeKey
     *    → Makes MATCH (src:CIMNode {nodeKey:...}) O(log n)
     *    One index covers ALL cimTypes
     *
     * 3. CIMNode.version index (for version-based queries):
     *    INDEX cim_version ON (n:CIMNode) FOR n.version
     *    → MATCH (n:CIMNode {version:'DB140'}) uses index
     *
     * 4. CIMNode.orgId index (for org-based queries):
     *    INDEX cim_orgid ON (n:CIMNode) FOR n.orgId
     *    → MATCH (n:CIMNode {orgId:'CAISO'}) uses index
     *
     * 5. CIMNode.mrid index (for mrid lookups):
     *    INDEX cim_mrid ON (n:CIMNode) FOR n.mrid
     *    → MATCH (n:CIMNode {mrid:'_abc...'}) uses index
     *
     * WITHOUT indexes:
     *   MATCH (n {version:'DB140'}) on 3.4M nodes = full scan = minutes
     * WITH indexes:
     *   MATCH (n:CIMNode {version:'DB140'}) = O(log n) = milliseconds
     */
    private void ensureSharedIndexes() {
        // CIMNode indexes — shared across all cimType labels
        String[][] indexes = {
            // Name,                          Cypher
            {"cim_node_nodekey_idx",
             "CREATE INDEX cim_node_nodekey_idx IF NOT EXISTS " +
             "FOR (n:CIMNode) ON (n.nodeKey)"},
            {"cim_node_version_idx",
             "CREATE INDEX cim_node_version_idx IF NOT EXISTS " +
             "FOR (n:CIMNode) ON (n.version)"},
            {"cim_node_orgid_idx",
             "CREATE INDEX cim_node_orgid_idx IF NOT EXISTS " +
             "FOR (n:CIMNode) ON (n.orgId)"},
            {"cim_node_mrid_idx",
             "CREATE INDEX cim_node_mrid_idx IF NOT EXISTS " +
             "FOR (n:CIMNode) ON (n.mrid)"},
            {"cim_node_rdfid_idx",
             "CREATE INDEX cim_node_rdfid_idx IF NOT EXISTS " +
             "FOR (n:CIMNode) ON (n.rdfId)"},
            {"cim_node_cimtype_idx",
             "CREATE INDEX cim_node_cimtype_idx IF NOT EXISTS " +
             "FOR (n:CIMNode) ON (n.cimType)"},
        };

        for (String[] idx : indexes) {
            try (Session s = driver.session()) {
                s.run(idx[1]);
                log.debug("Index ensured: {}", idx[0]);
            } catch (Exception e) {
                log.debug("Index note {}: {}", idx[0], e.getMessage());
            }
        }
        log.info("Shared CIMNode indexes ensured ({} indexes)", indexes.length);
    }

    private void clearExistingNodes(String version, String orgId) {
        log.info("Clearing nodes version={} orgId={}", version, orgId);
        long total = 0;
        while (true) {
            try (Session s = driver.session()) {
                // :CIMNode label + index on version/orgId = fast delete
                Result r = s.writeTransaction(tx -> tx.run(
                    "MATCH (n:CIMNode {version: $v, orgId: $o}) " +
                    "WITH n LIMIT 1000 DETACH DELETE n " +
                    "RETURN count(n) AS d",
                    Values.parameters("v", version, "o", orgId)));
                long d = r.single().get("d").asLong();
                total += d;
                if (d == 0) break;
            } catch (Exception e) {
                log.warn("Clear error: {}", e.getMessage());
                break;
            }
        }
        log.info("Cleared {} nodes", total);
    }

    // ── Criteria builder ──────────────────────────────────────────────────

    private Criteria buildCriteria(ExportRequest req) {
        String jobId = req.getJobId();
        if (req.getMode() == ExportMode.PHYSICAL_ONLY) {
            return Criteria.where("jobId").is(jobId).and("category").is("PHYSICAL");
        } else if (req.getMode() == ExportMode.REQUIRED_ONLY) {
            return Criteria.where("jobId").is(jobId).and("isRequired").is(true);
        } else if (req.getMode() == ExportMode.CUSTOM) {
            return Criteria.where("jobId").is(jobId)
                    .and("cimType").in(req.getCimTypes());
        } else if (req.getMode() == ExportMode.TOPOLOGY) {
            List<String> logical = Arrays.asList(
                    "Terminal","ConnectivityNode","TopologicalNode","TopologicalIsland");
            return new Criteria().orOperator(
                    Criteria.where("jobId").is(jobId).and("category").is("PHYSICAL"),
                    Criteria.where("jobId").is(jobId).and("cimType").in(logical));
        }
        // ALL
        return Criteria.where("jobId").is(jobId);
    }

    // ── Label sanitizer ───────────────────────────────────────────────────

    private String sanitizeLabel(String t) {
        if (t == null || t.isBlank()) return "Unknown";
        return t.replaceAll("[^A-Za-z0-9_]", "_");
    }

    // ── Remove legacy :CIMObject labels ──────────────────────────────────

    public long removeCimObjectLabels() {
        long total = 0;
        while (true) {
            try (Session s = driver.session()) {
                Result r = s.writeTransaction(tx -> tx.run(
                    "MATCH (n:CIMObject) WITH n LIMIT 1000 " +
                    "REMOVE n:CIMObject RETURN count(n) AS removed"));
                long removed = r.single().get("removed").asLong();
                total += removed;
                if (removed == 0) break;
                log.info("Removed :CIMObject from {} nodes (total: {})", removed, total);
            } catch (Exception e) {
                log.warn("Label removal: {}", e.getMessage());
                break;
            }
        }
        log.info("Cleanup done — removed :CIMObject from {} nodes", total);
        return total;
    }

    // ── Status ────────────────────────────────────────────────────────────

    public Optional<Neo4jExportJob> getExportStatus(String exportId) {
        return exportRepo.findByExportId(exportId);
    }

    public List<Neo4jExportJob> getRecentExports() {
        return exportRepo.findTop10ByOrderByStartedAtDesc();
    }
}
