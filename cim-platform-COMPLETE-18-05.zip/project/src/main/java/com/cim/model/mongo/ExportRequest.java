package com.cim.model.mongo;

import java.util.ArrayList;
import java.util.List;

/**
 * Export request body — @RequestBody for Swagger UI (REQ #6).
 *
 * REQ #3 — THREE VERSION TYPES, each with its OWN set of CIM types:
 *
 *   FULL      ({version}-0): User-defined full CIM type list
 *                            e.g. all equipment + connectors + measurements
 *
 *   SANITISED ({version}-1): User-defined core CIM type list
 *                            e.g. primary equipment + topology connectors
 *                            DEFAULT for import flow (auto-export)
 *
 *   RESILIENT ({version}-2): User-defined minimal CIM type list
 *                            e.g. primary equipment only
 *
 * Each variant exports a DIFFERENT SET of CIM types to Neo4j.
 * All three can be triggered from a single API call.
 * Stored as separate node sets in Neo4j (different version suffix).
 *
 * To export a single variant: set singleVersionType + cimTypes
 * To export all three at once: set fullCimTypes + sanitisedCimTypes + resilientCimTypes
 */
public class ExportRequest {

    public enum ExportMode {
        ALL,
        PHYSICAL_ONLY,
        REQUIRED_ONLY,
        /** Export the cimTypes list directly */
        CUSTOM,
        /** Physical + Terminal + ConnectivityNode — recommended */
        TOPOLOGY
    }

    /**
     * Which version variant this single-export request targets.
     * Used when exporting one variant at a time.
     * SANITISED is the default (import flow auto-export).
     */
    public enum VersionType {
        FULL,       // stored as {version}-0
        SANITISED,  // stored as {version}-1  ← default
        RESILIENT   // stored as {version}-2
    }

    // ── Required ─────────────────────────────────────────────────────────

    /** MongoDB import job ID to export from. Required. */
    private String jobId;

    /** Organisation ID. Uses job orgId if not provided. REQ #4 */
    private String orgId;

    /** Delete existing nodes for this version+orgId before export. */
    private boolean clearFirst = true;

    // ── Single variant export ─────────────────────────────────────────────
    // Use these when exporting ONE version type at a time.

    /** Which variant to export. Default: SANITISED */
    private VersionType versionType = VersionType.SANITISED;

    /**
     * CIM types for single-variant export.
     * Required when versionType is set and mode=CUSTOM.
     * e.g. ["ACLineSegment","Breaker","PowerTransformer","Terminal"]
     */
    private List<String> cimTypes = new ArrayList<>();

    /** Export mode for single-variant export. Default: TOPOLOGY */
    private ExportMode mode = ExportMode.TOPOLOGY;

    // ── Multi-variant export (all three at once) ──────────────────────────
    // Set fullCimTypes + sanitisedCimTypes + resilientCimTypes to export
    // all three variants in one API call. Each gets its own version suffix.

    /**
     * CIM types for FULL variant ({version}-0).
     * If set, FULL export is triggered alongside other variants.
     * Typically the largest set — all equipment + connectors + measurements.
     *
     * Example:
     *   ["ACLineSegment","Breaker","PowerTransformer","Fuse","Disconnector",
     *    "Recloser","SynchronousMachine","EnergyConsumer","GeneratingUnit",
     *    "LinearShuntCompensator","Terminal","ConnectivityNode",
     *    "TopologicalNode","BaseVoltage","Substation","VoltageLevel",
     *    "Bay","Line","SubGeographicalRegion","GeographicalRegion"]
     */
    private List<String> fullCimTypes = new ArrayList<>();

    /**
     * CIM types for SANITISED variant ({version}-1).
     * If set, SANITISED export is triggered.
     * Core topology — primary equipment + connectors.
     *
     * Example:
     *   ["ACLineSegment","Breaker","PowerTransformer","Fuse","Disconnector",
     *    "Terminal","ConnectivityNode","BaseVoltage","Substation",
     *    "VoltageLevel","Line"]
     */
    private List<String> sanitisedCimTypes = new ArrayList<>();

    /**
     * CIM types for RESILIENT variant ({version}-2).
     * If set, RESILIENT export is triggered.
     * Minimal set — only primary equipment with all refs guaranteed resolved.
     *
     * Example:
     *   ["ACLineSegment","Breaker","PowerTransformer","Fuse","Disconnector",
     *    "SynchronousMachine","EnergyConsumer"]
     */
    private List<String> resilientCimTypes = new ArrayList<>();

    // ── Constructors ──────────────────────────────────────────────────────

    public ExportRequest() {}

    /** Single variant constructor */
    public ExportRequest(String jobId, ExportMode mode,
                          List<String> cimTypes, boolean clearFirst) {
        this.jobId       = jobId;
        this.mode        = mode;
        this.cimTypes    = cimTypes != null ? cimTypes : new ArrayList<>();
        this.clearFirst  = clearFirst;
        this.versionType = VersionType.SANITISED;
    }

    // ── Version suffix builder ────────────────────────────────────────────

    /**
     * Returns the Neo4j version string for a given variant.
     * e.g. networkVersion="DB140", SANITISED → "DB140-1"
     */
    public String buildNeo4jVersion(String networkVersion, VersionType type) {
        if (networkVersion == null) return "unknown-1";
        String base = networkVersion.trim();
        if (type == VersionType.FULL)      return base + "-0";
        if (type == VersionType.RESILIENT) return base + "-2";
        return base + "-1"; // SANITISED default
    }

    /** Convenience: build version for this request's versionType */
    public String buildNeo4jVersion(String networkVersion) {
        return buildNeo4jVersion(networkVersion, this.versionType);
    }

    /**
     * Returns true if this is a multi-variant export request.
     * Multi-variant: at least one of fullCimTypes, sanitisedCimTypes,
     * or resilientCimTypes is non-empty.
     */
    public boolean isMultiVariant() {
        return !fullCimTypes.isEmpty()
            || !sanitisedCimTypes.isEmpty()
            || !resilientCimTypes.isEmpty();
    }

    // ── Getters / Setters ─────────────────────────────────────────────────

    public String       getJobId()                           { return jobId; }
    public void         setJobId(String v)                   { this.jobId = v; }
    public String       getOrgId()                           { return orgId; }
    public void         setOrgId(String v)                   { this.orgId = v; }
    public boolean      isClearFirst()                       { return clearFirst; }
    public void         setClearFirst(boolean v)             { this.clearFirst = v; }
    public VersionType  getVersionType()                     { return versionType; }
    public void         setVersionType(VersionType v)        { this.versionType = v; }
    public List<String> getCimTypes()                        { return cimTypes; }
    public void         setCimTypes(List<String> v)          { this.cimTypes = v != null ? v : new ArrayList<>(); }
    public ExportMode   getMode()                            { return mode; }
    public void         setMode(ExportMode v)                { this.mode = v; }
    public List<String> getFullCimTypes()                    { return fullCimTypes; }
    public void         setFullCimTypes(List<String> v)      { this.fullCimTypes = v != null ? v : new ArrayList<>(); }
    public List<String> getSanitisedCimTypes()               { return sanitisedCimTypes; }
    public void         setSanitisedCimTypes(List<String> v) { this.sanitisedCimTypes = v != null ? v : new ArrayList<>(); }
    public List<String> getResilientCimTypes()               { return resilientCimTypes; }
    public void         setResilientCimTypes(List<String> v) { this.resilientCimTypes = v != null ? v : new ArrayList<>(); }
}
