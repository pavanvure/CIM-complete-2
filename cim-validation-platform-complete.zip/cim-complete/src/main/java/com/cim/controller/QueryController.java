package com.cim.controller;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.repository.CimObjectRecordRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.bson.Document;

import java.util.*;

/**
 * Query and isRequired management REST API
 *
 * GET  /api/jobs/{jobId}/objects               — list objects
 * GET  /api/jobs/{jobId}/objects/stats         — type breakdown
 * GET  /api/objects/{id}                       — single object
 * GET  /api/objects/{id}/required              — get isRequired
 * PATCH /api/objects/{id}/required?value=true  — set one object
 * PATCH /api/jobs/{jobId}/objects/required     — bulk set
 * PATCH /api/jobs/{jobId}/objects/required/reset — reset to defaults
 * GET  /api/jobs/{jobId}/objects/required/summary — summary
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class QueryController {

    private final CimObjectRecordRepository objectRepo;
    private final MongoTemplate             mongoTemplate;

    public QueryController(CimObjectRecordRepository objectRepo,
                            MongoTemplate mongoTemplate) {
        this.objectRepo    = objectRepo;
        this.mongoTemplate = mongoTemplate;
    }

    // ── Query objects ──────────────────────────────────────────────────────

    @GetMapping("/jobs/{jobId}/objects")
    public ResponseEntity<?> getObjects(
            @PathVariable String jobId,
            @RequestParam(required=false) String type,
            @RequestParam(required=false) String category,
            @RequestParam(required=false) Boolean required,
            @RequestParam(defaultValue="0")  int page,
            @RequestParam(defaultValue="50") int size) {

        if (type != null) return ResponseEntity.ok(
                objectRepo.findByJobIdAndCimType(jobId, type));
        if (category != null) return ResponseEntity.ok(
                objectRepo.findByJobIdAndCategory(jobId, category.toUpperCase()));
        if (required != null) return ResponseEntity.ok(
                objectRepo.findByJobIdAndIsRequired(jobId, required));

        Page<CimObjectRecord> p = objectRepo.findByJobId(jobId,
                PageRequest.of(page, size, Sort.by("cimType")));
        return ResponseEntity.ok(Map.of(
            "content",       p.getContent(),
            "totalElements", p.getTotalElements(),
            "totalPages",    p.getTotalPages(),
            "page",          page,
            "size",          size
        ));
    }

    @GetMapping("/jobs/{jobId}/objects/stats")
    public ResponseEntity<?> getStats(@PathVariable String jobId) {
        long total    = objectRepo.countByJobId(jobId);
        long physical = objectRepo.countByJobIdAndCategory(jobId, "PHYSICAL");
        long logical  = objectRepo.countByJobIdAndCategory(jobId, "LOGICAL");
        long required = objectRepo.countByJobIdAndIsRequired(jobId, true);
        List<Map<String,Object>> byType = getTypeBreakdown(jobId);
        return ResponseEntity.ok(Map.of(
            "total", total, "physical", physical,
            "logical", logical, "required", required,
            "byType", byType
        ));
    }

    @GetMapping("/objects/{id}")
    public ResponseEntity<?> getObject(@PathVariable String id) {
        return objectRepo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // ── isRequired management ──────────────────────────────────────────────

    @GetMapping("/objects/{id}/required")
    public ResponseEntity<?> getRequired(@PathVariable String id) {
        return objectRepo.findById(id)
                .map(o -> ResponseEntity.ok(Map.of(
                    "id", o.getId(), "rdfId", o.getRdfId(),
                    "cimType", o.getCimType(),
                    "name", o.getName() != null ? o.getName() : "",
                    "category", o.getCategory(), "isRequired", o.isRequired()
                ))).orElse(ResponseEntity.notFound().build());
    }

    @PatchMapping("/objects/{id}/required")
    public ResponseEntity<?> setRequired(@PathVariable String id,
                                          @RequestParam boolean value) {
        return objectRepo.findById(id).map(o -> {
            boolean old = o.isRequired();
            o.setRequired(value);
            objectRepo.save(o);
            return ResponseEntity.ok(Map.of(
                "id", o.getId(), "cimType", o.getCimType(),
                "isRequired", o.isRequired(),
                "changed", old != value,
                "message", "isRequired: " + old + " → " + value
            ));
        }).orElse(ResponseEntity.notFound().build());
    }

    @PatchMapping("/jobs/{jobId}/objects/required")
    public ResponseEntity<?> bulkSetRequired(
            @PathVariable String jobId,
            @RequestParam boolean value,
            @RequestParam(required=false) String category,
            @RequestParam(required=false) String cimType) {

        Criteria criteria = Criteria.where("jobId").is(jobId);
        if (category != null && !category.isBlank())
            criteria = criteria.and("category").is(category.toUpperCase());
        if (cimType != null && !cimType.isBlank())
            criteria = criteria.and("cimType").is(cimType);

        var result = mongoTemplate.updateMulti(
                new Query(criteria), new Update().set("isRequired", value), "cim_objects");

        return ResponseEntity.ok(Map.of(
            "message", "isRequired set to " + value,
            "jobId", jobId,
            "category", category != null ? category : "ALL",
            "cimType",  cimType  != null ? cimType  : "ALL",
            "updated",  result.getModifiedCount()
        ));
    }

    @PatchMapping("/jobs/{jobId}/objects/required/reset")
    public ResponseEntity<?> resetRequired(@PathVariable String jobId) {
        long p = mongoTemplate.updateMulti(
                new Query(Criteria.where("jobId").is(jobId).and("category").is("PHYSICAL")),
                new Update().set("isRequired", true), "cim_objects").getModifiedCount();
        long l = mongoTemplate.updateMulti(
                new Query(Criteria.where("jobId").is(jobId).and("category").is("LOGICAL")),
                new Update().set("isRequired", false), "cim_objects").getModifiedCount();
        return ResponseEntity.ok(Map.of(
            "message", "Reset to defaults",
            "physicalSetTrue", p, "logicalSetFalse", l, "total", p+l
        ));
    }

    @GetMapping("/jobs/{jobId}/objects/required/summary")
    public ResponseEntity<?> requiredSummary(@PathVariable String jobId) {
        long required    = objectRepo.countByJobIdAndIsRequired(jobId, true);
        long notRequired = objectRepo.countByJobIdAndIsRequired(jobId, false);
        long physReq  = countWhere(jobId,"PHYSICAL",true);
        long physOpt  = countWhere(jobId,"PHYSICAL",false);
        long logReq   = countWhere(jobId,"LOGICAL",true);
        long logOpt   = countWhere(jobId,"LOGICAL",false);
        return ResponseEntity.ok(Map.of(
            "jobId", jobId,
            "total", required+notRequired,
            "required", required, "notRequired", notRequired,
            "breakdown", Map.of(
                "PHYSICAL", Map.of("required", physReq, "notRequired", physOpt),
                "LOGICAL",  Map.of("required", logReq,  "notRequired", logOpt)
            )
        ));
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private long countWhere(String jobId, String cat, boolean req) {
        return mongoTemplate.count(new Query(Criteria.where("jobId").is(jobId)
                .and("category").is(cat).and("isRequired").is(req)), "cim_objects");
    }

    private List<Map<String,Object>> getTypeBreakdown(String jobId) {
        try {
            MatchOperation match = Aggregation.match(Criteria.where("jobId").is(jobId));
            GroupOperation group = Aggregation.group("cimType").count().as("count");
            SortOperation  sort  = Aggregation.sort(Sort.by(Sort.Direction.DESC,"count"));
            var results = mongoTemplate.aggregate(
                    Aggregation.newAggregation(match,group,sort),
                    "cim_objects", Document.class);
            List<Map<String,Object>> list = new ArrayList<>();
            for (Document doc : results.getMappedResults()) {
                Object t = doc.get("_id");
                if (t == null || t.toString().isBlank()) continue;
                list.add(Map.of("type", t.toString(), "count", doc.getInteger("count",0)));
            }
            return list;
        } catch (Exception e) { return Collections.emptyList(); }
    }
}
