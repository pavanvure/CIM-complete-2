package com.cim.adapter;

import com.cim.model.cim.CIMObject;
import org.springframework.stereotype.Component;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.InputStream;
import java.util.*;

/**
 * Adapter for IEC CIM RDF/XML format.
 *
 * Handles files from CAISO, PSSE exports, GridAPPS-D, and any
 * standard IEC 61970 RDF serialization.
 *
 * Example input:
 * <rdf:RDF xmlns:cim="http://iec.ch/TC57/2010/CIM-schema-cim15#"
 *          xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
 *   <cim:ACLineSegment rdf:ID="_40eafb00..." cim:mrid="...">
 *     <cim:IdentifiedObject.name>CALCME-OAKWD</cim:IdentifiedObject.name>
 *     <cim:ACLineSegment.r>0.618552</cim:ACLineSegment.r>
 *     <cim:ConductingEquipment.BaseVoltage rdf:resource="#_C4DF..."/>
 *   </cim:ACLineSegment>
 * </rdf:RDF>
 */
@Component
public class RdfXmlAdapter implements CIMFormatAdapter {

    private static final String NS_RDF  = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
    private static final String NS_CIM  = "http://iec.ch/TC57/2010/CIM-schema-cim15#";
    private static final String FORMAT  = "RDF_XML";

    @Override
    public boolean supports(byte[] sample, String fileName) {
        if (fileName != null) {
            String lower = fileName.toLowerCase();
            if (lower.endsWith(".rdf") || lower.endsWith(".xml")) return true;
        }
        String start = new String(sample, 0, Math.min(500, sample.length));
        return start.contains("rdf:RDF") || start.contains("xmlns:cim=")
                || start.contains("CIM-schema");
    }

    @Override
    public String getFormatName() { return FORMAT; }

    @Override
    public List<CIMObject> parse(InputStream inputStream, String fileName) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        // Prevent XXE attacks
        dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        Document doc = dbf.newDocumentBuilder().parse(inputStream);
        doc.getDocumentElement().normalize();

        List<CIMObject> objects = new ArrayList<>();
        NodeList children = doc.getDocumentElement().getChildNodes();

        for (int i = 0; i < children.getLength(); i++) {
            Node node = children.item(i);
            if (node.getNodeType() != Node.ELEMENT_NODE) continue;
            CIMObject obj = parseElement((Element) node, fileName);
            if (obj != null) objects.add(obj);
        }

        resolveReferences(objects);
        return objects;
    }

    private CIMObject parseElement(Element el, String fileName) {
        String localName = el.getLocalName();
        if (localName == null) return null;

        String rdfId = cleanRef(el.getAttributeNS(NS_RDF, "ID"));
        if (rdfId == null || rdfId.isBlank()) {
            rdfId = cleanRef(el.getAttributeNS(NS_RDF, "about"));
        }
        if (rdfId == null || rdfId.isBlank()) return null;

        CIMObject obj = new CIMObject(localName, rdfId);
        obj.setMrid(cleanRef(el.getAttribute("cim:mrid")));
        obj.setOrgId(el.getAttribute("cim:orgId"));
        obj.setVersion(el.getAttribute("cim:version"));
        obj.setSourceFormat(FORMAT);
        obj.setSourceFile(fileName);

        // If mrid empty, use rdfId
        if (obj.getMrid() == null || obj.getMrid().isBlank()) {
            obj.setMrid(rdfId);
        }

        NodeList attrNodes = el.getChildNodes();
        for (int j = 0; j < attrNodes.getLength(); j++) {
            Node child = attrNodes.item(j);
            if (child.getNodeType() != Node.ELEMENT_NODE) continue;
            Element attr = (Element) child;
            String key   = attr.getLocalName();
            if (key == null) continue;

            String ref = cleanRef(attr.getAttributeNS(NS_RDF, "resource"));
            if (ref != null && !ref.isBlank()) {
                obj.addReference(key, ref);
            } else {
                String val = attr.getTextContent();
                obj.setAttribute(key, val != null ? val.trim() : "");
            }
        }
        return obj;
    }

    private void resolveReferences(List<CIMObject> objects) {
        Map<String, CIMObject> byId = new LinkedHashMap<>();
        for (CIMObject o : objects) byId.put(o.getRdfId(), o);
        for (CIMObject o : objects) {
            for (Map.Entry<String, String> ref : o.getReferences().entrySet()) {
                CIMObject target = byId.get(ref.getValue());
                if (target != null) o.addResolved(ref.getKey(), target);
            }
        }
    }

    private String cleanRef(String v) {
        if (v == null) return null;
        v = v.trim();
        if (v.startsWith("#")) v = v.substring(1);
        return v;
    }
}
