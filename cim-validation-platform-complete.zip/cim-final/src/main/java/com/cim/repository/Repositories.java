package com.cim.repository;

import com.cim.model.mongo.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CimClassRepository
        extends MongoRepository<CimClassDefinition, String> {
    Optional<CimClassDefinition> findByClassName(String className);
    List<CimClassDefinition> findByCategory(String category);
    List<CimClassDefinition> findByCimVersion(String version);
    void deleteAllByCimVersion(String version);
}

@Repository
interface ValidationJobRepository
        extends MongoRepository<ValidationJob, String> {
    Optional<ValidationJob> findByJobId(String jobId);
    List<ValidationJob> findTop10ByOrderBySubmittedAtDesc();
    List<ValidationJob> findByNetworkVersion(String networkVersion);
    List<ValidationJob> findByFileHashAndNetworkVersionAndStatusIn(
            String hash, String version, List<String> statuses);
    List<ValidationJob> findByFileNameAndNetworkVersionAndStatusIn(
            String fileName, String version, List<String> statuses);
    List<ValidationJob> findByStatus(String status);
}

@Repository
interface CimObjectRecordRepository
        extends MongoRepository<CimObjectRecord, String> {
    Page<CimObjectRecord>  findByJobId(String jobId, Pageable p);
    List<CimObjectRecord>  findByJobIdAndCimType(String jobId, String cimType);
    List<CimObjectRecord>  findByJobIdAndCategory(String jobId, String category);
    List<CimObjectRecord>  findByJobIdAndIsRequired(String jobId, boolean req);
    List<CimObjectRecord>  findByJobIdAndCategoryAndIsRequired(
            String jobId, String cat, boolean req);
    long countByJobId(String jobId);
    long countByJobIdAndCategory(String jobId, String category);
    long countByJobIdAndIsRequired(String jobId, boolean req);
    void deleteByJobId(String jobId);
}

@Repository
interface Neo4jExportJobRepository
        extends MongoRepository<Neo4jExportJob, String> {
    Optional<Neo4jExportJob> findByExportId(String exportId);
    List<Neo4jExportJob>     findByJobId(String jobId);
    List<Neo4jExportJob>     findTop10ByOrderByStartedAtDesc();
}
