package com.cim.service;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.model.mongo.Neo4jExportJob;
import com.cim.model.mongo.ExportRequest;
import com.cim.model.mongo.ExportRequest.ExportMode;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.repository.Neo4jExportJobRepository;
import com.cim.repository.ValidationJobRepository;
import com.cim.util.MapKeySanitizer;
import org.neo4j.driver.*;
import org.neo4j.driver.exceptions.Neo4jException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;

/**
 * Neo4j Export Service — Simplified High-Performance Version
 *
 * KEY DESIGN DECISIONS:
 *
 * 1. CREATE CONSTRAINT on rdfId per label (not label-less index)
 *    Neo4j 4.x requires a label on every index/constraint.
 *    Label-less index syntax silently fails → MERGE does full scan → O(n) per MERGE
 *    Constraint per label → MERGE uses it → O(log n) always.
 *    We create constraints lazily: first time we see a cimType label.
 *
 * 2. MERGE on rdfId + version + orgId encoded as nodeKey string
 *    Single string property with per-label constraint = fast lookup.
 *
 * 3. Cursor pagination (_id > lastId) = O(1) per page regardless of page number.
 *    Offset pagination (skip N) = O(N) — was causing slowdown past page 100.
 *
 * 4. One session per page batch (all cimTypes share one connection).
 *
 * 5. Two-pass: all nodes first, then all relationships.
 *    Prevents MATCH failures when source/target nodes in different pages.
 *
 * 6. Batch size 2000 (configurable).
 */
@Service
public class Neo4jExportService {

    private static final Logger log =
            LoggerFactory.getLogger(Neo4jExportService.class);

    @Value("${cim.neo4j.export.batch-size:5000}")
    private int batchSize;

    @Value("${cim.neo4j.export.create-constraints:true}")
    private boolean createConstraints;

    private final Driver                    driver;
    private final MongoTemplate             mongo;
    private final CimObjectRecordRepository objectRepo;
    private final Neo4jExportJobRepository  exportRepo;
    private final ValidationJobRepository   jobRepo;

    // Tracks which labels already have a constraint — avoids redundant DDL
    private final Set<String> constrainedLabels = new HashSet<>();

    private Neo4jExportExecutor executor;

    @org.springframework.beans.factory.annotation.Autowired
    public void setExecutor(Neo4jExportExecutor executor) {
        this.executor = executor;
    }

    public Neo4jExportService(Driver driver, MongoTemplate mongo,
                               CimObjectRecordRepository objectRepo,
                               Neo4jExportJobRepository exportRepo,
                               ValidationJobRepository jobRepo) {
        this.driver     = driver;
        this.mongo      = mongo;
        this.objectRepo = objectRepo;
        this.exportRepo = exportRepo;
        this.jobRepo    = jobRepo;
    }

    // ── Start export (returns immediately) ───────────────────────────────

    public Neo4jExportJob startExport(ExportRequest req) {
        String exportId = UUID.randomUUID().toString();
        String version  = jobRepo.findByJobId(req.getJobId())
                .map(j -> j.getNetworkVersion() != null ? j.getNetworkVersion() : "")
                .orElse("");
        String orgId = jobRepo.findByJobId(req.getJobId())
                .map(j -> j.getOrgId() != null ? j.getOrgId() : "")
                .orElse("");
        Neo4jExportJob job = new Neo4jExportJob(
                exportId, req.getJobId(), version, orgId, req.getMode().name());
        exportRepo.save(job);
        executor.runAsync(req, job);
        return job;
    }

    // ── Called by Neo4jExportExecutor on async thread ─────────────────────

    public void runExport(ExportRequest req, Neo4jExportJob job) {
        try {
            job.setStatus("RUNNING");
            exportRepo.save(job);
            long start = System.currentTimeMillis();
            constrainedLabels.clear();

            if (req.isClearFirst()) {
                clearExistingNodes(job.getNetworkVersion(), job.getOrgId());
            }

            // Create ALL constraints upfront — not lazily per page
            // Querying distinct cimTypes once is far cheaper than
            // creating constraints mid-export on every new label encountered
            createAllConstraintsUpfront(req);

            int[] counts = twoPassExport(req, job);

            job.setStatus("DONE");
            job.setNodesExported(counts[0]);
            job.setRelsExported(counts[1]);
            job.setCompletedAt(Instant.now());
            job.setProcessingMs(System.currentTimeMillis() - start);
            exportRepo.save(job);

            log.info("Export DONE: nodes={} rels={} in {}s",
                    counts[0], counts[1],
                    (System.currentTimeMillis() - start) / 1000);

        } catch (Exception e) {
            log.error("Export FAILED: {}", e.getMessage(), e);
            job.setStatus("FAILED");
            job.setErrorMessage(e.getMessage());
            job.setCompletedAt(Instant.now());
            exportRepo.save(job);
        }
    }

    // ── Two-pass: nodes first, then relationships ─────────────────────────

    private int[] twoPassExport(ExportRequest req, Neo4jExportJob job) {
        int totalNodes = 0, totalRels = 0;

        // Count once before loop — never inside
        long total = mongo.count(new Query(buildCriteria(req)), "cim_objects");
        log.info("Pass 1 — exporting {} nodes (batch={})", total, batchSize);

        long start = System.currentTimeMillis();
        String lastId = null;
        int page = 0;

        // ── PASS 1: All nodes ─────────────────────────────────────────────
        while (true) {
            List<CimObjectRecord> batch = fetchPage(req, lastId);
            if (batch.isEmpty()) break;

            totalNodes += writeNodes(batch, job.getNetworkVersion(), job.getOrgId());
            lastId = batch.get(batch.size() - 1).getId();
            page++;

            if (page % 20 == 0) {
                long elapsed = System.currentTimeMillis() - start;
                long rate    = elapsed > 0 ? totalNodes * 1000L / elapsed : 0;
                long etaSec  = rate > 0 ? (total - totalNodes) / rate : -1;
                log.info("Pass 1: page={} nodes={}/{} rate={}/s eta={}min",
                        page, totalNodes, total, rate, etaSec / 60);
                job.setNodesExported(totalNodes);
                exportRepo.save(job);
            }
        }
        log.info("Pass 1 DONE — {} nodes in {}s",
                totalNodes, (System.currentTimeMillis() - start) / 1000);

        // ── PASS 2: All relationships ─────────────────────────────────────
        log.info("Pass 2 — exporting relationships");
        start  = System.currentTimeMillis();
        lastId = null;
        page   = 0;

        while (true) {
            List<CimObjectRecord> batch = fetchPage(req, lastId);
            if (batch.isEmpty()) break;

            totalRels += writeRelationships(batch);
            lastId = batch.get(batch.size() - 1).getId();
            page++;

            if (page % 20 == 0) {
                log.info("Pass 2: page={} rels={}", page, totalRels);
                job.setRelsExported(totalRels);
                exportRepo.save(job);
            }
        }
        log.info("Pass 2 DONE — {} rels in {}s",
                totalRels, (System.currentTimeMillis() - start) / 1000);

        return new int[]{totalNodes, totalRels};
    }

    // ── Cursor-based fetch — O(1) per page ────────────────────────────────

    private List<CimObjectRecord> fetchPage(ExportRequest req, String lastId) {
        Criteria criteria = buildCriteria(req);
        if (lastId != null && !lastId.isBlank()) {
            criteria = new Criteria().andOperator(
                    criteria,
                    Criteria.where("_id").gt(
                            new org.bson.types.ObjectId(lastId)));
        }
        return mongo.find(
                new Query(criteria)
                        .limit(batchSize)
                        .with(Sort.by(Sort.Direction.ASC, "_id")),
                CimObjectRecord.class, "cim_objects");
    }

    // ── Write nodes — constraint per label, one session per batch ─────────

    private int writeNodes(List<CimObjectRecord> records,
                            String version, String orgId) {
        if (records.isEmpty()) return 0;

        // Group by sanitized cimType label
        Map<String, List<Map<String, Object>>> byLabel = new LinkedHashMap<>();
        for (CimObjectRecord rec : records) {
            String label = sanitizeLabel(rec.getCimType());
            byLabel.computeIfAbsent(label, k -> new ArrayList<>())
                   .add(buildNodeProps(rec, version, orgId));
        }

        int written = 0;
        // ONE session for all labels in this batch
        try (Session s = driver.session()) {
            for (Map.Entry<String, List<Map<String, Object>>> e : byLabel.entrySet()) {
                String label = e.getKey();
                List<Map<String, Object>> nodeBatch = e.getValue();

                // Ensure constraint exists for this label (lazy, once per label)
                ensureLabelConstraint(s, label);

                // MERGE on nodeKey — uses per-label constraint = O(log n)
                String cypher =
                    "UNWIND $batch AS p " +
                    "MERGE (n:" + label + " {nodeKey: p.nodeKey}) " +
                    "SET n += p";

                try {
                    final String fc = cypher;
                    final List<Map<String, Object>> fb = nodeBatch;
                    s.writeTransaction(tx -> {
                        tx.run(fc, Values.parameters("batch", fb));
                        return null;
                    });
                    written += nodeBatch.size();
                } catch (Neo4jException ex) {
                    log.warn("Node write failed for {}: {}", label, ex.getMessage());
                }
            }
        } catch (Exception e) {
            log.warn("Session error writeNodes: {}", e.getMessage());
        }
        return written;
    }

    // ── Create constraint per label lazily ────────────────────────────────

    /**
     * Creates constraints for ALL distinct cimTypes in one pass BEFORE export starts.
     * Much faster than lazy per-page creation which blocks each batch.
     */
    private void createAllConstraintsUpfront(ExportRequest req) {
        if (!createConstraints) return;
        log.info("Creating constraints for all cimType labels...");
        long start = System.currentTimeMillis();

        // Get distinct cimTypes for this job
        org.springframework.data.mongodb.core.aggregation.Aggregation agg =
            org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation(
                org.springframework.data.mongodb.core.aggregation.Aggregation.match(buildCriteria(req)),
                org.springframework.data.mongodb.core.aggregation.Aggregation.group("cimType"),
                org.springframework.data.mongodb.core.aggregation.Aggregation.project("_id")
            );
        List<org.bson.Document> results = mongo.aggregate(
                agg, "cim_objects", org.bson.Document.class).getMappedResults();

        int created = 0;
        for (org.bson.Document doc : results) {
            Object ct = doc.get("_id");
            if (ct == null) continue;
            String label = sanitizeLabel(ct.toString());
            if (constrainedLabels.contains(label)) continue;
            try (Session s = driver.session()) {
                s.run("CREATE CONSTRAINT " + label + "_nodekey IF NOT EXISTS " +
                      "ON (n:" + label + ") ASSERT n.nodeKey IS UNIQUE");
                constrainedLabels.add(label);
                created++;
            } catch (Exception e) {
                constrainedLabels.add(label); // mark as handled
                log.debug("Constraint note {}: {}", label, e.getMessage());
            }
        }
        log.info("Constraints ready: {} labels in {}ms",
                constrainedLabels.size(), System.currentTimeMillis() - start);
    }

    /** Per-label constraint check — now only called if not already in constrainedLabels */
    private void ensureLabelConstraint(Session s, String label) {
        if (constrainedLabels.contains(label)) return;
        try {
            s.run("CREATE CONSTRAINT " + label + "_nodekey IF NOT EXISTS " +
                  "ON (n:" + label + ") ASSERT n.nodeKey IS UNIQUE");
            constrainedLabels.add(label);
        } catch (Exception e) {
            constrainedLabels.add(label);
        }
    }

    // ── Write relationships — one session per batch ───────────────────────

    private int writeRelationships(List<CimObjectRecord> records) {
        if (records.isEmpty()) return 0;

        // Build all relationships from resolvedRefIds
        Map<String, List<Map<String, Object>>> byRelType = new LinkedHashMap<>();
        for (CimObjectRecord rec : records) {
            if (rec.getResolvedRefIds() == null || rec.getResolvedRefIds().isEmpty())
                continue;
            String v   = rec.getVersion() != null ? rec.getVersion() : "";
            String o   = rec.getOrgId()   != null ? rec.getOrgId()   : "";
            String src = rec.getRdfId()   != null ? rec.getRdfId()   : "";

            MapKeySanitizer.decodeKeys(rec.getResolvedRefIds())
                    .forEach((key, tgt) -> {
                        Map<String, Object> r = new LinkedHashMap<>();
                        r.put("srcKey", src + "|" + v + "|" + o);
                        r.put("tgtKey", tgt + "|" + v + "|" + o);
                        r.put("version", v);
                        r.put("orgId",   o);
                        String relType = "`" + key.replace("`", "") + "`";
                        byRelType.computeIfAbsent(relType, k -> new ArrayList<>()).add(r);
                    });
        }

        int written = 0;
        // ONE session for all relationship types
        try (Session s = driver.session()) {
            for (Map.Entry<String, List<Map<String, Object>>> e : byRelType.entrySet()) {
                String relType = e.getKey();
                List<Map<String, Object>> relBatch = e.getValue();
                String cypher =
                    "UNWIND $batch AS r " +
                    "MATCH (src {nodeKey: r.srcKey}) " +
                    "MATCH (tgt {nodeKey: r.tgtKey}) " +
                    "MERGE (src)-[:" + relType +
                    " {version: r.version, orgId: r.orgId}]->(tgt)";
                final String fc = cypher;
                final List<Map<String, Object>> fb = relBatch;
                try {
                    s.writeTransaction(tx -> {
                        tx.run(fc, Values.parameters("batch", fb));
                        return null;
                    });
                    written += relBatch.size();
                } catch (Neo4jException ex) {
                    log.warn("Rel write failed {}: {}", relType, ex.getMessage());
                }
            }
        } catch (Exception e) {
            log.warn("Session error writeRelationships: {}", e.getMessage());
        }
        return written;
    }

    // ── Node properties ───────────────────────────────────────────────────

    private Map<String, Object> buildNodeProps(CimObjectRecord rec,
                                                String version, String orgId) {
        Map<String, Object> p = new LinkedHashMap<>();
        String v = version != null ? version : "";
        String o = orgId   != null ? orgId   : "";
        String r = rec.getRdfId() != null ? rec.getRdfId() : "";

        // nodeKey = unique identifier across versions/orgs
        p.put("nodeKey", r + "|" + v + "|" + o);
        p.put("mrid",    rec.getMrid()    != null ? rec.getMrid()    : r);
        p.put("rdfId",   r);
        p.put("name",    rec.getName()    != null ? rec.getName()    : "");
        p.put("cimType", rec.getCimType() != null ? rec.getCimType() : "Unknown");
        p.put("version", v);
        p.put("orgId",   o);
        p.put("uri",     rec.getSourceFile() != null ? rec.getSourceFile() : "");

        // CIM attributes — dot notation keys (ACLineSegment.r etc)
        if (rec.getAttributes() != null) {
            MapKeySanitizer.decodeKeys(rec.getAttributes()).forEach((k, val) -> {
                if (k != null && val != null && !val.isBlank()) p.put(k, val);
            });
        }
        return p;
    }

    // ── Clear existing nodes (batched) ────────────────────────────────────

    private void clearExistingNodes(String version, String orgId) {
        log.info("Clearing nodes version={} orgId={}", version, orgId);
        long total = 0;
        while (true) {
            try (Session s = driver.session()) {
                Result r = s.writeTransaction(tx -> tx.run(
                    "MATCH (n {version: $v, orgId: $o}) " +
                    "WITH n LIMIT 1000 DETACH DELETE n " +
                    "RETURN count(n) AS d",
                    Values.parameters("v", version, "o", orgId)));
                long d = r.single().get("d").asLong();
                total += d;
                if (d == 0) break;
            } catch (Exception e) {
                log.warn("Clear error: {}", e.getMessage());
                break;
            }
        }
        log.info("Cleared {} nodes", total);
    }

    // ── Criteria builder ──────────────────────────────────────────────────

    private Criteria buildCriteria(ExportRequest req) {
        String jobId = req.getJobId();
        if (req.getMode() == ExportMode.PHYSICAL_ONLY) {
            return Criteria.where("jobId").is(jobId).and("category").is("PHYSICAL");
        } else if (req.getMode() == ExportMode.REQUIRED_ONLY) {
            return Criteria.where("jobId").is(jobId).and("isRequired").is(true);
        } else if (req.getMode() == ExportMode.CUSTOM) {
            return Criteria.where("jobId").is(jobId)
                    .and("cimType").in(req.getCimTypes());
        } else if (req.getMode() == ExportMode.TOPOLOGY) {
            List<String> logical = Arrays.asList(
                    "Terminal","ConnectivityNode","TopologicalNode","TopologicalIsland");
            return new Criteria().orOperator(
                    Criteria.where("jobId").is(jobId).and("category").is("PHYSICAL"),
                    Criteria.where("jobId").is(jobId).and("cimType").in(logical));
        }
        // ALL
        return Criteria.where("jobId").is(jobId);
    }

    // ── Label sanitizer ───────────────────────────────────────────────────

    private String sanitizeLabel(String t) {
        if (t == null || t.isBlank()) return "Unknown";
        return t.replaceAll("[^A-Za-z0-9_]", "_");
    }

    // ── Remove legacy :CIMObject labels ──────────────────────────────────

    public long removeCimObjectLabels() {
        long total = 0;
        while (true) {
            try (Session s = driver.session()) {
                Result r = s.writeTransaction(tx -> tx.run(
                    "MATCH (n:CIMObject) WITH n LIMIT 1000 " +
                    "REMOVE n:CIMObject RETURN count(n) AS removed"));
                long removed = r.single().get("removed").asLong();
                total += removed;
                if (removed == 0) break;
                log.info("Removed :CIMObject from {} nodes (total: {})", removed, total);
            } catch (Exception e) {
                log.warn("Label removal: {}", e.getMessage());
                break;
            }
        }
        log.info("Cleanup done — removed :CIMObject from {} nodes", total);
        return total;
    }

    // ── Status ────────────────────────────────────────────────────────────

    public Optional<Neo4jExportJob> getExportStatus(String exportId) {
        return exportRepo.findByExportId(exportId);
    }

    public List<Neo4jExportJob> getRecentExports() {
        return exportRepo.findTop10ByOrderByStartedAtDesc();
    }
}
