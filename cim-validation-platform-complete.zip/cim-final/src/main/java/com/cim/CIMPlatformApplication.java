package com.cim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * CIM Network Data Import + Neo4j Export Platform
 *
 * Pipeline:
 *  1. Admin uploads CPSM OWL → hierarchy registry (category from OWL only)
 *  2. Upload CIM file + networkVersion
 *  3. Stream parse (RDF/XML / JSON-LD / CSV)
 *  4. Save to MongoDB — category/isRequired resolved from OWL registry
 *  5. Path validation — checks attribute tags against OWL hierarchy
 *  6. Resolve cross-references — MongoDB $lookup aggregation
 *  7. Status = RESOLVED
 *  8. Export to Neo4j — selected objects/relationships as graph nodes
 */
@SpringBootApplication
@EnableAsync
public class CIMPlatformApplication {
    public static void main(String[] args) {
        SpringApplication.run(CIMPlatformApplication.class, args);
    }
}
