package com.cim.controller;

import com.cim.service.CIMStandardService;
import com.cim.validation.registry.CIMHierarchyRegistry;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * REST API — Admin / CIM Standard Management
 *
 * POST /api/admin/cim/reload?version=CIM17   Reload CIM hierarchy
 * GET  /api/admin/cim/classes                List all classes
 * GET  /api/admin/cim/classes/{name}         Get class definition
 * GET  /api/admin/cim/chain/{className}      Get inheritance chain
 * POST /api/admin/cim/validate-path          Test a path interactively
 */
@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    private final CIMStandardService   standardService;
    private final CIMHierarchyRegistry registry;
    private final com.cim.repository.CimClassRepository classRepo;

    public AdminController(CIMStandardService standardService,
                           CIMHierarchyRegistry registry,
                           com.cim.repository.CimClassRepository classRepo) {
        this.standardService = standardService;
        this.registry        = registry;
        this.classRepo       = classRepo;
    }

    // ─────────────────────────────────────────────────────────────────────
    // POST /api/admin/cim/reload?version=CIM17
    // Reload the CIM standard from scratch.
    // curl -X POST "http://localhost:8080/api/admin/cim/reload?version=CIM17"
    // ─────────────────────────────────────────────────────────────────────
    @PostMapping("/cim/reload")
    public ResponseEntity<?> reloadStandard(
            @RequestParam(defaultValue = "CIM17") String version) {
        try {
            standardService.reloadCIMStandard(version);
            return ResponseEntity.ok(Map.of(
                "status",        "OK",
                "version",       version,
                "classesLoaded", registry.size(),
                "message",       "CIM standard reloaded successfully."
            ));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage()));
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/admin/cim/classes
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/cim/classes")
    public ResponseEntity<?> listClasses(
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String cimPackage) {

        var classes = category != null
                ? classRepo.findByCategory(category.toUpperCase())
                : classRepo.findAll();

        return ResponseEntity.ok(Map.of(
            "totalClasses", classes.size(),
            "classes",      classes
        ));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/admin/cim/classes/{name}
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/cim/classes/{name}")
    public ResponseEntity<?> getClass(@PathVariable String name) {
        var def = registry.getDefinition(name);
        if (def == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(Map.of(
            "className",     def.getClassName(),
            "parentClass",   def.getParentClass() != null ? def.getParentClass() : "ROOT",
            "ancestors",     def.getAncestors(),
            "ownAttributes", def.getOwnAttributes(),
            "category",      def.getCategory() != null ? def.getCategory() : "UNKNOWN",
            "cimPackage",    def.getCimPackage() != null ? def.getCimPackage() : "Unknown",
            "cimVersion",    def.getCimVersion()
        ));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/admin/cim/chain/{className}
    // Get full inheritance chain for a class.
    // curl http://localhost:8080/api/admin/cim/chain/ACLineSegment
    // → ["ACLineSegment","Conductor","ConductingEquipment","Equipment",
    //    "PowerSystemResource","IdentifiedObject"]
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/cim/chain/{className}")
    public ResponseEntity<?> getChain(@PathVariable String className) {
        if (!registry.isKnownClass(className)) {
            return ResponseEntity.notFound().build();
        }
        var chain = registry.getFullChain(className);
        return ResponseEntity.ok(Map.of(
            "className",        className,
            "inheritanceChain", chain,
            "depth",            chain.size()
        ));
    }

    // ─────────────────────────────────────────────────────────────────────
    // POST /api/admin/cim/validate-path
    // Interactive path checker — test any attribute tag against any type.
    //
    // curl -X POST http://localhost:8080/api/admin/cim/validate-path \
    //   -H "Content-Type: application/json" \
    //   -d '{"objectType":"ACLineSegment","attributeTag":"ConductingEquipment.BaseVoltage"}'
    //
    // Response:
    // { "status": "VALID",
    //   "explanation": "ACLineSegment -> Conductor -> ConductingEquipment [declares BaseVoltage]",
    //   "inheritanceChain": [...] }
    // ─────────────────────────────────────────────────────────────────────
    @PostMapping("/cim/validate-path")
    public ResponseEntity<?> validatePath(@RequestBody Map<String, String> body) {
        String objectType   = body.get("objectType");
        String attributeTag = body.get("attributeTag");

        if (objectType == null || attributeTag == null) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error",
                            "Both 'objectType' and 'attributeTag' are required."));
        }

        var result = registry.validateAttributePath(objectType, attributeTag);
        var chain  = registry.getFullChain(objectType);

        return ResponseEntity.ok(Map.of(
            "objectType",        objectType,
            "attributeTag",      attributeTag,
            "status",            result.getStatus().name(),
            "valid",             result.isValid(),
            "explanation",       result.getExplanation(),
            "inheritanceChain",  chain
        ));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/admin/cim/stats
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/cim/stats")
    public ResponseEntity<?> getStats() {
        long physical = classRepo.findByCategory("PHYSICAL").size();
        long logical  = classRepo.findByCategory("LOGICAL").size();
        return ResponseEntity.ok(Map.of(
            "totalClasses",    registry.size(),
            "physicalClasses", physical,
            "logicalClasses",  logical,
            "registryLoaded",  registry.isLoaded()
        ));
    }
}
