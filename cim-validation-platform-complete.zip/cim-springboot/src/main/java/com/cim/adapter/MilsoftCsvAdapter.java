package com.cim.adapter;

import com.cim.model.cim.CIMObject;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Component;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Adapter for Milsoft / CSV-based CIM export format.
 *
 * Milsoft WindMil exports power system data in CSV format.
 * This adapter handles two CSV layouts:
 *
 * Layout A — Milsoft native (each row = one equipment instance):
 *   Type,ID,Name,KV,R1,X1,B1,FromBus,ToBus,...
 *   Line,L001,Main_Feeder_1,12.47,0.306,0.627,0.0,BUS_A,BUS_B,...
 *
 * Layout B — Generic CIM CSV (each row = one attribute of one object):
 *   rdfId,cimType,attributeKey,attributeValue,isReference,targetRdfId
 *   _uuid1,ACLineSegment,ACLineSegment.r,0.618,,
 *   _uuid1,ACLineSegment,ConductingEquipment.BaseVoltage,,true,_bv-uuid
 *
 * The adapter auto-detects which layout is being used.
 */
@Component
public class MilsoftCsvAdapter implements CIMFormatAdapter {

    private static final String FORMAT = "MILSOFT_CSV";

    // Milsoft type → CIM class name mapping
    private static final Map<String, String> MILSOFT_TYPE_MAP = Map.ofEntries(
        Map.entry("Line",         "ACLineSegment"),
        Map.entry("LINE",         "ACLineSegment"),
        Map.entry("Transformer",  "PowerTransformer"),
        Map.entry("TRANSFORMER",  "PowerTransformer"),
        Map.entry("Xfmr",         "PowerTransformer"),
        Map.entry("Breaker",      "Breaker"),
        Map.entry("BREAKER",      "Breaker"),
        Map.entry("Recloser",     "Recloser"),
        Map.entry("RECLOSER",     "Recloser"),
        Map.entry("Fuse",         "Fuse"),
        Map.entry("FUSE",         "Fuse"),
        Map.entry("Capacitor",    "LinearShuntCompensator"),
        Map.entry("CAP",          "LinearShuntCompensator"),
        Map.entry("Load",         "EnergyConsumer"),
        Map.entry("LOAD",         "EnergyConsumer"),
        Map.entry("Generator",    "SynchronousMachine"),
        Map.entry("GEN",          "SynchronousMachine"),
        Map.entry("Switch",       "Switch"),
        Map.entry("Node",         "ConnectivityNode"),
        Map.entry("Bus",          "ConnectivityNode"),
        Map.entry("BUS",          "ConnectivityNode"),
        Map.entry("Source",       "EnergySource"),
        Map.entry("Substation",   "Substation")
    );

    @Override
    public boolean supports(byte[] sample, String fileName) {
        if (fileName != null) {
            String lower = fileName.toLowerCase();
            if (lower.endsWith(".csv") || lower.endsWith(".txt")) {
                String start = new String(sample, 0, Math.min(200, sample.length)).toLowerCase();
                // Milsoft header detection
                return start.contains("type,") || start.contains("rdfid,cimtype")
                        || start.contains("id,name,kv") || start.contains("line,")
                        || start.contains("transformer,");
            }
        }
        return false;
    }

    @Override
    public String getFormatName() { return FORMAT; }

    @Override
    public List<CIMObject> parse(InputStream inputStream, String fileName) throws Exception {
        byte[] bytes = inputStream.readAllBytes();
        String content = new String(bytes, StandardCharsets.UTF_8);
        String firstLine = content.split("\n")[0].trim().toLowerCase();

        if (firstLine.startsWith("rdfid,cimtype") || firstLine.startsWith("id,type,")) {
            return parseGenericCimCsv(new ByteArrayInputStream(bytes), fileName);
        } else {
            return parseMilsoftNative(new ByteArrayInputStream(bytes), fileName);
        }
    }

    // ── Layout B: Generic CIM CSV ─────────────────────────────────────────

    private List<CIMObject> parseGenericCimCsv(InputStream is, String fileName)
            throws Exception {
        Map<String, CIMObject> byId = new LinkedHashMap<>();

        try (CSVParser parser = CSVParser.parse(is, StandardCharsets.UTF_8,
                CSVFormat.DEFAULT.withFirstRecordAsHeader().withTrim())) {

            for (CSVRecord row : parser) {
                String rdfId    = row.get("rdfId");
                String cimType  = row.get("cimType");
                String attrKey  = row.get("attributeKey");
                String attrVal  = safeGet(row, "attributeValue");
                boolean isRef   = "true".equalsIgnoreCase(safeGet(row, "isReference"));
                String targetId = safeGet(row, "targetRdfId");

                if (rdfId == null || rdfId.isBlank()) continue;

                CIMObject obj = byId.computeIfAbsent(rdfId, id -> {
                    CIMObject o = new CIMObject(cimType, id);
                    o.setMrid(id);
                    o.setSourceFormat(FORMAT);
                    o.setSourceFile(fileName);
                    return o;
                });

                if (isRef && targetId != null && !targetId.isBlank()) {
                    obj.addReference(attrKey, targetId);
                } else if (attrVal != null && !attrVal.isBlank()) {
                    obj.setAttribute(attrKey, attrVal);
                }
            }
        }

        List<CIMObject> objects = new ArrayList<>(byId.values());
        resolveReferences(objects);
        return objects;
    }

    // ── Layout A: Milsoft Native CSV ──────────────────────────────────────

    private List<CIMObject> parseMilsoftNative(InputStream is, String fileName)
            throws Exception {
        List<CIMObject> objects = new ArrayList<>();
        Map<String, String> busIdMap = new LinkedHashMap<>(); // busName → rdfId

        try (CSVParser parser = CSVParser.parse(is, StandardCharsets.UTF_8,
                CSVFormat.DEFAULT.withFirstRecordAsHeader().withTrim())) {

            List<String> headers = parser.getHeaderNames();

            for (CSVRecord row : parser) {
                String milsoftType = safeGet(row, "Type");
                String id          = safeGet(row, "ID");
                String name        = safeGet(row, "Name");
                String kv          = safeGet(row, "KV");

                if (milsoftType == null || milsoftType.isBlank()) continue;

                String cimType = MILSOFT_TYPE_MAP.getOrDefault(milsoftType, milsoftType);
                String rdfId   = "_" + (id != null && !id.isBlank() ? id : UUID.randomUUID().toString());

                CIMObject obj = new CIMObject(cimType, rdfId);
                obj.setMrid(rdfId);
                obj.setSourceFormat(FORMAT);
                obj.setSourceFile(fileName);

                // Map name
                if (name != null && !name.isBlank()) {
                    obj.setAttribute("IdentifiedObject.name", name);
                }

                // Map voltage to BaseVoltage concept
                if (kv != null && !kv.isBlank()) {
                    obj.setAttribute("ConductingEquipment.nominalVoltage_kv", kv);
                }

                // Map remaining columns by header
                for (String header : headers) {
                    if (List.of("Type","ID","Name","KV").contains(header)) continue;
                    String val = safeGet(row, header);
                    if (val == null || val.isBlank()) continue;

                    String mappedKey = mapMilsoftColumn(cimType, header);
                    if (mappedKey.endsWith("_REF")) {
                        // It's a bus reference — store for later linking
                        String busRef = "_BUS_" + val.replaceAll("\\s+","_");
                        busIdMap.put(val, busRef);
                        obj.addReference(mappedKey.replace("_REF",""), busRef);
                    } else {
                        obj.setAttribute(mappedKey, val);
                    }
                }

                objects.add(obj);
            }
        }

        // Create ConnectivityNode objects for buses found in references
        for (Map.Entry<String, String> bus : busIdMap.entrySet()) {
            CIMObject cn = new CIMObject("ConnectivityNode", bus.getValue());
            cn.setMrid(bus.getValue());
            cn.setAttribute("IdentifiedObject.name", bus.getKey());
            cn.setSourceFormat(FORMAT);
            cn.setSourceFile(fileName);
            objects.add(cn);
        }

        resolveReferences(objects);
        return objects;
    }

    /** Maps Milsoft column names to CIM attribute keys */
    private String mapMilsoftColumn(String cimType, String column) {
        return switch (column.toUpperCase()) {
            case "R1", "R"   -> "ACLineSegment.r";
            case "X1", "X"   -> "ACLineSegment.x";
            case "B1", "B"   -> "ACLineSegment.bch";
            case "R0"        -> "ACLineSegment.r0";
            case "X0"        -> "ACLineSegment.x0";
            case "B0"        -> "ACLineSegment.b0ch";
            case "LENGTH","LEN" -> "Conductor.length";
            case "FROMBUS","FROM_BUS","FROM" -> "Equipment.EquipmentContainer_REF";
            case "TOBUS","TO_BUS","TO"       -> "Equipment.toNode_REF";
            case "RATEDKVA","RATEDMVA","KVA" -> "PowerTransformerEnd.ratedS";
            case "PHASES"    -> "ACLineSegment.phases";
            case "NORMALLY_OPEN","NO","NORMOPEN" -> "Switch.normalOpen";
            case "P","KW"    -> "EnergyConsumer.p";
            case "Q","KVAR"  -> "EnergyConsumer.q";
            default          -> cimType + "." + column.toLowerCase();
        };
    }

    private void resolveReferences(List<CIMObject> objects) {
        Map<String, CIMObject> byId = new LinkedHashMap<>();
        for (CIMObject o : objects) byId.put(o.getRdfId(), o);
        for (CIMObject o : objects) {
            for (Map.Entry<String, String> ref : o.getReferences().entrySet()) {
                CIMObject target = byId.get(ref.getValue());
                if (target != null) o.addResolved(ref.getKey(), target);
            }
        }
    }

    private String safeGet(CSVRecord row, String col) {
        try { return row.get(col); } catch (Exception e) { return null; }
    }
}
