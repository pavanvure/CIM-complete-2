package com.cim.service;

import com.cim.model.mongo.CimClassDefinition;
import com.cim.repository.CimClassRepository;
import com.cim.validation.registry.CIMHierarchyRegistry;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Loads the CIM17 class hierarchy into MongoDB and the in-memory registry.
 * Runs automatically on application startup.
 * Admin can trigger reload via POST /api/admin/cim/reload.
 */
@Service
public class CIMStandardService {

    private final CimClassRepository mongoRepo;
    private final CIMHierarchyRegistry registry;

    public CIMStandardService(CimClassRepository mongoRepo,
                               CIMHierarchyRegistry registry) {
        this.mongoRepo = mongoRepo;
        this.registry  = registry;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void initOnStartup() {
        if (mongoRepo.count() == 0) {
            seedCIMStandard("CIM17");
        } else {
            registry.load(mongoRepo.findAll());
        }
    }

    public void reloadCIMStandard(String version) {
        mongoRepo.deleteAll();
        seedCIMStandard(version);
    }

    // ── Build and persist CIM hierarchy ───────────────────────────────────

    private void seedCIMStandard(String version) {
        List<CimClassDefinition> defs = buildDefinitions(version);
        mongoRepo.saveAll(defs);
        registry.load(defs);
    }

    private List<CimClassDefinition> buildDefinitions(String version) {
        Map<String, String>        parents  = getParentMap();
        Map<String, List<String>>  attrs    = getAttributeMap();
        Map<String, String>        packages = getPackageMap();
        Set<String>                logical  = getLogicalClasses();

        List<CimClassDefinition> defs = new ArrayList<>();

        for (Map.Entry<String, String> e : parents.entrySet()) {
            String cls    = e.getKey();
            String parent = e.getValue();
            List<String> ancestors = computeAncestors(cls, parents);
            String category = logical.contains(cls) ? "LOGICAL" : "PHYSICAL";

            CimClassDefinition def = new CimClassDefinition(
                    cls, parent, ancestors,
                    attrs.getOrDefault(cls, new ArrayList<>()),
                    category, version);
            def.setCimPackage(packages.getOrDefault(cls, "Core"));
            defs.add(def);
        }

        // Root
        CimClassDefinition root = new CimClassDefinition(
                "IdentifiedObject", null, new ArrayList<>(),
                List.of("name","mRID","description","aliasName"),
                "LOGICAL", version);
        root.setCimPackage("Core");
        defs.add(root);

        return defs;
    }

    private List<String> computeAncestors(String cls, Map<String, String> parents) {
        List<String> ancestors = new ArrayList<>();
        Set<String>  visited   = new HashSet<>();
        String       current   = parents.get(cls);
        while (current != null && !visited.contains(current)) {
            ancestors.add(current);
            visited.add(current);
            current = parents.get(current);
        }
        return ancestors;
    }

    // ── CIM17 Hierarchy Data ───────────────────────────────────────────────

    private Map<String, String> getParentMap() {
        return new LinkedHashMap<>() {{
            // Wires package — Conductors
            put("ACLineSegment",              "Conductor");
            put("Conductor",                  "ConductingEquipment");
            put("ConductingEquipment",        "Equipment");
            put("Equipment",                  "PowerSystemResource");
            put("PowerSystemResource",        "IdentifiedObject");

            // Wires — Switches (PNNL Section 8: Fuse NOT from ProtectedSwitch)
            put("Breaker",                    "ProtectedSwitch");
            put("Recloser",                   "ProtectedSwitch");
            put("LoadBreakSwitch",            "ProtectedSwitch");
            put("ProtectedSwitch",            "Switch");
            put("Fuse",                       "Switch");        // NOT ProtectedSwitch
            put("Disconnector",               "Switch");
            put("GroundDisconnector",         "Switch");
            put("Sectionaliser",              "Switch");
            put("Jumper",                     "Switch");
            put("CompositeSwitch",            "Equipment");
            put("Switch",                     "ConductingEquipment");

            // Wires — Transformers (PNNL Section 7)
            put("PowerTransformer",           "ConductingEquipment");
            put("TransformerTank",            "Equipment");
            put("TransformerEnd",             "IdentifiedObject");
            put("PowerTransformerEnd",        "TransformerEnd");
            put("TransformerTankEnd",         "TransformerEnd");
            put("TransformerWinding",         "ConductingEquipment");
            put("RatioTapChanger",            "TapChanger");
            put("PhaseTapChangerLinear",      "TapChanger");
            put("TapChanger",                 "PowerSystemResource");

            // Wires — Reactive (PNNL Section 9 — ShuntCompensator extends RegulatingCondEq)
            put("LinearShuntCompensator",     "ShuntCompensator");
            put("NonLinearShuntCompensator",  "ShuntCompensator");
            put("ShuntCompensator",           "RegulatingCondEq");
            put("StaticVarCompensator",       "RegulatingCondEq");
            put("SeriesCompensator",          "ConductingEquipment");
            put("RegulatingCondEq",           "EnergyConnection");
            put("EnergyConnection",           "ConductingEquipment");

            // Wires — Machines (PNNL Section 11 — via RotatingMachine)
            put("SynchronousMachine",         "RotatingMachine");
            put("AsynchronousMachine",        "RotatingMachine");
            put("RotatingMachine",            "RegulatingCondEq");
            put("BusbarSection",              "ConductingEquipment");

            // Generation package
            put("GeneratingUnit",             "Equipment");
            put("HydroGeneratingUnit",        "GeneratingUnit");
            put("ThermalGeneratingUnit",      "GeneratingUnit");
            put("WindGeneratingUnit",         "GeneratingUnit");
            put("NuclearGeneratingUnit",      "GeneratingUnit");
            put("SolarGeneratingUnit",        "GeneratingUnit");

            // DER (PNNL Section 12)
            put("PowerElectronicsConnection", "RegulatingCondEq");
            put("PowerElectronicsConnectionPhase","PowerSystemResource");
            put("PowerElectronicsUnit",       "Equipment");
            put("BatteryUnit",                "PowerElectronicsUnit");
            put("PhotoVoltaicUnit",           "PowerElectronicsUnit");
            put("PowerElectronicsWindUnit",   "PowerElectronicsUnit");

            // Loads (PNNL Section 10)
            put("EnergyConsumer",             "EnergyConnection");
            put("EnergyConsumerPhase",        "PowerSystemResource");
            put("ConformLoad",                "EnergyConsumer");
            put("NonConformLoad",             "EnergyConsumer");
            put("StationSupply",              "EnergyConsumer");

            // Containers
            put("Line",                       "EquipmentContainer");
            put("Substation",                 "EquipmentContainer");
            put("VoltageLevel",               "EquipmentContainer");
            put("Bay",                        "EquipmentContainer");
            put("Feeder",                     "EquipmentContainer");
            put("EquipmentContainer",         "ConnectivityNodeContainer");
            put("ConnectivityNodeContainer",  "PowerSystemResource");

            // Geography
            put("GeographicalRegion",         "IdentifiedObject");
            put("SubGeographicalRegion",      "IdentifiedObject");
            put("BaseVoltage",                "IdentifiedObject");

            // Limits
            put("OperationalLimitSet",        "IdentifiedObject");
            put("CurrentLimit",               "IdentifiedObject");
            put("ActivePowerLimit",           "IdentifiedObject");
            put("ApparentPowerLimit",         "IdentifiedObject");

            // Topology (Logical)
            put("ConnectivityNode",           "IdentifiedObject");
            put("TopologicalNode",            "IdentifiedObject");
            put("TopologicalIsland",          "IdentifiedObject");
            put("Terminal",                   "ACDCTerminal");
            put("ACDCTerminal",               "IdentifiedObject");

            // Measurements (Logical)
            put("Measurement",                "IdentifiedObject");
            put("Accumulator",                "Measurement");
            put("Analog",                     "Measurement");
            put("Discrete",                   "Measurement");
            put("AccumulatorValue",           "IdentifiedObject");
            put("AnalogValue",                "IdentifiedObject");
            put("DiscreteValue",              "IdentifiedObject");

            // Load Areas (Logical)
            put("LoadArea",                   "EnergyArea");
            put("SubLoadArea",                "EnergyArea");
            put("EnergyArea",                 "IdentifiedObject");
            put("LoadGroup",                  "IdentifiedObject");
            put("ConformLoadGroup",           "LoadGroup");
            put("NonConformLoadGroup",        "LoadGroup");
        }};
    }

    private Map<String, List<String>> getAttributeMap() {
        return new LinkedHashMap<>() {{
            put("IdentifiedObject",     List.of("name","mRID","description","aliasName"));
            put("PowerSystemResource",  List.of("assetDataSheet","location"));
            put("Equipment",            List.of("aggregate","normallyInService",
                                                 "networkAnalysisEnabled","inService",
                                                 "EquipmentContainer","emsFlag","NAFlag"));
            put("ConductingEquipment",  List.of("BaseVoltage"));
            put("Conductor",            List.of("length"));
            put("ACLineSegment",        List.of("r","r0","x","x0","x2","bch","b0ch",
                                                 "gch","g0ch","shortCircuitEndTemperature",
                                                 "weccSchedulingPath","rtCompetitiveConstraint",
                                                 "daConstraintEnforcementFlag","daCompetitiveConstraint"));
            put("Switch",               List.of("normalOpen","open","ratedCurrent",
                                                 "retained","locked","switchOnCount"));
            put("ProtectedSwitch",      List.of("breakingCapacity"));
            put("Breaker",              List.of("inTransitTime"));
            put("BaseVoltage",          List.of("nominalVoltage"));
            put("EquipmentContainer",   List.of("emsFlag"));
            put("GeneratingUnit",       List.of("maxOperatingP","minOperatingP","nominalP",
                                                 "ratedNetMaxP","ratedGrossMaxP","ratedGrossMinP",
                                                 "genControlSource"));
            put("PowerTransformer",     List.of("isPartOfGeneratorUnit","vectorGroup",
                                                 "beforeShCircuitHighestOperatingCurrent",
                                                 "beforeShCircuitHighestOperatingVoltage"));
            put("EnergyConsumer",       List.of("customerCount","grounded","p","pfixed",
                                                 "pfixedPct","q","qfixed","qfixedPct",
                                                 "phaseConnection"));
            put("ShuntCompensator",     List.of("aVRDelay","grounded","maximumSections",
                                                 "nomU","normalSections","sections",
                                                 "voltageSensitivity","phaseConnection"));
            put("LinearShuntCompensator",List.of("bPerSection","gPerSection",
                                                  "b0PerSection","g0PerSection"));
            put("TapChanger",           List.of("controlEnabled","highStep","lowStep",
                                                 "ltcFlag","neutralStep","neutralU",
                                                 "normalStep","step","subsequentDelay"));
            put("RatioTapChanger",      List.of("stepVoltageIncrement","tculControlMode"));
        }};
    }

    private Map<String, String> getPackageMap() {
        return Map.ofEntries(
            Map.entry("ACLineSegment","Wires"), Map.entry("Conductor","Wires"),
            Map.entry("Breaker","Wires"), Map.entry("Switch","Wires"),
            Map.entry("PowerTransformer","Wires"), Map.entry("ShuntCompensator","Wires"),
            Map.entry("SynchronousMachine","Wires"), Map.entry("GeneratingUnit","Production"),
            Map.entry("EnergyConsumer","Wires"), Map.entry("ConnectivityNode","Topology"),
            Map.entry("TopologicalNode","Topology"), Map.entry("Terminal","Core"),
            Map.entry("Measurement","Meas"), Map.entry("Analog","Meas"),
            Map.entry("Substation","Core"), Map.entry("VoltageLevel","Core"),
            Map.entry("GeographicalRegion","Core"), Map.entry("BaseVoltage","Core"),
            Map.entry("LoadArea","LoadModel"), Map.entry("ConformLoadGroup","LoadModel"),
            Map.entry("PowerElectronicsConnection","Wires"),
            Map.entry("BatteryUnit","Production"), Map.entry("PhotoVoltaicUnit","Production")
        );
    }

    private Set<String> getLogicalClasses() {
        return Set.of(
            "ConnectivityNode","TopologicalNode","TopologicalIsland",
            "Terminal","ACDCTerminal","Measurement","Accumulator","Analog","Discrete",
            "AccumulatorValue","AnalogValue","DiscreteValue","MeasurementValue",
            "LoadArea","SubLoadArea","EnergyArea","LoadGroup",
            "ConformLoadGroup","NonConformLoadGroup",
            "RegulatingControl","RegulationSchedule","TapChangerControl",
            "ConformLoadSchedule","NonConformLoadSchedule","RegularTimePoint",
            "BranchGroup","BranchGroupTerminal","LossShare",
            "Name","NameType","Location","PowerCutZone"
        );
    }
}
