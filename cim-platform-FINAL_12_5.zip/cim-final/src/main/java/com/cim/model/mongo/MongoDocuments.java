package com.cim.model.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.*;

// ═══════════════════════════════════════════════════════════════════
// CimClassDefinition — loaded from CPSM OWL, category from OWL only
// ═══════════════════════════════════════════════════════════════════
@Document(collection = "cim_standard_owl")
public class CimClassDefinition {
    @Id private String id;
    @Indexed(unique = true)
    private String       className;
    private String       parentClass;
    private List<String> ancestors     = new ArrayList<>();
    private List<String> ownAttributes = new ArrayList<>();
    private String       category;     // PHYSICAL or LOGICAL — from OWL
    private boolean      required;     // true=PHYSICAL, false=LOGICAL
    private String       cimPackage;
    private String       stereotype;
    private String       cimVersion;
    private String       description;
    private Instant      loadedAt;

    public CimClassDefinition() {}
    public CimClassDefinition(String className, String parentClass,
                               List<String> ancestors, List<String> ownAttributes,
                               String category, String cimVersion) {
        this.className=className; this.parentClass=parentClass;
        this.ancestors=ancestors!=null?ancestors:new ArrayList<>();
        this.ownAttributes=ownAttributes!=null?ownAttributes:new ArrayList<>();
        this.category=category; this.cimVersion=cimVersion;
        this.required="PHYSICAL".equals(category); this.loadedAt=Instant.now();
    }
    public boolean isAncestorOrSelf(String n) { return className.equals(n)||ancestors.contains(n); }
    public String  getId()                          { return id; }
    public String  getClassName()                   { return className; }
    public void    setClassName(String v)           { this.className=v; }
    public String  getParentClass()                 { return parentClass; }
    public void    setParentClass(String v)         { this.parentClass=v; }
    public List<String> getAncestors()              { return ancestors; }
    public void    setAncestors(List<String> v)     { this.ancestors=v; }
    public List<String> getOwnAttributes()          { return ownAttributes; }
    public void    setOwnAttributes(List<String> v) { this.ownAttributes=v; }
    public String  getCategory()                    { return category; }
    public void    setCategory(String v)            { this.category=v; this.required="PHYSICAL".equals(v); }
    public boolean isRequired()                     { return required; }
    public void    setRequired(boolean v)           { this.required=v; }
    public String  getCimPackage()                  { return cimPackage; }
    public void    setCimPackage(String v)          { this.cimPackage=v; }
    public String  getStereotype()                  { return stereotype; }
    public void    setStereotype(String v)          { this.stereotype=v; }
    public String  getCimVersion()                  { return cimVersion; }
    public void    setCimVersion(String v)          { this.cimVersion=v; }
    public String  getDescription()                 { return description; }
    public void    setDescription(String v)         { this.description=v; }
    public Instant getLoadedAt()                    { return loadedAt; }
    public void    setLoadedAt(Instant v)           { this.loadedAt=v; }
}

// ═══════════════════════════════════════════════════════════════════
// NamespaceConfig — user-defined namespace settings (REQ #2)
// Stored in MongoDB. Controls what gets parsed and stored.
// ═══════════════════════════════════════════════════════════════════
@Document(collection = "namespace_configs")
public class NamespaceConfig {
    @Id private String id;

    /**
     * Short prefix used in RDF files.
     * e.g. "cim", "caiso", "spc", "ercot"
     */
    private String prefix;

    /**
     * Full namespace URI.
     * e.g. "http://ucaiug.org/2020/CPSM-CoreEquipment#"
     */
    private String namespaceUri;

    /**
     * Whether to process attributes/references from this namespace.
     *   true  = store attributes and references (no path validation for non-CIM)
     *   false = skip attributes, log as UNKNOWN_NAMESPACE in pathIssues
     */
    private boolean enabled;

    /**
     * Whether to perform path validation for this namespace.
     *   true  = validate attribute tags against OWL hierarchy (CIM namespaces)
     *   false = store as-is, no path validation (custom/vendor namespaces)
     */
    private boolean validatePath;

    /** Human-readable description of this namespace */
    private String description;

    /** Who created this config */
    private String createdBy;
    private Instant createdAt;
    private Instant updatedAt;

    public NamespaceConfig() {}
    public NamespaceConfig(String prefix, String uri, boolean enabled,
                            boolean validatePath, String description) {
        this.prefix=prefix; this.namespaceUri=uri; this.enabled=enabled;
        this.validatePath=validatePath; this.description=description;
        this.createdAt=Instant.now(); this.updatedAt=Instant.now();
    }

    public String  getId()                      { return id; }
    public String  getPrefix()                  { return prefix; }
    public void    setPrefix(String v)          { this.prefix=v; }
    public String  getNamespaceUri()            { return namespaceUri; }
    public void    setNamespaceUri(String v)    { this.namespaceUri=v; }
    public boolean isEnabled()                  { return enabled; }
    public void    setEnabled(boolean v)        { this.enabled=v; this.updatedAt=Instant.now(); }
    public boolean isValidatePath()             { return validatePath; }
    public void    setValidatePath(boolean v)   { this.validatePath=v; this.updatedAt=Instant.now(); }
    public String  getDescription()             { return description; }
    public void    setDescription(String v)     { this.description=v; }
    public String  getCreatedBy()               { return createdBy; }
    public void    setCreatedBy(String v)       { this.createdBy=v; }
    public Instant getCreatedAt()               { return createdAt; }
    public void    setCreatedAt(Instant v)      { this.createdAt=v; }
    public Instant getUpdatedAt()               { return updatedAt; }
    public void    setUpdatedAt(Instant v)      { this.updatedAt=v; }
}

// ═══════════════════════════════════════════════════════════════════
// StageTimings — per-stage processing times (REQ #6)
// ═══════════════════════════════════════════════════════════════════
public class StageTimings {
    private Long parseMs;          // stream parse + save
    private Long pathValidationMs; // path validation (inline during parse)
    private Long referenceMs;      // reference resolution ($lookup)
    private Long neo4jExportMs;    // neo4j export (if triggered)
    private Long totalMs;          // end-to-end

    public Long getParseMs()             { return parseMs; }
    public void setParseMs(Long v)       { this.parseMs=v; }
    public Long getPathValidationMs()    { return pathValidationMs; }
    public void setPathValidationMs(Long v){ this.pathValidationMs=v; }
    public Long getReferenceMs()         { return referenceMs; }
    public void setReferenceMs(Long v)   { this.referenceMs=v; }
    public Long getNeo4jExportMs()       { return neo4jExportMs; }
    public void setNeo4jExportMs(Long v) { this.neo4jExportMs=v; }
    public Long getTotalMs()             { return totalMs; }
    public void setTotalMs(Long v)       { this.totalMs=v; }
}

// ═══════════════════════════════════════════════════════════════════
// ValidationJob — one record per imported file
// Enhanced: orgId, stageTimings, enabledNamespaces (REQ #1, #2, #6)
// ═══════════════════════════════════════════════════════════════════
@Document(collection = "validation_jobs")
class ValidationJob {
    @Id private String id;
    @Indexed(unique = true)
    private String  jobId;
    private String  fileName;
    private String  fileFormat;
    private String  networkVersion;
    private String  fileHash;
    private String  status;
    private String  submittedBy;

    /** REQ #1 — Organisation ID */
    private String  orgId;

    private int     totalObjects;
    private int     physicalObjects;
    private int     logicalObjects;
    private int     pathIssueCount;    // objects with path issues
    private String  errorMessage;
    private long    processingMs;

    /** REQ #6 — Per-stage timing breakdown */
    private StageTimings stageTimings = new StageTimings();

    /**
     * REQ #2 — Namespace prefixes enabled for this import.
     * Stored at job level so each import can have different settings.
     * e.g. ["cim", "caiso"] = store cim + caiso attributes
     */
    private List<String> enabledNamespaces = new ArrayList<>();

    private Instant submittedAt;
    private Instant completedAt;

    public ValidationJob() {}
    public ValidationJob(String jobId, String fileName, String fileFormat,
                          String submittedBy, String networkVersion, String orgId) {
        this.jobId=jobId; this.fileName=fileName; this.fileFormat=fileFormat;
        this.submittedBy=submittedBy; this.networkVersion=networkVersion;
        this.orgId=orgId; this.status="PENDING"; this.submittedAt=Instant.now();
    }

    public String  getId()                          { return id; }
    public String  getJobId()                       { return jobId; }
    public void    setJobId(String v)               { this.jobId=v; }
    public String  getFileName()                    { return fileName; }
    public void    setFileName(String v)            { this.fileName=v; }
    public String  getFileFormat()                  { return fileFormat; }
    public void    setFileFormat(String v)          { this.fileFormat=v; }
    public String  getNetworkVersion()              { return networkVersion; }
    public void    setNetworkVersion(String v)      { this.networkVersion=v; }
    public String  getFileHash()                    { return fileHash; }
    public void    setFileHash(String v)            { this.fileHash=v; }
    public String  getStatus()                      { return status; }
    public void    setStatus(String v)              { this.status=v; }
    public String  getSubmittedBy()                 { return submittedBy; }
    public void    setSubmittedBy(String v)         { this.submittedBy=v; }
    public String  getOrgId()                       { return orgId; }
    public void    setOrgId(String v)               { this.orgId=v; }
    public int     getTotalObjects()                { return totalObjects; }
    public void    setTotalObjects(int v)           { this.totalObjects=v; }
    public int     getPhysicalObjects()             { return physicalObjects; }
    public void    setPhysicalObjects(int v)        { this.physicalObjects=v; }
    public int     getLogicalObjects()              { return logicalObjects; }
    public void    setLogicalObjects(int v)         { this.logicalObjects=v; }
    public int     getPathIssueCount()              { return pathIssueCount; }
    public void    setPathIssueCount(int v)         { this.pathIssueCount=v; }
    public String  getErrorMessage()                { return errorMessage; }
    public void    setErrorMessage(String v)        { this.errorMessage=v; }
    public long    getProcessingMs()                { return processingMs; }
    public void    setProcessingMs(long v)          { this.processingMs=v; }
    public StageTimings getStageTimings()           { return stageTimings; }
    public void    setStageTimings(StageTimings v)  { this.stageTimings=v; }
    public List<String> getEnabledNamespaces()      { return enabledNamespaces; }
    public void    setEnabledNamespaces(List<String> v){ this.enabledNamespaces=v; }
    public Instant getSubmittedAt()                 { return submittedAt; }
    public void    setSubmittedAt(Instant v)        { this.submittedAt=v; }
    public Instant getCompletedAt()                 { return completedAt; }
    public void    setCompletedAt(Instant v)        { this.completedAt=v; }
}

// ═══════════════════════════════════════════════════════════════════
// CimObjectRecord — one MongoDB document per CIM object
// Enhanced: orgId (REQ #1), namespace-filtered attributes (REQ #2)
// ═══════════════════════════════════════════════════════════════════
@Document(collection = "cim_objects")
@CompoundIndexes({
    @CompoundIndex(name="idx_jobid",          def="{'jobId':1}"),
    @CompoundIndex(name="idx_jobid_rdfid",    def="{'jobId':1,'rdfId':1}"),
    @CompoundIndex(name="idx_jobid_cimtype",  def="{'jobId':1,'cimType':1}"),
    @CompoundIndex(name="idx_jobid_category", def="{'jobId':1,'category':1}"),
    @CompoundIndex(name="idx_jobid_required", def="{'jobId':1,'isRequired':1}"),
    @CompoundIndex(name="idx_jobid_orgid",    def="{'jobId':1,'orgId':1}")
})
class CimObjectRecord {
    @Id private String id;
    private String jobId;
    private String rdfId;
    private String mrid;
    private String cimType;
    private String name;
    private String category;    // PHYSICAL or LOGICAL — from OWL registry
    private boolean isRequired; // from OWL registry, changeable via API

    private String sourceFormat;
    private String sourceFile;

    /** REQ #1 — Organisation ID, passed from import request */
    private String orgId;

    private String version;     // networkVersion from import

    /**
     * Attributes from ALL enabled namespaces.
     * Keys are encoded (dots → U+FF0E).
     * CIM attributes: "ACLineSegment\uff0er" = "0.05"
     * Custom attributes: "caiso\uff0eemsFlag" = "true" (if caiso enabled)
     */
    private Map<String,String> attributes     = new LinkedHashMap<>();

    /** References from enabled namespaces */
    private Map<String,String> references     = new LinkedHashMap<>();

    /** Resolved reference IDs after $lookup */
    private Map<String,String> resolvedRefIds = new LinkedHashMap<>();

    /**
     * Path validation issues.
     * CIM attributes: INVALID if declaring class not in ancestry chain.
     * Custom namespace (enabled, no validation): not stored here.
     * Custom namespace (disabled): UNKNOWN_NAMESPACE stored here (REQ #3).
     */
    private List<Map<String,String>> pathIssues = new ArrayList<>();

    private Instant createdAt;

    public String  getId()                              { return id; }
    public void    setId(String v)                      { this.id=v; }
    public String  getJobId()                           { return jobId; }
    public void    setJobId(String v)                   { this.jobId=v; }
    public String  getRdfId()                           { return rdfId; }
    public void    setRdfId(String v)                   { this.rdfId=v; }
    public String  getMrid()                            { return mrid; }
    public void    setMrid(String v)                    { this.mrid=v; }
    public String  getCimType()                         { return cimType; }
    public void    setCimType(String v)                 { this.cimType=v; }
    public String  getName()                            { return name; }
    public void    setName(String v)                    { this.name=v; }
    public String  getCategory()                        { return category; }
    public void    setCategory(String v)                { this.category=v; }
    public boolean isRequired()                         { return isRequired; }
    public void    setRequired(boolean v)               { this.isRequired=v; }
    public String  getSourceFormat()                    { return sourceFormat; }
    public void    setSourceFormat(String v)            { this.sourceFormat=v; }
    public String  getSourceFile()                      { return sourceFile; }
    public void    setSourceFile(String v)              { this.sourceFile=v; }
    public String  getOrgId()                           { return orgId; }
    public void    setOrgId(String v)                   { this.orgId=v; }
    public String  getVersion()                         { return version; }
    public void    setVersion(String v)                 { this.version=v; }
    public Map<String,String> getAttributes()           { return attributes; }
    public void    setAttributes(Map<String,String> v)  { this.attributes=v; }
    public Map<String,String> getReferences()           { return references; }
    public void    setReferences(Map<String,String> v)  { this.references=v; }
    public Map<String,String> getResolvedRefIds()       { return resolvedRefIds; }
    public void    setResolvedRefIds(Map<String,String> v){ this.resolvedRefIds=v; }
    public List<Map<String,String>> getPathIssues()     { return pathIssues; }
    public void    setPathIssues(List<Map<String,String>> v){ this.pathIssues=v; }
    public Instant getCreatedAt()                       { return createdAt; }
    public void    setCreatedAt(Instant v)              { this.createdAt=v; }
}

// ═══════════════════════════════════════════════════════════════════
// Neo4jExportJob — tracks Neo4j export operations
// ═══════════════════════════════════════════════════════════════════
@Document(collection = "neo4j_exports")
class Neo4jExportJob {
    @Id private String id;
    private String  exportId;
    private String  jobId;
    private String  networkVersion;
    private String  orgId;
    private String  status;
    private String  exportMode;
    private int     nodesExported;
    private int     relsExported;
    private String  errorMessage;
    private long    processingMs;
    private Instant startedAt;
    private Instant completedAt;

    public Neo4jExportJob() {}
    public Neo4jExportJob(String exportId, String jobId,
                           String networkVersion, String orgId, String mode) {
        this.exportId=exportId; this.jobId=jobId;
        this.networkVersion=networkVersion; this.orgId=orgId;
        this.exportMode=mode; this.status="PENDING"; this.startedAt=Instant.now();
    }

    public String  getId()                      { return id; }
    public String  getExportId()                { return exportId; }
    public void    setExportId(String v)        { this.exportId=v; }
    public String  getJobId()                   { return jobId; }
    public void    setJobId(String v)           { this.jobId=v; }
    public String  getNetworkVersion()          { return networkVersion; }
    public void    setNetworkVersion(String v)  { this.networkVersion=v; }
    public String  getOrgId()                   { return orgId; }
    public void    setOrgId(String v)           { this.orgId=v; }
    public String  getStatus()                  { return status; }
    public void    setStatus(String v)          { this.status=v; }
    public String  getExportMode()              { return exportMode; }
    public void    setExportMode(String v)      { this.exportMode=v; }
    public int     getNodesExported()           { return nodesExported; }
    public void    setNodesExported(int v)      { this.nodesExported=v; }
    public int     getRelsExported()            { return relsExported; }
    public void    setRelsExported(int v)       { this.relsExported=v; }
    public String  getErrorMessage()            { return errorMessage; }
    public void    setErrorMessage(String v)    { this.errorMessage=v; }
    public long    getProcessingMs()            { return processingMs; }
    public void    setProcessingMs(long v)      { this.processingMs=v; }
    public Instant getStartedAt()               { return startedAt; }
    public void    setStartedAt(Instant v)      { this.startedAt=v; }
    public Instant getCompletedAt()             { return completedAt; }
    public void    setCompletedAt(Instant v)    { this.completedAt=v; }
}

// ═══════════════════════════════════════════════════════════════════
// Neo4jExportConfig — stored CIM type selection for auto-export
// CRUD via /api/admin/neo4j/configs REST API
// ═══════════════════════════════════════════════════════════════════
@Document(collection = "neo4j_export_configs")
public class Neo4jExportConfig {
    @Id private String id;

    /**
     * Human-readable name for this config.
     * e.g. "CAISO Physical Equipment", "Full Topology", "Breakers Only"
     */
    private String configName;

    /**
     * Description of what this config exports and why.
     */
    private String description;

    /**
     * Organisation this config belongs to.
     * If set, auto-export only triggers for matching orgId on import.
     * If null/empty — applies to all orgs.
     */
    private String orgId;

    /**
     * Export mode: ALL, PHYSICAL_ONLY, REQUIRED_ONLY, CUSTOM
     */
    private String exportMode;

    /**
     * CIM types to export when mode=CUSTOM.
     * e.g. ["ACLineSegment","Breaker","PowerTransformer","Terminal",
     *        "ConnectivityNode","VoltageLevel","Substation","BaseVoltage"]
     */
    private List<String> cimTypes = new ArrayList<>();

    /**
     * Whether to delete existing Neo4j nodes (same version+orgId) before export.
     */
    private boolean clearFirst;

    /**
     * Whether this config triggers automatically after every import.
     * true  = auto-triggered after import completes (RESOLVED status)
     * false = on-demand only via POST /api/admin/neo4j/export
     */
    private boolean autoExport;

    /**
     * Whether this config is active.
     * Inactive configs are never auto-triggered.
     */
    private boolean active;

    private String  createdBy;
    private Instant createdAt;
    private Instant updatedAt;

    public Neo4jExportConfig() {}

    public String  getId()                         { return id; }
    public String  getConfigName()                 { return configName; }
    public void    setConfigName(String v)         { this.configName=v; }
    public String  getDescription()                { return description; }
    public void    setDescription(String v)        { this.description=v; }
    public String  getOrgId()                      { return orgId; }
    public void    setOrgId(String v)              { this.orgId=v; }
    public String  getExportMode()                 { return exportMode; }
    public void    setExportMode(String v)         { this.exportMode=v; }
    public List<String> getCimTypes()              { return cimTypes; }
    public void    setCimTypes(List<String> v)     { this.cimTypes=v!=null?v:new ArrayList<>(); }
    public boolean isClearFirst()                  { return clearFirst; }
    public void    setClearFirst(boolean v)        { this.clearFirst=v; }
    public boolean isAutoExport()                  { return autoExport; }
    public void    setAutoExport(boolean v)        { this.autoExport=v; }
    public boolean isActive()                      { return active; }
    public void    setActive(boolean v)            { this.active=v; }
    public String  getCreatedBy()                  { return createdBy; }
    public void    setCreatedBy(String v)          { this.createdBy=v; }
    public Instant getCreatedAt()                  { return createdAt; }
    public void    setCreatedAt(Instant v)         { this.createdAt=v; }
    public Instant getUpdatedAt()                  { return updatedAt; }
    public void    setUpdatedAt(Instant v)         { this.updatedAt=v; }
}
