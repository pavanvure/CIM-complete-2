package com.cim.streaming;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.util.MapKeySanitizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;
import org.bson.Document;

import java.util.*;

/**
 * Resolves rdf:resource cross-references using MongoDB server-side $lookup.
 * Zero Java-side document iteration for resolution — runs entirely in MongoDB.
 */
@Component
public class StreamingReferenceResolver {

    private static final Logger log = LoggerFactory.getLogger(StreamingReferenceResolver.class);
    private static final int BATCH = 500;

    private final CimObjectRecordRepository objectRepo;
    private final MongoTemplate             mongoTemplate;

    public StreamingReferenceResolver(CimObjectRecordRepository objectRepo,
                                       MongoTemplate mongoTemplate) {
        this.objectRepo    = objectRepo;
        this.mongoTemplate = mongoTemplate;
    }

    public long resolveReferencesInMongo(String jobId, int batchSize,
                                          ProgressTracker progress) {
        progress.log("Reference resolution starting (server-side $lookup)");
        long start = System.currentTimeMillis();

        try {
            long resolved = resolveServerSide(jobId, progress, start);
            progress.log("Server-side resolution done in " + elapsed(start) + "s — " + resolved);
            return resolved;
        } catch (Exception e) {
            log.warn("Server-side failed ({}), using client-side fallback", e.getMessage());
            return resolveClientSide(jobId, batchSize, progress, start);
        }
    }

    // ── Server-side: MongoDB $lookup + $merge ──────────────────────────────

    private long resolveServerSide(String jobId, ProgressTracker progress, long start) {
        String pipeline = String.format(
            "{ aggregate: 'cim_objects', pipeline: ["
          + "  { $match: { jobId: '%s' } },"
          + "  { $addFields: { refArray: { $objectToArray: '$references' } } },"
          + "  { $lookup: { from: 'cim_objects', localField: 'refArray.v',"
          + "      foreignField: 'rdfId', as: 'resolvedDocs',"
          + "      pipeline: [{ $match: { jobId: '%s' } }, { $project: { rdfId: 1, _id: 0 } }] } },"
          + "  { $addFields: { resolvedRdfIdSet: '$resolvedDocs.rdfId' } },"
          + "  { $addFields: { resolvedPairs: { $filter: { input: '$refArray', as: 'pair',"
          + "      cond: { $in: ['$$pair.v', '$resolvedRdfIdSet'] } } } } },"
          + "  { $addFields: { resolvedRefIds: { $arrayToObject: '$resolvedPairs' } } },"
          + "  { $project: { resolvedRefIds: 1 } },"
          + "  { $merge: { into: 'cim_objects', on: '_id',"
          + "      whenMatched: 'merge', whenNotMatched: 'discard' } }"
          + "], cursor: {}, allowDiskUse: true}",
            jobId, jobId);

        mongoTemplate.getDb().runCommand(Document.parse(pipeline));
        progress.log("$merge completed in " + elapsed(start) + "s");

        // Count resolved
        Criteria c = Criteria.where("resolvedRefIds").exists(true).ne(new Document());
        return mongoTemplate.count(
                new Query(Criteria.where("jobId").is(jobId).andOperator(c)),
                "cim_objects");
    }

    // ── Client-side fallback ───────────────────────────────────────────────

    private long resolveClientSide(String jobId, int batchSize,
                                    ProgressTracker progress, long start) {
        // Step 1: collect all target rdfIds via aggregation
        Set<String> allTargets = collectTargets(jobId, progress);
        progress.log("Targets collected: " + allTargets.size() + " in " + elapsed(start) + "s");

        // Step 2: verify existence in batches
        Set<String> existing = verifyExistence(jobId, allTargets, progress);
        progress.log("Verified: " + existing.size() + "/" + allTargets.size());

        // Step 3: write back resolvedRefIds
        return writeBack(jobId, existing, batchSize, progress);
    }

    private Set<String> collectTargets(String jobId, ProgressTracker progress) {
        try {
            String pipeline = String.format(
                "{ aggregate: 'cim_objects', pipeline: ["
              + "  { $match: { jobId: '%s', references: { $exists: true } } },"
              + "  { $project: { _id: 0, refs: { $objectToArray: '$references' } } },"
              + "  { $unwind: '$refs' },"
              + "  { $group: { _id: '$refs.v' } }"
              + "], cursor: { batchSize: 50000 }, allowDiskUse: true}", jobId);

            Document result = mongoTemplate.getDb().runCommand(Document.parse(pipeline));
            Set<String> targets = new HashSet<>();
            Document cursor = (Document) result.get("cursor");
            if (cursor != null) {
                @SuppressWarnings("unchecked")
                List<Document> batch = (List<Document>) cursor.get("firstBatch");
                if (batch != null) batch.forEach(d -> {
                    Object id = d.get("_id");
                    if (id != null && !id.toString().isBlank()) targets.add(id.toString());
                });
            }
            return targets;
        } catch (Exception e) {
            log.warn("Target aggregation failed: {}", e.getMessage());
            return new HashSet<>();
        }
    }

    private Set<String> verifyExistence(String jobId, Set<String> targets,
                                         ProgressTracker progress) {
        Set<String> existing = new HashSet<>();
        List<String> list = new ArrayList<>(targets);
        for (int i = 0; i < list.size(); i += BATCH) {
            List<String> batch = list.subList(i, Math.min(i + BATCH, list.size()));
            Query q = new Query(Criteria.where("jobId").is(jobId).and("rdfId").in(batch));
            q.fields().include("rdfId").exclude("_id");
            q.withHint(Document.parse("{jobId:1,rdfId:1}"));
            mongoTemplate.find(q, CimObjectRecord.class, "cim_objects")
                    .forEach(r -> { if (r.getRdfId() != null) existing.add(r.getRdfId()); });
        }
        return existing;
    }

    private long writeBack(String jobId, Set<String> existing,
                            int batchSize, ProgressTracker progress) {
        long total = 0; int page = 0;
        while (true) {
            List<CimObjectRecord> batch = objectRepo
                    .findByJobId(jobId, PageRequest.of(page, batchSize)).getContent();
            if (batch.isEmpty()) break;
            org.springframework.data.mongodb.core.BulkOperations bulk =
                    mongoTemplate.bulkOps(
                            org.springframework.data.mongodb.core.BulkOperations.BulkMode.UNORDERED,
                            "cim_objects");
            int updates = 0;
            for (CimObjectRecord rec : batch) {
                Map<String,String> refs = rec.getReferences();
                if (refs == null || refs.isEmpty()) continue;
                Map<String,String> resolved = new LinkedHashMap<>();
                MapKeySanitizer.decodeKeys(refs).forEach((k,v) -> {
                    if (existing.contains(v))
                        resolved.put(MapKeySanitizer.encodeKey(k), v);
                });
                if (!resolved.isEmpty()) {
                    Query q = new Query(Criteria.where("_id").is(rec.getId()));
                    org.springframework.data.mongodb.core.query.Update u =
                            new org.springframework.data.mongodb.core.query.Update()
                                    .set("resolvedRefIds", resolved);
                    bulk.updateOne(q, u);
                    total += resolved.size(); updates++;
                }
            }
            if (updates > 0) bulk.execute();
            page++;
        }
        return total;
    }

    private long elapsed(long start) { return (System.currentTimeMillis() - start) / 1000; }
}
