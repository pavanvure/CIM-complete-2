package com.cim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * CIM Network Data Import Platform
 * IEC 61970 / IEC 61968 — Multi-Format CIM RDF Importer
 *
 * Flow:
 *  1. Admin loads CIM OWL hierarchy (once on startup)
 *  2. Client uploads CIM file with networkVersion
 *  3. Format auto-detected (RDF/XML, JSON-LD, Milsoft CSV)
 *  4. File parsed → CIMObjects (common model)
 *  5. Objects stored in MongoDB with version + isRequired flag
 *  6. Cross-references resolved via MongoDB $lookup
 *  7. Status = RESOLVED
 *  8. REST API exposes objects, stats, required/optional flags
 */
@SpringBootApplication
@EnableAsync
public class CIMPlatformApplication {
    public static void main(String[] args) {
        SpringApplication.run(CIMPlatformApplication.class, args);
    }
}
