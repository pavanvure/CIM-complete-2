package com.cim.service;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.model.mongo.Neo4jExportJob;
import com.cim.model.mongo.ExportRequest;
import com.cim.model.mongo.ExportRequest.ExportMode;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.repository.Neo4jExportJobRepository;
import com.cim.repository.ValidationJobRepository;
import com.cim.util.MapKeySanitizer;
import org.neo4j.driver.*;
import org.neo4j.driver.exceptions.Neo4jException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
// @Async moved to Neo4jExportExecutor — separate bean to avoid proxy bypass
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 * Neo4j Export Service
 *
 * Exports CIM objects from MongoDB to Neo4j matching the EXISTING topology structure:
 *
 * NODE STRUCTURE (matches existing Neo4j):
 *   Labels:      :ACLineSegment  (cimType only — no :CIMObject label)
 *   Properties:  ACLineSegment.r, ACLineSegment.x  ← DOT notation preserved
 *                version, orgId                    ← top-level
 *                mrid, rdfId, name, uri            ← standard fields
 *
 * RELATIONSHIP STRUCTURE (matches existing Neo4j):
 *   Type:        Terminal.ConductingEquipment      ← DOT notation preserved
 *   e.g.         (Terminal)-[:Terminal.ConductingEquipment]->(ACLineSegment)
 *
 * Java 11 + Neo4j Driver 4.4.x:
 *   session.writeTransaction(tx -> { ... return null; })
 *   No APOC. No yield. No switch expressions.
 */
@Service
public class Neo4jExportService {

    private static final Logger log = LoggerFactory.getLogger(Neo4jExportService.class);

    @Value("${cim.neo4j.export.batch-size:500}")
    private int batchSize;

    @Value("${cim.neo4j.export.create-constraints:true}")
    private boolean createConstraints;

    private final Driver                    driver;
    private final MongoTemplate             mongo;
    private final CimObjectRecordRepository objectRepo;
    private final Neo4jExportJobRepository  exportRepo;
    private final ValidationJobRepository   jobRepo;

    // Injected via setter to avoid circular dependency
    // Neo4jExportExecutor depends on Neo4jExportService, so we use @Autowired setter
    private Neo4jExportExecutor executor;

    @org.springframework.beans.factory.annotation.Autowired
    public void setExecutor(Neo4jExportExecutor executor) {
        this.executor = executor;
    }

    public Neo4jExportService(Driver driver, MongoTemplate mongo,
                               CimObjectRecordRepository objectRepo,
                               Neo4jExportJobRepository exportRepo,
                               ValidationJobRepository jobRepo) {
        this.driver     = driver;
        this.mongo      = mongo;
        this.objectRepo = objectRepo;
        this.exportRepo = exportRepo;
        this.jobRepo    = jobRepo;
    }

    // ── Start export ──────────────────────────────────────────────────────

    public Neo4jExportJob startExport(ExportRequest req) {
        String exportId = UUID.randomUUID().toString();
        String version = jobRepo.findByJobId(req.getJobId())
                .map(j -> j.getNetworkVersion() != null ? j.getNetworkVersion() : "unknown")
                .orElse("unknown");
        String orgId = jobRepo.findByJobId(req.getJobId())
                .map(j -> j.getOrgId() != null ? j.getOrgId() : "")
                .orElse("");

        Neo4jExportJob job = new Neo4jExportJob(
                exportId, req.getJobId(), version, orgId, req.getMode().name());
        exportRepo.save(job);
        // Call executor (different bean) so Spring proxy triggers @Async
        // This is truly asynchronous — returns immediately, client polls status
        executor.runAsync(req, job);
        return job;
    }

    /**
     * Called by Neo4jExportExecutor.runAsync() on a separate thread.
     * public so executor can call it. NOT @Async itself — async is on executor.
     */
    public void runExport(ExportRequest req, Neo4jExportJob job) {
        try {
            job.setStatus("RUNNING");
            exportRepo.save(job);
            long start = System.currentTimeMillis();

            if (createConstraints) ensureConstraints();
            if (req.isClearFirst()) clearExistingNodes(job.getNetworkVersion(), job.getOrgId());

            int[] counts = exportAllObjects(req, job);

            job.setStatus("DONE");
            job.setNodesExported(counts[0]);
            job.setRelsExported(counts[1]);
            job.setCompletedAt(Instant.now());
            job.setProcessingMs(System.currentTimeMillis() - start);
            exportRepo.save(job);

            log.info("Neo4j export done: exportId={} version={} orgId={} nodes={} rels={} in {}ms",
                    job.getExportId(), job.getNetworkVersion(), job.getOrgId(),
                    counts[0], counts[1], System.currentTimeMillis() - start);

        } catch (Exception e) {
            log.error("Neo4j export failed: {}", e.getMessage(), e);
            job.setStatus("FAILED");
            job.setErrorMessage(e.getMessage());
            job.setCompletedAt(Instant.now());
            exportRepo.save(job);
        }
    }

    // ── Constraints / Indexes ─────────────────────────────────────────────

    private void ensureConstraints() {
        try (Session s = driver.session()) {
            s.writeTransaction(tx -> {
                // Index on mrid for fast lookup
                try {
                    tx.run("CREATE INDEX cim_mrid_idx IF NOT EXISTS FOR (n:CIMObject) ON (n.mrid)");
                } catch (Exception e) { log.debug("Index note: {}", e.getMessage()); }
                // Index on rdfId for relationship resolution
                try {
                    tx.run("CREATE INDEX cim_rdfid_idx IF NOT EXISTS FOR (n:CIMObject) ON (n.rdfId)");
                } catch (Exception e) { log.debug("Index note: {}", e.getMessage()); }
                // Index on version for version-based queries
                try {
                    tx.run("CREATE INDEX cim_version_idx IF NOT EXISTS FOR (n:CIMObject) ON (n.version)");
                } catch (Exception e) { log.debug("Index note: {}", e.getMessage()); }
                return null;
            });
            log.info("Neo4j indexes ensured");
        } catch (Exception e) {
            log.warn("Index setup warning: {}", e.getMessage());
        }
    }

    // ── Clear existing nodes for version + orgId ──────────────────────────

    private void clearExistingNodes(String version, String orgId) {
        try (Session s = driver.session()) {
            s.writeTransaction(tx -> {
                // Clear by version AND orgId to avoid touching other orgs
                tx.run("MATCH (n {version: $v, orgId: $o}) DETACH DELETE n",
                        Values.parameters("v", version, "o", orgId));
                return null;
            });
            log.info("Cleared Neo4j nodes for version={} orgId={}", version, orgId);
        }
    }

    // ── Main export loop ──────────────────────────────────────────────────

    private int[] exportAllObjects(ExportRequest req, Neo4jExportJob job) {
        int totalNodes = 0, totalRels = 0, page = 0;

        while (true) {
            Page<CimObjectRecord> pageResult = getPage(req, page);
            if (pageResult.isEmpty()) break;

            List<CimObjectRecord> records = pageResult.getContent();

            // Export nodes grouped by cimType
            totalNodes += writeNodeBatch(records, job.getNetworkVersion(), job.getOrgId());

            // Export relationships from resolvedRefIds
            List<Map<String, Object>> relBatch = buildRelBatch(records);
            if (!relBatch.isEmpty()) {
                totalRels += writeRelBatch(relBatch);
            }

            if (page % 10 == 0) {
                log.info("Neo4j export progress: page={} nodes={} rels={}",
                        page, totalNodes, totalRels);
            }
            page++;
        }
        return new int[]{totalNodes, totalRels};
    }

    // ── Node batch write ──────────────────────────────────────────────────
    /**
     * Writes nodes matching EXISTING Neo4j topology structure.
     *
     * Each node gets:
     *   Label:      cimType only (e.g. :ACLineSegment)
     *   Properties: dot-notation attribute keys (ACLineSegment.r, NOT ACLineSegment_r)
     *               version and orgId as top-level properties
     *               uri = source file reference
     *
     * Groups by cimType so each Cypher has the label statically.
     * No APOC required.
     */
    private int writeNodeBatch(List<CimObjectRecord> records,
                                String version, String orgId) {
        if (records.isEmpty()) return 0;

        // Group by cimType
        Map<String, List<Map<String, Object>>> byType = new LinkedHashMap<>();
        for (CimObjectRecord rec : records) {
            String label = sanitizeLabel(rec.getCimType());
            Map<String, Object> props = toNodeProps(rec, version, orgId);
            byType.computeIfAbsent(label, k -> new ArrayList<>()).add(props);
        }

        int written = 0;
        for (Map.Entry<String, List<Map<String, Object>>> entry : byType.entrySet()) {
            String label     = entry.getKey();
            List<Map<String, Object>> batch = entry.getValue();

            // MERGE on mrid+version+orgId — matches existing topology pattern
            String cypher =
                "UNWIND $batch AS p " +
                "MERGE (n:" + label + " {mrid: p.mrid, version: p.version, orgId: p.orgId}) " +
                "SET n += p";

            try (Session s = driver.session()) {
                final String fc = cypher;
                final List<Map<String, Object>> fb = batch;
                s.writeTransaction(tx -> {
                    tx.run(fc, Values.parameters("batch", fb));
                    return null;
                });
                written += batch.size();
            } catch (Neo4jException e) {
                log.warn("Node write failed for {}: {}", label, e.getMessage());
            }
        }
        return written;
    }

    // ── Relationship batch ────────────────────────────────────────────────
    /**
     * Relationships use DOT notation to match existing topology:
     *   (Terminal)-[:Terminal.ConductingEquipment]->(ACLineSegment)
     *   (ACLineSegment)-[:Equipment.EquipmentContainer]->(Line)
     *
     * The relationship type is the original reference key (e.g. "Terminal.ConductingEquipment")
     * with only characters that are invalid in Neo4j relationship types replaced.
     * Neo4j DOES support dots in relationship types with backtick escaping.
     */
    private List<Map<String, Object>> buildRelBatch(List<CimObjectRecord> records) {
        List<Map<String, Object>> relBatch = new ArrayList<>();
        for (CimObjectRecord rec : records) {
            if (rec.getResolvedRefIds() == null || rec.getResolvedRefIds().isEmpty()) continue;

            // Decode keys: U+FF0E → dot
            Map<String, String> decoded = MapKeySanitizer.decodeKeys(rec.getResolvedRefIds());
            for (Map.Entry<String, String> e : decoded.entrySet()) {
                Map<String, Object> rel = new LinkedHashMap<>();
                rel.put("sourceRdfId", rec.getRdfId());
                rel.put("targetRdfId", e.getValue());
                // Keep original dot notation: "Terminal.ConductingEquipment"
                rel.put("relType",     e.getKey());
                rel.put("version",     rec.getVersion() != null ? rec.getVersion() : "");
                rel.put("orgId",       rec.getOrgId()   != null ? rec.getOrgId()   : "");
                relBatch.add(rel);
            }
        }
        return relBatch;
    }

    private int writeRelBatch(List<Map<String, Object>> batch) {
        if (batch.isEmpty()) return 0;

        // Group by relationship type
        Map<String, List<Map<String, Object>>> byRel = new LinkedHashMap<>();
        for (Map<String, Object> r : batch) {
            String relType = (String) r.get("relType");
            byRel.computeIfAbsent(relType, k -> new ArrayList<>()).add(r);
        }

        int total = 0;
        for (Map.Entry<String, List<Map<String, Object>>> e : byRel.entrySet()) {
            String relType      = e.getKey();
            List<Map<String, Object>> relBatch = e.getValue();

            // Backtick-escape relationship type to allow dot notation
            // This produces: MERGE (src)-[:`Terminal.ConductingEquipment`]->(tgt)
            // matching exactly what is in your existing Neo4j topology
            String escapedType  = "`" + relType.replace("`", "") + "`";
            String cypher =
                "UNWIND $batch AS r " +
                "MATCH (src {rdfId: r.sourceRdfId, version: r.version, orgId: r.orgId}) " +
                "MATCH (tgt {rdfId: r.targetRdfId, version: r.version, orgId: r.orgId}) " +
                "MERGE (src)-[:" + escapedType + " {version: r.version, orgId: r.orgId}]->(tgt)";

            try (Session s = driver.session()) {
                final String fc = cypher;
                final List<Map<String, Object>> fb = relBatch;
                s.writeTransaction(tx -> {
                    tx.run(fc, Values.parameters("batch", fb));
                    return null;
                });
                total += relBatch.size();
            } catch (Neo4jException ex) {
                log.warn("Rel write failed for {}: {}", relType, ex.getMessage());
            }
        }
        return total;
    }

    // ── Node properties — matching existing Neo4j structure ───────────────

    private Map<String, Object> toNodeProps(CimObjectRecord rec,
                                             String version, String orgId) {
        Map<String, Object> props = new LinkedHashMap<>();

        // Standard identity fields
        props.put("mrid",   rec.getMrid()   != null ? rec.getMrid()   : rec.getRdfId());
        props.put("rdfId",  rec.getRdfId()  != null ? rec.getRdfId()  : "");
        props.put("name",   rec.getName()   != null ? rec.getName()   : "");
        props.put("cimType",rec.getCimType()!= null ? rec.getCimType(): "Unknown");

        // version and orgId as TOP-LEVEL properties (matches existing topology)
        props.put("version", version != null ? version : "");
        props.put("orgId",   orgId   != null ? orgId   : "");

        // uri — source file reference (matches existing topology 'uri' property)
        props.put("uri", rec.getSourceFile() != null ? rec.getSourceFile() : "");

        // CIM attributes — USE DOT NOTATION to match existing topology
        // EXISTING:  ACLineSegment.r = "0.11109"   ← dot preserved
        // NOT:       ACLineSegment_r = "0.11109"   ← underscore (wrong)
        if (rec.getAttributes() != null) {
            // decodeKeys restores U+FF0E → dot giving "ACLineSegment.r" etc.
            Map<String, String> decoded = MapKeySanitizer.decodeKeys(rec.getAttributes());
            for (Map.Entry<String, String> e : decoded.entrySet()) {
                // Skip if value is null or empty to keep nodes clean
                if (e.getKey() != null && e.getValue() != null && !e.getValue().isBlank()) {
                    props.put(e.getKey(), e.getValue());
                }
            }
        }

        return props;
    }

    // ── getPage — Java 11 if/else, no switch expression ──────────────────

    private Page<CimObjectRecord> getPage(ExportRequest req, int page) {
        PageRequest pr = PageRequest.of(page, batchSize);

        if (req.getMode() == ExportMode.ALL) {
            return objectRepo.findByJobId(req.getJobId(), pr);

        } else if (req.getMode() == ExportMode.PHYSICAL_ONLY) {
            Query q = new Query(Criteria.where("jobId").is(req.getJobId())
                    .and("category").is("PHYSICAL")).with(pr);
            List<CimObjectRecord> list = mongo.find(q, CimObjectRecord.class);
            return new org.springframework.data.domain.PageImpl<>(list, pr, list.size());

        } else if (req.getMode() == ExportMode.REQUIRED_ONLY) {
            Query q = new Query(Criteria.where("jobId").is(req.getJobId())
                    .and("isRequired").is(true)).with(pr);
            List<CimObjectRecord> list = mongo.find(q, CimObjectRecord.class);
            return new org.springframework.data.domain.PageImpl<>(list, pr, list.size());

        } else if (req.getMode() == ExportMode.CUSTOM) {
            Query q = new Query(Criteria.where("jobId").is(req.getJobId())
                    .and("cimType").in(req.getCimTypes())).with(pr);
            List<CimObjectRecord> list = mongo.find(q, CimObjectRecord.class);
            return new org.springframework.data.domain.PageImpl<>(list, pr, list.size());

        } else {
            return objectRepo.findByJobId(req.getJobId(), pr);
        }
    }

    // ── Label sanitizer ───────────────────────────────────────────────────

    /** Sanitize label — letters/digits/underscore only */
    private String sanitizeLabel(String t) {
        if (t == null || t.isBlank()) return "Unknown";
        return t.replaceAll("[^A-Za-z0-9_]", "_");
    }

    // ── Status ────────────────────────────────────────────────────────────

    public Optional<Neo4jExportJob> getExportStatus(String exportId) {
        return exportRepo.findByExportId(exportId);
    }

    public List<Neo4jExportJob> getRecentExports() {
        return exportRepo.findTop10ByOrderByStartedAtDesc();
    }
}
