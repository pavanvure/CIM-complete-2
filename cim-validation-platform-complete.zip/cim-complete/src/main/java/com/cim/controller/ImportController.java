package com.cim.controller;

import com.cim.model.mongo.ValidationJob;
import com.cim.repository.ValidationJobRepository;
import com.cim.service.ImportService;
import com.cim.streaming.ProgressTracker;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.security.MessageDigest;
import java.util.*;

/**
 * Import REST API
 *
 * POST /api/import              — upload CIM file with networkVersion
 * GET  /api/jobs                — list jobs (optional ?networkVersion filter)
 * GET  /api/jobs/{jobId}        — job status
 * GET  /api/jobs/{jobId}/progress — live progress (large files)
 * DELETE /api/jobs/{jobId}      — delete job + objects (allows re-import)
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ImportController {

    private static final long LARGE_FILE_BYTES = 50L * 1024 * 1024;

    private final ImportService           importService;
    private final ValidationJobRepository jobRepo;

    public ImportController(ImportService importService,
                              ValidationJobRepository jobRepo) {
        this.importService = importService;
        this.jobRepo       = jobRepo;
    }

    // ─────────────────────────────────────────────────────────────────
    // POST /api/import
    // Params: file (required), networkVersion (required), X-User header
    // ─────────────────────────────────────────────────────────────────
    @PostMapping("/import")
    public ResponseEntity<?> importFile(
            @RequestParam("file")           MultipartFile file,
            @RequestParam("networkVersion") String networkVersion,
            @RequestHeader(value="X-User", defaultValue="anonymous") String user) {

        if (file.isEmpty())
            return ResponseEntity.badRequest().body(Map.of("error","File is empty."));

        if (networkVersion == null || networkVersion.isBlank())
            return ResponseEntity.badRequest().body(Map.of(
                "error","networkVersion is required.",
                "hint", "E.g. '2024-Q1', 'SUMMER-PEAK', 'v3.2'"));

        String version = networkVersion.trim();
        byte[] bytes;
        String hash;
        try {
            bytes = file.getBytes();
            hash  = sha256(bytes);
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error","Could not read file: "+e.getMessage()));
        }

        // ── Duplicate check ───────────────────────────────────────────
        List<String> active = List.of("PENDING","RUNNING","RESOLVED");

        // Check by hash + version (same file content)
        List<ValidationJob> dup1 = jobRepo
                .findByFileHashAndNetworkVersionAndStatusIn(hash, version, active);
        if (!dup1.isEmpty()) {
            ValidationJob ex = dup1.get(0);
            return ResponseEntity.status(409).body(Map.of(
                "error",          "Duplicate import rejected.",
                "reason",         "Same file content with version '"+version
                                  +"' already "+ex.getStatus()+".",
                "existingJobId",  ex.getJobId(),
                "existingStatus", ex.getStatus(),
                "importedAt",     ex.getSubmittedAt().toString(),
                "hint",           "Use a different networkVersion or DELETE the existing job first."
            ));
        }

        // Check by filename + version (same name, possibly different content)
        List<ValidationJob> dup2 = jobRepo
                .findByFileNameAndNetworkVersionAndStatusIn(
                        file.getOriginalFilename(), version, active);
        if (!dup2.isEmpty()) {
            ValidationJob ex = dup2.get(0);
            return ResponseEntity.status(409).body(Map.of(
                "error",          "Duplicate import rejected.",
                "reason",         "File '"+file.getOriginalFilename()
                                  +"' with version '"+version
                                  +"' already imported ("+ex.getStatus()+").",
                "existingJobId",  ex.getJobId(),
                "hint",           "DELETE the existing job to re-import."
            ));
        }

        // ── Detect format ─────────────────────────────────────────────
        String format = detectFormat(bytes, file.getOriginalFilename());

        // ── Create job ────────────────────────────────────────────────
        String jobId = UUID.randomUUID().toString();
        ValidationJob job = new ValidationJob(
                jobId, file.getOriginalFilename(), format, user, version);
        job.setFileHash(hash);
        job.setStatus("PENDING");
        jobRepo.save(job);

        // ── Process ───────────────────────────────────────────────────
        try {
            if (file.getSize() <= LARGE_FILE_BYTES) {
                importService.processAndResolve(
                        new java.io.ByteArrayInputStream(bytes),
                        file.getOriginalFilename(), format, jobId, version);

                ValidationJob done = jobRepo.findByJobId(jobId).orElse(job);
                return ResponseEntity.ok(Map.of(
                    "jobId",          jobId,
                    "status",         done.getStatus(),
                    "networkVersion", version,
                    "fileName",       file.getOriginalFilename(),
                    "format",         format,
                    "totalObjects",   done.getTotalObjects(),
                    "links",          links(jobId)
                ));
            } else {
                importService.processAndResolveAsync(
                        file.getInputStream(), file.getOriginalFilename(),
                        format, jobId, version);

                return ResponseEntity.accepted().body(Map.of(
                    "jobId",          jobId,
                    "status",         "PROCESSING",
                    "networkVersion", version,
                    "fileName",       file.getOriginalFilename(),
                    "format",         format,
                    "fileSizeMb",     String.format("%.1f", file.getSize()/1048576.0),
                    "links",          links(jobId)
                ));
            }
        } catch (Exception e) {
            job.setStatus("FAILED"); job.setErrorMessage(e.getMessage());
            jobRepo.save(job);
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage(), "jobId", jobId));
        }
    }

    // ─────────────────────────────────────────────────────────────────
    // GET /api/jobs
    // ─────────────────────────────────────────────────────────────────
    @GetMapping("/jobs")
    public ResponseEntity<?> listJobs(
            @RequestParam(required=false) String networkVersion) {
        return ResponseEntity.ok(networkVersion != null && !networkVersion.isBlank()
                ? jobRepo.findByNetworkVersion(networkVersion.trim())
                : jobRepo.findTop10ByOrderBySubmittedAtDesc());
    }

    // ─────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}
    // ─────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}")
    public ResponseEntity<?> getJob(@PathVariable String jobId) {
        return jobRepo.findByJobId(jobId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // ─────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/progress
    // ─────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}/progress")
    public ResponseEntity<?> getProgress(@PathVariable String jobId) {
        return importService.getTracker(jobId)
                .map(t -> ResponseEntity.ok(t.snapshot()))
                .orElseGet(() -> jobRepo.findByJobId(jobId)
                        .map(job -> ResponseEntity.ok(Map.of(
                            "jobId",    jobId,
                            "status",   job.getStatus(),
                            "version",  job.getNetworkVersion() != null ? job.getNetworkVersion() : "",
                            "finished", "RESOLVED".equals(job.getStatus()) || "FAILED".equals(job.getStatus())
                        ))).orElse(ResponseEntity.notFound().build()));
    }

    // ─────────────────────────────────────────────────────────────────
    // DELETE /api/jobs/{jobId}  — allows re-import of same file+version
    // ─────────────────────────────────────────────────────────────────
    @DeleteMapping("/jobs/{jobId}")
    public ResponseEntity<?> deleteJob(@PathVariable String jobId) {
        Optional<ValidationJob> opt = jobRepo.findByJobId(jobId);
        if (opt.isEmpty()) return ResponseEntity.notFound().build();
        // Objects deleted via MongoTemplate in QueryService
        jobRepo.delete(opt.get());
        return ResponseEntity.ok(Map.of(
            "message", "Job "+jobId+" deleted.",
            "hint",    "You can now re-import the same file+version."
        ));
    }

    // ── Helpers ───────────────────────────────────────────────────────

    private String detectFormat(byte[] bytes, String fileName) {
        String header = new String(bytes, 0, Math.min(512, bytes.length));
        if (header.contains("rdf:RDF") || header.contains("xmlns:cim")) return "RDF_XML";
        if (header.contains("@context") || header.contains("@type")) return "JSON_LD";
        if (fileName != null && fileName.toLowerCase().endsWith(".csv")) return "MILSOFT_CSV";
        return "RDF_XML"; // default
    }

    private Map<String,String> links(String jobId) {
        return Map.of(
            "progress", "/api/jobs/"+jobId+"/progress",
            "objects",  "/api/jobs/"+jobId+"/objects",
            "stats",    "/api/jobs/"+jobId+"/objects/stats",
            "required", "/api/jobs/"+jobId+"/objects/required/summary"
        );
    }

    private String sha256(byte[] data) throws Exception {
        byte[] h = MessageDigest.getInstance("SHA-256").digest(data);
        StringBuilder sb = new StringBuilder();
        for (byte b : h) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
