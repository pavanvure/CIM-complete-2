package com.cim.adapter;

import org.springframework.stereotype.Component;
import java.util.List;

/**
 * Registry that holds all format adapters and detects the correct one.
 * Spring injects all @Component beans implementing CIMFormatAdapter.
 */
@Component
public class AdapterRegistry {

    private final List<CIMFormatAdapter> adapters;

    public AdapterRegistry(List<CIMFormatAdapter> adapters) {
        this.adapters = adapters;
    }

    /**
     * Detects the right adapter for the given file content.
     * Tests adapters in priority order: RDF/XML → JSON-LD → Milsoft CSV
     */
    public CIMFormatAdapter detect(byte[] contentSample, String fileName) {
        // Try RDF/XML first (most common CIM format)
        for (CIMFormatAdapter adapter : adapters) {
            if (adapter instanceof RdfXmlAdapter && adapter.supports(contentSample, fileName)) {
                return adapter;
            }
        }
        // Then try others
        for (CIMFormatAdapter adapter : adapters) {
            if (adapter.supports(contentSample, fileName)) {
                return adapter;
            }
        }
        throw new IllegalArgumentException(
            "No adapter found for file: '" + fileName
            + "'. Supported formats: "
            + adapters.stream().map(CIMFormatAdapter::getFormatName)
                      .reduce("", (a,b) -> a.isBlank() ? b : a + ", " + b));
    }

    public List<String> getSupportedFormats() {
        return adapters.stream().map(CIMFormatAdapter::getFormatName).toList();
    }
}
