package com.cim.service;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.model.mongo.Neo4jExportJob;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.repository.Neo4jExportJobRepository;
import com.cim.repository.ValidationJobRepository;
import com.cim.util.MapKeySanitizer;
import org.neo4j.driver.*;
import org.neo4j.driver.exceptions.Neo4jException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * Exports CIM objects from MongoDB to Neo4j as a topology graph.
 *
 * GRAPH MODEL:
 *   Nodes:
 *     Each CimObjectRecord → Neo4j node with label = cimType
 *     Properties: mrid, rdfId, name, category, isRequired, version, + all attributes
 *
 *   Relationships:
 *     Each resolvedRefId entry → directed relationship
 *     (Source)-[:REFERENCE_KEY]->(Target)
 *     e.g. (Terminal)-[:Terminal_ConnectivityNode]->(ConnectivityNode)
 *
 * EXPORT MODES:
 *   ALL            — all objects in the job
 *   PHYSICAL_ONLY  — only category=PHYSICAL objects
 *   REQUIRED_ONLY  — only isRequired=true objects
 *   CUSTOM         — caller specifies cimTypes list
 *
 * PERFORMANCE:
 *   - UNWIND batch writes (500 per transaction) — single round trip per batch
 *   - Constraint on mrid ensures idempotent re-export
 *   - Async for large jobs
 *   - Relationships exported after all nodes are present
 */
@Service
public class Neo4jExportService {

    private static final Logger log = LoggerFactory.getLogger(Neo4jExportService.class);

    @Value("${cim.neo4j.export.batch-size:500}")
    private int batchSize;

    @Value("${cim.neo4j.export.create-constraints:true}")
    private boolean createConstraints;

    private final Driver                    driver;
    private final MongoTemplate             mongo;
    private final CimObjectRecordRepository objectRepo;
    private final Neo4jExportJobRepository  exportRepo;
    private final ValidationJobRepository   jobRepo;

    public Neo4jExportService(Driver driver, MongoTemplate mongo,
                               CimObjectRecordRepository objectRepo,
                               Neo4jExportJobRepository exportRepo,
                               ValidationJobRepository jobRepo) {
        this.driver     = driver;
        this.mongo      = mongo;
        this.objectRepo = objectRepo;
        this.exportRepo = exportRepo;
        this.jobRepo    = jobRepo;
    }

    // ── Export modes ──────────────────────────────────────────────────────

    public enum ExportMode { ALL, PHYSICAL_ONLY, REQUIRED_ONLY, CUSTOM }

    public record ExportRequest(
        String jobId,
        ExportMode mode,
        List<String> cimTypes,   // for CUSTOM mode
        boolean clearFirst       // delete existing nodes for this version first
    ) {}

    // ── Start export ──────────────────────────────────────────────────────

    public Neo4jExportJob startExport(ExportRequest req) {
        String exportId = UUID.randomUUID().toString();
        String version  = jobRepo.findByJobId(req.jobId())
                .map(j -> j.getNetworkVersion()).orElse("unknown");

        Neo4jExportJob job = new Neo4jExportJob(
                exportId, req.jobId(), version, req.mode().name());
        exportRepo.save(job);

        exportAsync(req, job);
        return job;
    }

    @Async
    CompletableFuture<Void> exportAsync(ExportRequest req, Neo4jExportJob job) {
        try {
            job.setStatus("RUNNING"); exportRepo.save(job);
            long start = System.currentTimeMillis();

            // Setup constraints
            if (createConstraints) ensureConstraints();

            // Clear existing nodes for this version if requested
            if (req.clearFirst()) clearExistingNodes(job.getNetworkVersion());

            // Export nodes
            int[] counts = exportNodes(req, job);
            int nodes = counts[0], rels = counts[1];

            job.setStatus("DONE");
            job.setNodesExported(nodes);
            job.setRelsExported(rels);
            job.setCompletedAt(Instant.now());
            job.setProcessingMs(System.currentTimeMillis() - start);
            exportRepo.save(job);

            log.info("Neo4j export done: exportId={} nodes={} rels={} in {}ms",
                    job.getExportId(), nodes, rels,
                    System.currentTimeMillis() - start);

        } catch (Exception e) {
            log.error("Neo4j export failed: {}", e.getMessage());
            job.setStatus("FAILED"); job.setErrorMessage(e.getMessage());
            job.setCompletedAt(Instant.now()); exportRepo.save(job);
        }
        return CompletableFuture.completedFuture(null);
    }

    // ── Neo4j constraint setup ────────────────────────────────────────────

    private void ensureConstraints() {
        try (Session s = driver.session()) {
            // Unique constraint on mrid for all CIM nodes
            s.run("CREATE CONSTRAINT cim_mrid_unique IF NOT EXISTS " +
                  "FOR (n:CIMObject) REQUIRE n.mrid IS UNIQUE");
            // Index on rdfId for relationship resolution
            s.run("CREATE INDEX cim_rdfid_idx IF NOT EXISTS " +
                  "FOR (n:CIMObject) ON (n.rdfId)");
            log.info("Neo4j constraints/indexes ensured");
        } catch (Neo4jException e) {
            log.warn("Constraint setup: {}", e.getMessage());
        }
    }

    // ── Clear existing nodes ──────────────────────────────────────────────

    private void clearExistingNodes(String version) {
        try (Session s = driver.session()) {
            s.run("MATCH (n:CIMObject {version: $v}) DETACH DELETE n",
                    Map.of("v", version));
            log.info("Cleared existing Neo4j nodes for version={}", version);
        }
    }

    // ── Export nodes + relationships ──────────────────────────────────────

    private int[] exportNodes(ExportRequest req, Neo4jExportJob job) {
        int totalNodes = 0, totalRels = 0;
        int page = 0;

        while (true) {
            Page<CimObjectRecord> pageResult = getPage(req, page);
            if (pageResult.isEmpty()) break;

            List<CimObjectRecord> records = pageResult.getContent();

            // Batch write nodes using UNWIND
            List<Map<String, Object>> nodeBatch = records.stream()
                    .map(this::toNodeProps)
                    .collect(Collectors.toList());

            totalNodes += writeNodeBatch(nodeBatch);

            // Batch write relationships for records that have resolved refs
            List<Map<String, Object>> relBatch = new ArrayList<>();
            for (CimObjectRecord rec : records) {
                if (rec.getResolvedRefIds() != null && !rec.getResolvedRefIds().isEmpty()) {
                    MapKeySanitizer.decodeKeys(rec.getResolvedRefIds())
                            .forEach((key, targetRdfId) -> relBatch.add(Map.of(
                                "sourceRdfId",  rec.getRdfId(),
                                "targetRdfId",  targetRdfId,
                                "relType",      sanitizeRelType(key),
                                "version",      rec.getVersion() != null ? rec.getVersion() : ""
                            )));
                }
            }

            if (!relBatch.isEmpty()) totalRels += writeRelBatch(relBatch);

            if (page % 10 == 0) {
                log.info("Neo4j export: page={} nodes={} rels={}", page, totalNodes, totalRels);
            }
            page++;
        }
        return new int[]{totalNodes, totalRels};
    }

    // ── UNWIND batch node write ───────────────────────────────────────────

    private int writeNodeBatch(List<Map<String,Object>> batch) {
        if (batch.isEmpty()) return 0;
        try (Session s = driver.session()) {
            s.executeWriteWithoutResult(tx -> {
                // MERGE on rdfId — idempotent re-export
                tx.run(
                    "UNWIND $batch AS p " +
                    "MERGE (n:CIMObject {rdfId: p.rdfId}) " +
                    "SET n += p " +
                    "WITH n, p " +
                    "CALL apoc.create.addLabels(n, [p.cimType]) YIELD node " +
                    "RETURN count(node)",
                    Map.of("batch", batch));
            });
        } catch (Neo4jException e) {
            // Fallback: write without apoc if not installed
            writeBatchNoApoc(batch);
        }
        return batch.size();
    }

    private void writeBatchNoApoc(List<Map<String,Object>> batch) {
        // Group by cimType for individual UNWIND per label
        Map<String, List<Map<String,Object>>> byType = new LinkedHashMap<>();
        batch.forEach(p -> byType.computeIfAbsent(
                (String) p.get("cimType"), k -> new ArrayList<>()).add(p));

        byType.forEach((type, nodes) -> {
            try (Session s = driver.session()) {
                // Safe label — letters and underscores only
                String label = sanitizeLabel(type);
                s.executeWriteWithoutResult(tx -> tx.run(
                    "UNWIND $batch AS p " +
                    "MERGE (n:" + label + ":CIMObject {rdfId: p.rdfId}) " +
                    "SET n += p",
                    Map.of("batch", nodes)));
            }
        });
    }

    // ── UNWIND batch relationship write ──────────────────────────────────

    private int writeRelBatch(List<Map<String,Object>> batch) {
        if (batch.isEmpty()) return 0;

        // Group by relType
        Map<String, List<Map<String,Object>>> byRel = new LinkedHashMap<>();
        batch.forEach(r -> byRel.computeIfAbsent(
                (String) r.get("relType"), k -> new ArrayList<>()).add(r));

        int total = 0;
        for (Map.Entry<String, List<Map<String,Object>>> e : byRel.entrySet()) {
            String relType = e.getKey();
            try (Session s = driver.session()) {
                s.executeWriteWithoutResult(tx -> tx.run(
                    "UNWIND $batch AS r " +
                    "MATCH (src:CIMObject {rdfId: r.sourceRdfId}) " +
                    "MATCH (tgt:CIMObject {rdfId: r.targetRdfId}) " +
                    "MERGE (src)-[:" + relType + " {version: r.version}]->(tgt)",
                    Map.of("batch", e.getValue())));
            } catch (Exception ex) {
                log.warn("Rel batch write failed for {}: {}", relType, ex.getMessage());
            }
            total += e.getValue().size();
        }
        return total;
    }

    // ── Query helpers ─────────────────────────────────────────────────────

    private Page<CimObjectRecord> getPage(ExportRequest req, int page) {
        PageRequest pr = PageRequest.of(page, batchSize);
        return switch (req.mode()) {
            case ALL           -> objectRepo.findByJobId(req.jobId(), pr);
            case PHYSICAL_ONLY -> {
                Query q = new Query(Criteria.where("jobId").is(req.jobId())
                        .and("category").is("PHYSICAL")).with(pr);
                var list = mongo.find(q, CimObjectRecord.class);
                yield new org.springframework.data.domain.PageImpl<>(list, pr, list.size());
            }
            case REQUIRED_ONLY -> {
                Query q = new Query(Criteria.where("jobId").is(req.jobId())
                        .and("isRequired").is(true)).with(pr);
                var list = mongo.find(q, CimObjectRecord.class);
                yield new org.springframework.data.domain.PageImpl<>(list, pr, list.size());
            }
            case CUSTOM -> {
                Query q = new Query(Criteria.where("jobId").is(req.jobId())
                        .and("cimType").in(req.cimTypes())).with(pr);
                var list = mongo.find(q, CimObjectRecord.class);
                yield new org.springframework.data.domain.PageImpl<>(list, pr, list.size());
            }
        };
    }

    // ── Conversion ────────────────────────────────────────────────────────

    private Map<String, Object> toNodeProps(CimObjectRecord rec) {
        Map<String, Object> props = new LinkedHashMap<>();
        props.put("rdfId",      rec.getRdfId());
        props.put("mrid",       rec.getMrid() != null ? rec.getMrid() : rec.getRdfId());
        props.put("cimType",    rec.getCimType());
        props.put("name",       rec.getName() != null ? rec.getName() : "");
        props.put("category",   rec.getCategory() != null ? rec.getCategory() : "UNKNOWN");
        props.put("isRequired", rec.isRequired());
        props.put("version",    rec.getVersion() != null ? rec.getVersion() : "");
        props.put("jobId",      rec.getJobId());
        // Add all CIM attributes as node properties (decoded keys)
        if (rec.getAttributes() != null) {
            MapKeySanitizer.decodeKeys(rec.getAttributes())
                    .forEach((k, v) -> props.put(sanitizePropKey(k), v));
        }
        return props;
    }

    /** "ACLineSegment.r" → "ACLineSegment_r" (Neo4j label safe) */
    private String sanitizeLabel(String t) {
        if (t == null) return "Unknown";
        return t.replaceAll("[^A-Za-z0-9_]", "_");
    }

    /** "Terminal.ConnectivityNode" → "Terminal_ConnectivityNode" */
    private String sanitizeRelType(String key) {
        if (key == null) return "REFERENCES";
        return key.replaceAll("[^A-Za-z0-9_]", "_").toUpperCase();
    }

    /** "ACLineSegment.r" → "ACLineSegment_r" (Neo4j property key safe) */
    private String sanitizePropKey(String k) {
        if (k == null) return "unknown";
        return k.replace(".", "_");
    }

    // ── Export status ─────────────────────────────────────────────────────

    public Optional<Neo4jExportJob> getExportStatus(String exportId) {
        return exportRepo.findByExportId(exportId);
    }

    public List<Neo4jExportJob> getRecentExports() {
        return exportRepo.findTop10ByOrderByStartedAtDesc();
    }
}
