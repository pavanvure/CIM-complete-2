package com.cim.streaming;

import com.cim.model.cim.CIMObject;
import org.springframework.stereotype.Component;

import javax.xml.stream.*;
import java.io.*;
import java.util.function.Consumer;

/**
 * StAX XMLStreamReader (cursor API) — O(1) memory, ~280K objects/sec.
 * Java 11 compatible.
 */
@Component
public class StreamingRdfXmlParser {

    private static final String NS_RDF  = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
    private static final int    BUF     = 65536;

    public long stream(InputStream in, String fileName,
                       Consumer<CIMObject> onObject) throws Exception {
        XMLInputFactory fac = XMLInputFactory.newInstance();
        fac.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
        fac.setProperty(XMLInputFactory.SUPPORT_DTD, false);
        fac.setProperty(XMLInputFactory.IS_COALESCING, true);
        XMLStreamReader r = fac.createXMLStreamReader(new BufferedInputStream(in, BUF));

        long          count   = 0;
        int           depth   = 0;
        CIMObject     current = null;
        String        attrKey = null;
        boolean       inAttr  = false;
        StringBuilder buf     = new StringBuilder(256);

        try {
            while (r.hasNext()) {
                int event = r.next();
                switch (event) {
                    case XMLStreamConstants.START_ELEMENT -> {
                        depth++;
                        String ns = r.getNamespaceURI(), local = r.getLocalName();
                        buf.setLength(0);
                        if (depth == 2) {
                            current = parseObject(r, fileName);
                        } else if (depth == 3 && current != null) {
                            attrKey = local; inAttr = true; buf.setLength(0);
                            String ref = r.getAttributeValue(NS_RDF, "resource");
                            if (ref != null && !ref.isBlank()) {
                                current.addReference(attrKey, cleanRef(ref));
                                inAttr = false;
                            }
                        }
                    }
                    case XMLStreamConstants.CHARACTERS, XMLStreamConstants.CDATA -> {
                        if (inAttr && current != null) buf.append(r.getText());
                    }
                    case XMLStreamConstants.END_ELEMENT -> {
                        if (depth == 3 && inAttr && current != null && attrKey != null) {
                            String val = buf.toString().trim();
                            if (!val.isEmpty()) current.setAttribute(attrKey, val);
                            inAttr = false; attrKey = null; buf.setLength(0);
                        }
                        if (depth == 2 && current != null) {
                            onObject.accept(current); count++; current = null;
                        }
                        depth--;
                    }
                }
            }
        } finally { r.close(); }
        return count;
    }

    private CIMObject parseObject(XMLStreamReader r, String fileName) {
        String local = r.getLocalName();
        if (local == null || local.isBlank()) return null;
        String rdfId = r.getAttributeValue(NS_RDF, "ID");
        if (rdfId == null || rdfId.isBlank()) rdfId = r.getAttributeValue(NS_RDF, "about");
        if (rdfId == null || rdfId.isBlank()) return null;
        rdfId = cleanRef(rdfId);
        CIMObject obj = new CIMObject(local.intern(), rdfId);
        String mrid = getAttrLocal(r, "mrid");
        obj.setMrid(mrid != null && !mrid.isBlank() ? cleanRef(mrid) : rdfId);
        obj.setSourceFormat("RDF_XML");
        obj.setSourceFile(fileName);
        return obj;
    }

    private String getAttrLocal(XMLStreamReader r, String name) {
        for (int i = 0; i < r.getAttributeCount(); i++)
            if (name.equalsIgnoreCase(r.getAttributeLocalName(i)))
                return r.getAttributeValue(i);
        return null;
    }

    private String cleanRef(String v) {
        if (v == null) return null;
        v = v.trim();
        return v.startsWith("#") ? v.substring(1) : v;
    }
}
