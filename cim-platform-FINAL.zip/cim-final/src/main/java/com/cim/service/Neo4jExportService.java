package com.cim.service;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.model.mongo.Neo4jExportJob;
import com.cim.model.mongo.ExportRequest;
import com.cim.model.mongo.ExportRequest.ExportMode;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.repository.Neo4jExportJobRepository;
import com.cim.repository.ValidationJobRepository;
import com.cim.util.MapKeySanitizer;
import org.neo4j.driver.*;
import org.neo4j.driver.exceptions.Neo4jException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * Neo4j Export Service — Java 11 + Neo4j Driver 4.4.x compatible
 *
 * Changes from previous version:
 *   1. Driver 4.4.x API: session.writeTransaction() not executeWriteWithoutResult()
 *   2. No APOC plugin required — labels applied via dynamic Cypher per cimType
 *   3. Java 11 compatible — no yield, no records, no text blocks
 *
 * GRAPH MODEL:
 *   Node:         (n:ACLineSegment:CIMObject {mrid, rdfId, name, ...attributes})
 *   Relationship: (Terminal)-[:TERMINAL_CONNECTIVITYNODE]->(ConnectivityNode)
 */
@Service
public class Neo4jExportService {

    private static final Logger log = LoggerFactory.getLogger(Neo4jExportService.class);

    @Value("${cim.neo4j.export.batch-size:500}")
    private int batchSize;

    @Value("${cim.neo4j.export.create-constraints:true}")
    private boolean createConstraints;

    private final Driver                    driver;
    private final MongoTemplate             mongo;
    private final CimObjectRecordRepository objectRepo;
    private final Neo4jExportJobRepository  exportRepo;
    private final ValidationJobRepository   jobRepo;

    public Neo4jExportService(Driver driver, MongoTemplate mongo,
                               CimObjectRecordRepository objectRepo,
                               Neo4jExportJobRepository exportRepo,
                               ValidationJobRepository jobRepo) {
        this.driver     = driver;
        this.mongo      = mongo;
        this.objectRepo = objectRepo;
        this.exportRepo = exportRepo;
        this.jobRepo    = jobRepo;
    }

    // ── Start export ──────────────────────────────────────────────────────

    public Neo4jExportJob startExport(ExportRequest req) {
        String exportId = UUID.randomUUID().toString();
        String version  = jobRepo.findByJobId(req.getJobId())
                .map(j -> j.getNetworkVersion() != null ? j.getNetworkVersion() : "unknown")
                .orElse("unknown");
        String orgId = jobRepo.findByJobId(req.getJobId())
                .map(j -> j.getOrgId() != null ? j.getOrgId() : "")
                .orElse("");

        Neo4jExportJob job = new Neo4jExportJob(
                exportId, req.getJobId(), version, orgId, req.getMode().name());
        exportRepo.save(job);
        exportAsync(req, job);
        return job;
    }

    @Async
    CompletableFuture<Void> exportAsync(ExportRequest req, Neo4jExportJob job) {
        try {
            job.setStatus("RUNNING");
            exportRepo.save(job);
            long start = System.currentTimeMillis();

            if (createConstraints) ensureConstraints();
            if (req.isClearFirst()) clearExistingNodes(job.getNetworkVersion());

            int[] counts = exportAllObjects(req, job);

            job.setStatus("DONE");
            job.setNodesExported(counts[0]);
            job.setRelsExported(counts[1]);
            job.setCompletedAt(Instant.now());
            job.setProcessingMs(System.currentTimeMillis() - start);
            exportRepo.save(job);

            log.info("Neo4j export done: exportId={} nodes={} rels={} in {}ms",
                    job.getExportId(), counts[0], counts[1],
                    System.currentTimeMillis() - start);

        } catch (Exception e) {
            log.error("Neo4j export failed: {}", e.getMessage());
            job.setStatus("FAILED");
            job.setErrorMessage(e.getMessage());
            job.setCompletedAt(Instant.now());
            exportRepo.save(job);
        }
        return CompletableFuture.completedFuture(null);
    }

    // ── Constraints ───────────────────────────────────────────────────────

    private void ensureConstraints() {
        try (Session s = driver.session()) {
            // Driver 4.4.x writeTransaction API
            s.writeTransaction(tx -> {
                try {
                    tx.run("CREATE CONSTRAINT cim_mrid_unique IF NOT EXISTS " +
                           "ON (n:CIMObject) ASSERT n.mrid IS UNIQUE");
                } catch (Exception e) {
                    log.debug("Constraint may already exist: {}", e.getMessage());
                }
                try {
                    tx.run("CREATE INDEX cim_rdfid_idx IF NOT EXISTS " +
                           "FOR (n:CIMObject) ON (n.rdfId)");
                } catch (Exception e) {
                    log.debug("Index may already exist: {}", e.getMessage());
                }
                return null; // writeTransaction requires return value in 4.4.x
            });
            log.info("Neo4j constraints/indexes ensured");
        } catch (Exception e) {
            log.warn("Constraint setup warning: {}", e.getMessage());
        }
    }

    private void clearExistingNodes(String version) {
        try (Session s = driver.session()) {
            s.writeTransaction(tx -> {
                tx.run("MATCH (n:CIMObject {version: $v}) DETACH DELETE n",
                        Values.parameters("v", version));
                return null;
            });
            log.info("Cleared existing Neo4j nodes for version={}", version);
        }
    }

    // ── Main export loop ──────────────────────────────────────────────────

    private int[] exportAllObjects(ExportRequest req, Neo4jExportJob job) {
        int totalNodes = 0, totalRels = 0, page = 0;

        while (true) {
            Page<CimObjectRecord> pageResult = getPage(req, page);
            if (pageResult.isEmpty()) break;

            List<CimObjectRecord> records = pageResult.getContent();

            // Export nodes — grouped by cimType for label assignment
            totalNodes += writeNodeBatch(records);

            // Export relationships for records that have resolved refs
            List<Map<String, Object>> relBatch = new ArrayList<>();
            for (CimObjectRecord rec : records) {
                if (rec.getResolvedRefIds() != null
                        && !rec.getResolvedRefIds().isEmpty()) {
                    Map<String, String> decoded =
                            MapKeySanitizer.decodeKeys(rec.getResolvedRefIds());
                    for (Map.Entry<String, String> e : decoded.entrySet()) {
                        Map<String, Object> rel = new LinkedHashMap<>();
                        rel.put("sourceRdfId", rec.getRdfId());
                        rel.put("targetRdfId", e.getValue());
                        rel.put("relType",     sanitizeRelType(e.getKey()));
                        rel.put("version",     rec.getVersion() != null ? rec.getVersion() : "");
                        relBatch.add(rel);
                    }
                }
            }
            if (!relBatch.isEmpty()) totalRels += writeRelBatch(relBatch);

            if (page % 10 == 0) {
                log.info("Neo4j export: page={} nodes={} rels={}", page, totalNodes, totalRels);
            }
            page++;
        }
        return new int[]{totalNodes, totalRels};
    }

    // ── Node batch write — no APOC, grouped by cimType ───────────────────

    /**
     * Writes nodes to Neo4j grouped by cimType.
     * Each cimType gets its own UNWIND statement with the label embedded
     * directly in the Cypher string — no APOC plugin required.
     *
     * Example Cypher generated:
     *   UNWIND $batch AS p
     *   MERGE (n:ACLineSegment:CIMObject {rdfId: p.rdfId})
     *   SET n += p
     *
     * Driver 4.4.x: session.writeTransaction(tx -> { ... return null; })
     */
    private int writeNodeBatch(List<CimObjectRecord> records) {
        if (records.isEmpty()) return 0;

        // Group by cimType so each Cypher has the label statically in the query
        Map<String, List<Map<String, Object>>> byType = new LinkedHashMap<>();
        for (CimObjectRecord rec : records) {
            String label = sanitizeLabel(rec.getCimType());
            Map<String, Object> props = toNodeProps(rec);
            byType.computeIfAbsent(label, k -> new ArrayList<>()).add(props);
        }

        int written = 0;
        for (Map.Entry<String, List<Map<String, Object>>> e : byType.entrySet()) {
            String label = e.getKey();
            List<Map<String, Object>> batch = e.getValue();
            String cypher = "UNWIND $batch AS p " +
                            "MERGE (n:" + label + ":CIMObject {rdfId: p.rdfId}) " +
                            "SET n += p";
            try (Session s = driver.session()) {
                final String finalCypher = cypher;
                final List<Map<String, Object>> finalBatch = batch;
                s.writeTransaction(tx -> {
                    tx.run(finalCypher, Values.parameters("batch", finalBatch));
                    return null; // required by 4.4.x writeTransaction
                });
                written += batch.size();
            } catch (Neo4jException ex) {
                log.warn("Node write failed for label={}: {}", label, ex.getMessage());
            }
        }
        return written;
    }

    // ── Relationship batch write ──────────────────────────────────────────

    private int writeRelBatch(List<Map<String, Object>> batch) {
        if (batch.isEmpty()) return 0;

        // Group by relationship type
        Map<String, List<Map<String, Object>>> byRel = new LinkedHashMap<>();
        for (Map<String, Object> r : batch) {
            String relType = (String) r.get("relType");
            byRel.computeIfAbsent(relType, k -> new ArrayList<>()).add(r);
        }

        int total = 0;
        for (Map.Entry<String, List<Map<String, Object>>> e : byRel.entrySet()) {
            String relType = e.getKey();
            List<Map<String, Object>> relBatch = e.getValue();
            String cypher = "UNWIND $batch AS r " +
                            "MATCH (src:CIMObject {rdfId: r.sourceRdfId}) " +
                            "MATCH (tgt:CIMObject {rdfId: r.targetRdfId}) " +
                            "MERGE (src)-[:" + relType + " {version: r.version}]->(tgt)";
            try (Session s = driver.session()) {
                final String finalCypher = cypher;
                final List<Map<String, Object>> finalBatch = relBatch;
                s.writeTransaction(tx -> {
                    tx.run(finalCypher, Values.parameters("batch", finalBatch));
                    return null;
                });
                total += relBatch.size();
            } catch (Neo4jException ex) {
                log.warn("Rel write failed for {}: {}", relType, ex.getMessage());
            }
        }
        return total;
    }

    // ── Page query — Java 11 if/else (no switch expression / yield) ───────

    private Page<CimObjectRecord> getPage(ExportRequest req, int page) {
        PageRequest pr = PageRequest.of(page, batchSize);

        if (req.getMode() == ExportMode.ALL) {
            return objectRepo.findByJobId(req.getJobId(), pr);

        } else if (req.getMode() == ExportMode.PHYSICAL_ONLY) {
            Query q = new Query(Criteria.where("jobId").is(req.getJobId())
                    .and("category").is("PHYSICAL")).with(pr);
            List<CimObjectRecord> list = mongo.find(q, CimObjectRecord.class);
            return new org.springframework.data.domain.PageImpl<>(list, pr, list.size());

        } else if (req.getMode() == ExportMode.REQUIRED_ONLY) {
            Query q = new Query(Criteria.where("jobId").is(req.getJobId())
                    .and("isRequired").is(true)).with(pr);
            List<CimObjectRecord> list = mongo.find(q, CimObjectRecord.class);
            return new org.springframework.data.domain.PageImpl<>(list, pr, list.size());

        } else if (req.getMode() == ExportMode.CUSTOM) {
            Query q = new Query(Criteria.where("jobId").is(req.getJobId())
                    .and("cimType").in(req.getCimTypes())).with(pr);
            List<CimObjectRecord> list = mongo.find(q, CimObjectRecord.class);
            return new org.springframework.data.domain.PageImpl<>(list, pr, list.size());

        } else {
            return objectRepo.findByJobId(req.getJobId(), pr);
        }
    }

    // ── Node properties builder ───────────────────────────────────────────

    private Map<String, Object> toNodeProps(CimObjectRecord rec) {
        Map<String, Object> props = new LinkedHashMap<>();
        props.put("rdfId",      rec.getRdfId() != null ? rec.getRdfId() : "");
        props.put("mrid",       rec.getMrid()  != null ? rec.getMrid()  : rec.getRdfId());
        props.put("cimType",    rec.getCimType() != null ? rec.getCimType() : "Unknown");
        props.put("name",       rec.getName()  != null ? rec.getName()  : "");
        props.put("category",   rec.getCategory() != null ? rec.getCategory() : "UNKNOWN");
        props.put("isRequired", rec.isRequired());
        props.put("version",    rec.getVersion() != null ? rec.getVersion() : "");
        props.put("orgId",      rec.getOrgId() != null ? rec.getOrgId() : "");
        props.put("jobId",      rec.getJobId() != null ? rec.getJobId() : "");

        // Add all CIM attributes — decoded keys (dots restored)
        if (rec.getAttributes() != null) {
            MapKeySanitizer.decodeKeys(rec.getAttributes())
                    .forEach((k, v) -> props.put(sanitizePropKey(k), v));
        }
        return props;
    }

    // ── String sanitizers ─────────────────────────────────────────────────

    /** "ACLineSegment" → "ACLineSegment" (letters/digits/underscore only) */
    private String sanitizeLabel(String t) {
        if (t == null || t.isBlank()) return "Unknown";
        return t.replaceAll("[^A-Za-z0-9_]", "_");
    }

    /** "Terminal.ConnectivityNode" → "TERMINAL_CONNECTIVITYNODE" */
    private String sanitizeRelType(String key) {
        if (key == null || key.isBlank()) return "REFERENCES";
        return key.replaceAll("[^A-Za-z0-9_]", "_").toUpperCase();
    }

    /** "ACLineSegment.r" → "ACLineSegment_r" */
    private String sanitizePropKey(String k) {
        if (k == null) return "unknown";
        return k.replace(".", "_").replace(":", "_");
    }

    // ── Status ────────────────────────────────────────────────────────────

    public Optional<Neo4jExportJob> getExportStatus(String exportId) {
        return exportRepo.findByExportId(exportId);
    }

    public List<Neo4jExportJob> getRecentExports() {
        return exportRepo.findTop10ByOrderByStartedAtDesc();
    }
}
