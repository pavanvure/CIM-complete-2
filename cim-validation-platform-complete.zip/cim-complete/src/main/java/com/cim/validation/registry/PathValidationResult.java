package com.cim.validation.registry;

public class PathValidationResult {

    public enum Status { VALID, INVALID, VENDOR_EXTENSION, UNKNOWN_TYPE }

    private final Status status;
    private final String explanation;

    private PathValidationResult(Status status, String explanation) {
        this.status      = status;
        this.explanation = explanation;
    }

    public Status  getStatus()      { return status; }
    public String  getExplanation() { return explanation; }
    public boolean isValid()        { return status == Status.VALID; }

    public static PathValidationResult valid(String type, String tag, String dc) {
        return new PathValidationResult(Status.VALID,
                "'" + dc + "' is in the inheritance chain of '" + type + "'");
    }

    public static PathValidationResult invalid(String type, String tag, String dc) {
        return new PathValidationResult(Status.INVALID,
                "'" + dc + "' is NOT in the inheritance chain of '" + type + "'");
    }

    public static PathValidationResult vendorExtension(String type, String tag) {
        return new PathValidationResult(Status.VENDOR_EXTENSION,
                "'" + tag + "' uses a vendor namespace — not in CIM standard");
    }

    public static PathValidationResult unknownType(String type, String tag) {
        return new PathValidationResult(Status.UNKNOWN_TYPE,
                "'" + type + "' is not registered in the CIM hierarchy");
    }
}
