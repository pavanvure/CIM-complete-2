package com.cim.controller;

import com.cim.repository.CimClassRepository;
import com.cim.service.CIMStandardService;
import com.cim.service.Neo4jExportService;
import com.cim.model.mongo.ExportRequest;
import com.cim.model.mongo.ExportRequest.ExportMode;
import com.cim.validation.registry.CIMHierarchyRegistry;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;

/**
 * Admin API
 *
 * ── OWL Management ──────────────────────────────────────────────────
 * POST /api/admin/cim/upload-owl              single OWL file
 * POST /api/admin/cim/upload-owl/multiple     CPSM multi-profile
 * POST /api/admin/cim/reload                  reload from configured path
 * GET  /api/admin/cim/stats                   registry stats
 * GET  /api/admin/cim/classes                 list all classes
 * GET  /api/admin/cim/classes/{name}          class detail
 * GET  /api/admin/cim/chain/{name}            inheritance chain
 * POST /api/admin/cim/validate-path           test path validation
 *
 * ── Neo4j Export ────────────────────────────────────────────────────
 * POST /api/admin/neo4j/export                start export
 * GET  /api/admin/neo4j/exports               list recent exports
 * GET  /api/admin/neo4j/exports/{exportId}    export status
 *
 * Export modes:
 *   ALL           → all objects in job
 *   PHYSICAL_ONLY → only PHYSICAL category
 *   REQUIRED_ONLY → only isRequired=true
 *   CUSTOM        → specify cimTypes list
 */
@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    private final CIMStandardService   standardService;
    private final CIMHierarchyRegistry registry;
    private final CimClassRepository   classRepo;
    private final Neo4jExportService   exportService;

    public AdminController(CIMStandardService standardService,
                            CIMHierarchyRegistry registry,
                            CimClassRepository classRepo,
                            Neo4jExportService exportService) {
        this.standardService = standardService;
        this.registry        = registry;
        this.classRepo       = classRepo;
        this.exportService   = exportService;
    }

    // ── OWL ───────────────────────────────────────────────────────────────

    @PostMapping("/cim/upload-owl")
    public ResponseEntity<?> uploadOwl(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value="version", defaultValue="CIM17") String version) {
        if (file.isEmpty()) return ResponseEntity.badRequest()
                .body(Map.of("error","File is empty."));
        try {
            var r = standardService.uploadSingle(file, version);
            return ResponseEntity.ok(Map.of(
                "status","OK","cimVersion",r.version(),"totalClasses",r.total(),
                "physicalClasses",r.physical(),"logicalClasses",r.logical()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error",e.getMessage()));
        }
    }

    @PostMapping("/cim/upload-owl/multiple")
    public ResponseEntity<?> uploadMultipleOwls(
            @RequestParam("files") List<MultipartFile> files,
            @RequestParam(value="version", defaultValue="CIM17-CPSM") String version) {
        if (files == null || files.isEmpty()) return ResponseEntity.badRequest()
                .body(Map.of("error","No files provided."));
        try {
            var r = standardService.uploadMultiple(files, version);
            return ResponseEntity.ok(Map.of(
                "status","OK","cimVersion",r.version(),"totalClasses",r.total(),
                "files", files.stream().map(MultipartFile::getOriginalFilename).toList()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error",e.getMessage()));
        }
    }

    @PostMapping("/cim/reload")
    public ResponseEntity<?> reload() {
        try {
            var r = standardService.reload();
            return ResponseEntity.ok(Map.of("status","OK",
                    "cimVersion",r.version(),"totalClasses",r.total()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error",e.getMessage()));
        }
    }

    @GetMapping("/cim/stats")
    public ResponseEntity<?> stats() {
        return ResponseEntity.ok(registry.getStats());
    }

    @GetMapping("/cim/classes")
    public ResponseEntity<?> listClasses(
            @RequestParam(required=false) String category) {
        var classes = category != null
                ? classRepo.findByCategory(category.toUpperCase())
                : classRepo.findAll();
        return ResponseEntity.ok(Map.of("total",classes.size(),"classes",classes));
    }

    @GetMapping("/cim/classes/{name}")
    public ResponseEntity<?> getClass(@PathVariable String name) {
        var def = registry.getDefinition(name);
        if (def == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(Map.of(
            "className",     def.getClassName(),
            "parentClass",   def.getParentClass() != null ? def.getParentClass() : "ROOT",
            "ancestors",     def.getAncestors(),
            "ownAttributes", def.getOwnAttributes(),
            "category",      def.getCategory(),
            "required",      def.isRequired(),
            "stereotype",    def.getStereotype() != null ? def.getStereotype() : "",
            "cimPackage",    def.getCimPackage() != null ? def.getCimPackage() : "",
            "cimVersion",    def.getCimVersion(),
            "description",   def.getDescription() != null ? def.getDescription() : ""
        ));
    }

    @GetMapping("/cim/chain/{className}")
    public ResponseEntity<?> getChain(@PathVariable String className) {
        if (!registry.isKnownClass(className))
            return ResponseEntity.notFound().build();
        var chain = registry.getFullChain(className);
        return ResponseEntity.ok(Map.of(
            "className",className,"chain",chain,"depth",chain.size()-1));
    }

    @PostMapping("/cim/validate-path")
    public ResponseEntity<?> validatePath(@RequestBody Map<String,String> body) {
        String type = body.get("objectType");
        String tag  = body.get("attributeTag");
        if (type == null || tag == null) return ResponseEntity.badRequest()
                .body(Map.of("error","Both objectType and attributeTag required."));
        var result = registry.validateAttributePath(type, tag);
        return ResponseEntity.ok(Map.of(
            "objectType",type,"attributeTag",tag,
            "status",result.getStatus().name(),
            "valid",result.isValid(),
            "explanation",result.getExplanation(),
            "chain",registry.getFullChain(type)
        ));
    }

    // ── Neo4j Export ─────────────────────────────────────────────────────

    /**
     * POST /api/admin/neo4j/export
     *
     * Body:
     * {
     *   "jobId":      "uuid",
     *   "mode":       "ALL" | "PHYSICAL_ONLY" | "REQUIRED_ONLY" | "CUSTOM",
     *   "cimTypes":   ["ACLineSegment","Breaker"],   // for CUSTOM mode only
     *   "clearFirst": true                            // delete existing nodes first
     * }
     */
    @PostMapping("/neo4j/export")
    public ResponseEntity<?> startExport(@RequestBody Map<String,Object> body) {
        String jobId = (String) body.get("jobId");
        if (jobId == null || jobId.isBlank())
            return ResponseEntity.badRequest().body(Map.of("error","jobId required."));

        String modeStr = body.getOrDefault("mode","ALL").toString().toUpperCase();
        ExportMode mode;
        try { mode = ExportMode.valueOf(modeStr); }
        catch (Exception e) { return ResponseEntity.badRequest()
                .body(Map.of("error","Invalid mode: "+modeStr,
                        "valid","ALL, PHYSICAL_ONLY, REQUIRED_ONLY, CUSTOM")); }

        @SuppressWarnings("unchecked")
        List<String> cimTypes = (List<String>) body.getOrDefault("cimTypes",
                new java.util.ArrayList<>());
        if (mode == ExportMode.CUSTOM && cimTypes.isEmpty())
            return ResponseEntity.badRequest()
                    .body(Map.of("error","cimTypes required for CUSTOM mode."));

        boolean clearFirst = Boolean.parseBoolean(
                body.getOrDefault("clearFirst","false").toString());

        // Java 11 compatible ExportRequest POJO (not record)
        ExportRequest req = new ExportRequest(jobId, mode, cimTypes, clearFirst);
        com.cim.model.mongo.Neo4jExportJob exportJob = exportService.startExport(req);

        return ResponseEntity.accepted().body(Map.of(
            "exportId",  exportJob.getExportId(),
            "status",    exportJob.getStatus(),
            "jobId",     jobId,
            "mode",      mode.name(),
            "links",     Map.of(
                "status","/api/admin/neo4j/exports/"+exportJob.getExportId())
        ));
    }

    @GetMapping("/neo4j/exports")
    public ResponseEntity<?> listExports(
            @RequestParam(required=false) String networkVersion,
            @RequestParam(required=false) String orgId) {
        // Filter exports by version and/or orgId when provided
        List<com.cim.model.mongo.Neo4jExportJob> exports = exportService.getRecentExports();
        if (networkVersion != null && !networkVersion.isBlank()) {
            String v = networkVersion.trim();
            exports = exports.stream()
                    .filter(e -> v.equals(e.getNetworkVersion()))
                    .collect(java.util.stream.Collectors.toList());
        }
        if (orgId != null && !orgId.isBlank()) {
            String o = orgId.trim();
            exports = exports.stream()
                    .filter(e -> o.equals(e.getOrgId()))
                    .collect(java.util.stream.Collectors.toList());
        }
        return ResponseEntity.ok(Map.of(
            "total",   exports.size(),
            "exports", exports,
            "filter",  Map.of(
                "networkVersion", networkVersion != null ? networkVersion : "ALL",
                "orgId",          orgId          != null ? orgId          : "ALL"
            )
        ));
    }

    @GetMapping("/neo4j/exports/{exportId}")
    public ResponseEntity<?> getExport(@PathVariable String exportId) {
        return exportService.getExportStatus(exportId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
