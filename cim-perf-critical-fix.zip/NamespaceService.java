package com.cim.service;

import com.cim.model.mongo.NamespaceConfig;
import com.cim.repository.NamespaceConfigRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Namespace Configuration Service — WITH in-memory cache.
 *
 * Cache is REQUIRED for acceptable parse performance.
 *
 * WHY CACHE IS NEEDED:
 *   isEnabled() and shouldValidatePath() are called once per attribute
 *   during the parse loop. A typical CIM object has 8-15 attributes.
 *   3.4M objects × 10 attributes = 34M calls to isEnabled().
 *
 *   Without cache: 34M MongoDB queries × ~1ms each = 9+ hours parse time
 *   With cache:    34M ConcurrentHashMap lookups × ~10ns each = ~0.3 seconds
 *
 * WHY CACHE IS SAFE:
 *   Imports happen once every 1-3 months.
 *   Namespace configs change rarely (manually via REST API).
 *   Cache is refreshed immediately on every create/update/delete via REST.
 *   No staleness risk in practice.
 */
@Service
public class NamespaceService {

    private static final Logger log = LoggerFactory.getLogger(NamespaceService.class);

    private final NamespaceConfigRepository repo;

    /**
     * In-memory cache: prefix → NamespaceConfig.
     * Populated at startup and refreshed on every mutation.
     * ConcurrentHashMap: thread-safe for concurrent imports.
     */
    private final ConcurrentHashMap<String, NamespaceConfig> cache
            = new ConcurrentHashMap<>();

    public NamespaceService(NamespaceConfigRepository repo) {
        this.repo = repo;
    }

    // ── Startup ───────────────────────────────────────────────────────────

    @EventListener(ApplicationReadyEvent.class)
    public void initDefaults() {
        if (!repo.existsByPrefix("cim")) {
            repo.save(new NamespaceConfig(
                    "cim",
                    "http://iec.ch/TC57/CIM100#",
                    true, true,
                    "IEC CIM standard namespace — path validation applied"));
            log.info("Default 'cim' namespace created");
        }
        refreshCache();
        log.info("Namespace service ready — {} configs in cache (fast path)",
                cache.size());
    }

    // ── Hot-path lookups — called per ATTRIBUTE during parse ──────────────

    /**
     * True if namespace is enabled for attribute storage.
     * HOT PATH: called ~34M times during a 3.4M object import.
     * Uses cache — O(1) ConcurrentHashMap lookup.
     */
    public boolean isEnabled(String prefix) {
        NamespaceConfig cfg = cache.get(normalizePrefix(prefix));
        return cfg != null && cfg.isEnabled();
    }

    /**
     * True if path validation should run for this namespace.
     * HOT PATH: called per attribute for enabled namespaces.
     */
    public boolean shouldValidatePath(String prefix) {
        NamespaceConfig cfg = cache.get(normalizePrefix(prefix));
        return cfg != null && cfg.isEnabled() && cfg.isValidatePath();
    }

    /**
     * Extract namespace prefix from an attribute tag.
     *   "caiso:emsFlag"       → "caiso"
     *   "ACLineSegment.r"     → "cim"
     *   "IdentifiedObject.name" → "cim"
     */
    public String extractPrefix(String attributeTag) {
        if (attributeTag == null) return "cim";
        int colon = attributeTag.indexOf(':');
        return colon > 0 ? attributeTag.substring(0, colon) : "cim";
    }

    // ── CRUD — refreshes cache on every change ────────────────────────────

    public List<NamespaceConfig> getAll() {
        return repo.findAll();
    }

    public List<NamespaceConfig> getEnabled() {
        return repo.findByEnabled(true);
    }

    public Optional<NamespaceConfig> findByPrefix(String prefix) {
        return repo.findByPrefix(normalizePrefix(prefix));
    }

    public NamespaceConfig create(NamespaceConfig config, String createdBy) {
        String prefix = normalizePrefix(config.getPrefix());
        if (repo.existsByPrefix(prefix))
            throw new IllegalArgumentException(
                    "Namespace prefix '" + prefix + "' already exists.");

        config.setPrefix(prefix);
        config.setCreatedBy(createdBy);
        config.setCreatedAt(Instant.now());
        config.setUpdatedAt(Instant.now());
        NamespaceConfig saved = repo.save(config);

        // Refresh cache immediately — next import uses new config
        cache.put(prefix, saved);
        log.info("Namespace added: {} enabled={} validatePath={} (cache refreshed)",
                prefix, saved.isEnabled(), saved.isValidatePath());
        return saved;
    }

    public NamespaceConfig update(String prefix, boolean enabled,
                                   boolean validatePath) {
        String p = normalizePrefix(prefix);
        NamespaceConfig config = repo.findByPrefix(p)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Namespace '" + p + "' not found."));
        config.setEnabled(enabled);
        config.setValidatePath(validatePath);
        config.setUpdatedAt(Instant.now());
        NamespaceConfig saved = repo.save(config);

        // Update cache immediately
        cache.put(p, saved);
        log.info("Namespace updated: {} enabled={} validatePath={} (cache refreshed)",
                p, enabled, validatePath);
        return saved;
    }

    public void delete(String prefix) {
        String p = normalizePrefix(prefix);
        repo.findByPrefix(p).ifPresent(c -> {
            repo.delete(c);
            cache.remove(p);
            log.info("Namespace removed: {} (cache refreshed)", p);
        });
    }

    /**
     * Reload entire cache from MongoDB.
     * Called at startup and available as a REST endpoint for manual refresh.
     */
    public void refreshCache() {
        cache.clear();
        repo.findAll().forEach(c -> cache.put(normalizePrefix(c.getPrefix()), c));
        log.info("Namespace cache refreshed: {} configs loaded", cache.size());
    }

    private String normalizePrefix(String p) {
        return p == null ? "" : p.toLowerCase().trim();
    }
}
