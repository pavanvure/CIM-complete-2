package com.cim.streaming;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicLong;

public class ProgressTracker {

    private static final Logger log = LoggerFactory.getLogger(ProgressTracker.class);

    public enum Stage {
        DETECTING_FORMAT, STREAMING_PARSE, SAVING_TO_MONGO,
        RESOLVING_REFERENCES, DONE, FAILED
    }

    private final String     jobId;
    private final int        logEvery;
    private final Instant    startTime = Instant.now();
    private       Stage      stage     = Stage.DETECTING_FORMAT;
    private       String     stageDetail;
    private       String     errorMessage;
    private final AtomicLong parsed    = new AtomicLong();
    private final AtomicLong saved     = new AtomicLong();
    private final AtomicLong errors    = new AtomicLong();
    private final AtomicLong warnings  = new AtomicLong();

    public ProgressTracker(String jobId, int logEvery) {
        this.jobId    = jobId;
        this.logEvery = logEvery;
    }

    public void incrementParsed() {
        long v = parsed.incrementAndGet();
        if (v % logEvery == 0) logProgress();
    }
    public void incrementSaved(long n) { saved.addAndGet(n); }
    public void addValidated(long n)   { }
    public void setErrors(long n)      { errors.set(n); }
    public void setWarnings(long n)    { warnings.set(n); }

    public void setStage(Stage s, String detail) {
        this.stage       = s;
        this.stageDetail = detail;
        log.info("[Job {}] stage={} {}", jobId, s, detail != null ? detail : "");
    }

    public void log(String msg) {
        log.info("[Job {}] {}", jobId, msg);
    }

    public void done()            { stage = Stage.DONE; }
    public void fail(String msg)  { stage = Stage.FAILED; errorMessage = msg; }

    public ProgressSnapshot snapshot() {
        long now = Instant.now().toEpochMilli();
        long el  = now - startTime.toEpochMilli();
        long p   = parsed.get(), s = saved.get();
        double rate = el >= 1000 ? (p * 1000.0 / el) : 0;
        int pct = p > 0 ? (int) Math.min(100, s * 100L / Math.max(1, p)) : 0;
        return new ProgressSnapshot(jobId, stage.name(),
                stageDetail != null ? stageDetail : "",
                p, s, errors.get(), warnings.get(),
                el, formatMs(el), Math.round(rate), pct,
                stage == Stage.DONE || stage == Stage.FAILED, errorMessage);
    }

    private void logProgress() {
        long el = Instant.now().toEpochMilli() - startTime.toEpochMilli();
        double rate = el > 0 ? (parsed.get() * 1000.0 / el) : 0;
        log.info("[Job {}] stage={} parsed={} saved={} rate={}/s",
                jobId, stage, parsed.get(), saved.get(), (int)rate);
    }

    private String formatMs(long ms) {
        long s = ms/1000, h = s/3600, m = (s%3600)/60, sec = s%60;
        if (h > 0) return h+"h "+m+"m "+sec+"s";
        if (m > 0) return m+"m "+sec+"s";
        return sec+"s";
    }

    public String  getJobId()        { return jobId; }
    public Stage   getStage()        { return stage; }
    public long    getParsed()       { return parsed.get(); }
    public long    getSaved()        { return saved.get(); }
    public boolean isDone()          { return stage == Stage.DONE; }
    public boolean isFailed()        { return stage == Stage.FAILED; }
    public String  getErrorMessage() { return errorMessage; }
}

// ── ProgressSnapshot DTO ──────────────────────────────────────────

@JsonPropertyOrder({"jobId","stage","stageDetail","parsed","saved",
        "errors","warnings","elapsedMs","elapsedFormatted",
        "parseRatePerSec","percentSaved","finished","errorMessage"})
@JsonInclude(JsonInclude.Include.NON_NULL)
class ProgressSnapshot {
    private final String  jobId, stage, stageDetail, elapsedFormatted, errorMessage;
    private final long    parsed, saved, errors, warnings, elapsedMs, parseRatePerSec;
    private final int     percentSaved;
    private final boolean finished;

    ProgressSnapshot(String jobId, String stage, String stageDetail,
                      long parsed, long saved, long errors, long warnings,
                      long elapsedMs, String elapsedFormatted, long rate,
                      int pct, boolean finished, String errorMessage) {
        this.jobId             = jobId;
        this.stage             = stage;
        this.stageDetail       = stageDetail;
        this.parsed            = parsed;
        this.saved             = saved;
        this.errors            = errors;
        this.warnings          = warnings;
        this.elapsedMs         = elapsedMs;
        this.elapsedFormatted  = elapsedFormatted;
        this.parseRatePerSec   = rate;
        this.percentSaved      = pct;
        this.finished          = finished;
        this.errorMessage      = errorMessage;
    }

    public String  getJobId()             { return jobId; }
    public String  getStage()             { return stage; }
    public String  getStageDetail()       { return stageDetail; }
    public long    getParsed()            { return parsed; }
    public long    getSaved()             { return saved; }
    public long    getErrors()            { return errors; }
    public long    getWarnings()          { return warnings; }
    public long    getElapsedMs()         { return elapsedMs; }
    public String  getElapsedFormatted()  { return elapsedFormatted; }
    public long    getParseRatePerSec()   { return parseRatePerSec; }
    public int     getPercentSaved()      { return percentSaved; }
    public boolean isFinished()           { return finished; }
    public String  getErrorMessage()      { return errorMessage; }
}
