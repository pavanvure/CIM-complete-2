package com.cim.service;

import com.cim.model.mongo.NamespaceConfig;
import com.cim.repository.NamespaceConfigRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

/**
 * Namespace Configuration Service — NO in-memory cache.
 *
 * Cache removed because:
 *   - Imports happen once every 1-3 months
 *   - MongoDB query for a namespace config by prefix is fast (indexed)
 *   - No need to hold stale state in memory between rare imports
 *   - Simpler code — no cache invalidation logic
 *
 * Every isEnabled() / shouldValidatePath() call queries MongoDB directly.
 * MongoDB will use its own OS-level page cache for hot data automatically.
 */
@Service
public class NamespaceService {

    private static final Logger log = LoggerFactory.getLogger(NamespaceService.class);

    private final NamespaceConfigRepository repo;

    public NamespaceService(NamespaceConfigRepository repo) {
        this.repo = repo;
    }

    // ── Startup defaults ──────────────────────────────────────────────────

    @EventListener(ApplicationReadyEvent.class)
    public void initDefaults() {
        if (!repo.existsByPrefix("cim")) {
            repo.save(new NamespaceConfig("cim",
                    "http://iec.ch/TC57/CIM100#",
                    true, true,
                    "IEC CIM standard namespace — full path validation applied"));
            log.info("Default cim namespace created");
        }
        log.info("Namespace service ready — {} configs in DB", repo.count());
    }

    // ── Namespace lookup — direct MongoDB query, no cache ─────────────────

    /**
     * Get config for a prefix. Returns empty if not configured.
     * Queries MongoDB directly — no cache.
     */
    public Optional<NamespaceConfig> findByPrefix(String prefix) {
        return repo.findByPrefix(normalizePrefix(prefix));
    }

    /**
     * True if namespace is enabled for attribute storage.
     * Queries MongoDB directly.
     */
    public boolean isEnabled(String prefix) {
        return repo.findByPrefix(normalizePrefix(prefix))
                .map(NamespaceConfig::isEnabled)
                .orElse(false); // not configured = disabled
    }

    /**
     * True if path validation should run for this namespace.
     * Queries MongoDB directly.
     */
    public boolean shouldValidatePath(String prefix) {
        return repo.findByPrefix(normalizePrefix(prefix))
                .map(c -> c.isEnabled() && c.isValidatePath())
                .orElse(false);
    }

    /**
     * Extract namespace prefix from an attribute tag.
     * "caiso:emsFlag"       → "caiso"
     * "ACLineSegment.r"     → "cim"   (CIM format — no colon)
     * "IdentifiedObject.name" → "cim"
     */
    public String extractPrefix(String attributeTag) {
        if (attributeTag == null) return "cim";
        int colon = attributeTag.indexOf(':');
        if (colon > 0) return attributeTag.substring(0, colon);
        return "cim"; // no colon = standard CIM format
    }

    // ── CRUD ─────────────────────────────────────────────────────────────

    public List<NamespaceConfig> getAll()     { return repo.findAll(); }
    public List<NamespaceConfig> getEnabled() { return repo.findByEnabled(true); }

    public NamespaceConfig create(NamespaceConfig config, String createdBy) {
        String prefix = normalizePrefix(config.getPrefix());
        if (repo.existsByPrefix(prefix))
            throw new IllegalArgumentException(
                    "Namespace prefix '" + prefix + "' already exists.");
        config.setPrefix(prefix);
        config.setCreatedBy(createdBy);
        config.setCreatedAt(Instant.now());
        config.setUpdatedAt(Instant.now());
        NamespaceConfig saved = repo.save(config);
        log.info("Namespace added: {} enabled={} validatePath={}",
                prefix, saved.isEnabled(), saved.isValidatePath());
        return saved;
    }

    public NamespaceConfig update(String prefix, boolean enabled, boolean validatePath) {
        String p = normalizePrefix(prefix);
        NamespaceConfig config = repo.findByPrefix(p)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Namespace '" + p + "' not found."));
        config.setEnabled(enabled);
        config.setValidatePath(validatePath);
        config.setUpdatedAt(Instant.now());
        NamespaceConfig saved = repo.save(config);
        log.info("Namespace updated: {} enabled={} validatePath={}", p, enabled, validatePath);
        return saved;
    }

    public void delete(String prefix) {
        String p = normalizePrefix(prefix);
        repo.findByPrefix(p).ifPresent(c -> {
            repo.delete(c);
            log.info("Namespace removed: {}", p);
        });
    }

    private String normalizePrefix(String p) {
        return p == null ? "" : p.toLowerCase().trim();
    }
}
