package com.cim.service;

import com.cim.model.mongo.CimClassDefinition;
import com.cim.repository.CimClassRepository;
import com.cim.validation.registry.CIMHierarchyRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.*;

@Service
public class CIMStandardService {

    private static final Logger log = LoggerFactory.getLogger(CIMStandardService.class);

    @Value("${cim.owl.file-path:}")
    private String singleOwlPath;

    @Value("${cim.owl.profile-paths:}")
    private List<String> profilePaths;

    @Value("${cim.owl.version:CIM17}")
    private String cimVersion;

    private final CimClassRepository   mongoRepo;
    private final CIMHierarchyRegistry registry;
    private final CIMOwlParser         owlParser;

    public CIMStandardService(CimClassRepository mongoRepo,
                               CIMHierarchyRegistry registry,
                               CIMOwlParser owlParser) {
        this.mongoRepo  = mongoRepo;
        this.registry   = registry;
        this.owlParser  = owlParser;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void initOnStartup() {
        if (mongoRepo.count() > 0) {
            registry.load(mongoRepo.findAll());
            log.info("CIM registry loaded from MongoDB: {} classes", registry.size());
            return;
        }
        if (profilePaths != null && !profilePaths.isEmpty()) {
            try { loadFromMultipleFiles(profilePaths, cimVersion); return; }
            catch (Exception e) { log.error("Multi-profile OWL load failed: {}", e.getMessage()); }
        }
        if (singleOwlPath != null && !singleOwlPath.isBlank()) {
            try { loadFromSingleFile(singleOwlPath, cimVersion); return; }
            catch (Exception e) { log.error("Single OWL load failed: {}", e.getMessage()); }
        }
        log.warn("CIM registry empty. Upload OWL via POST /api/admin/cim/upload-owl");
    }

    public AdminLoadResult loadFromUploadedOwl(MultipartFile file, String version) throws Exception {
        List<CimClassDefinition> defs = owlParser.parse(file.getInputStream(), version, file.getOriginalFilename());
        persistDefinitions(defs);
        return toResult(version, defs);
    }

    public AdminLoadResult loadFromMultipleUploads(List<MultipartFile> files, String version) throws Exception {
        Map<String, InputStream> streams = new LinkedHashMap<>();
        for (MultipartFile f : files) streams.put(f.getOriginalFilename(), f.getInputStream());
        List<CimClassDefinition> defs = owlParser.parseMultiple(streams, version);
        persistDefinitions(defs);
        return toResult(version, defs);
    }

    public AdminLoadResult reload(String version) throws Exception {
        String v = (version != null && !version.isBlank()) ? version : cimVersion;
        if (profilePaths != null && !profilePaths.isEmpty()) loadFromMultipleFiles(profilePaths, v);
        else if (singleOwlPath != null && !singleOwlPath.isBlank()) loadFromSingleFile(singleOwlPath, v);
        else throw new IllegalStateException("No OWL path configured.");
        return toResult(v, mongoRepo.findAll());
    }

    private void loadFromSingleFile(String path, String version) throws Exception {
        File f = new File(path);
        if (!f.exists()) throw new FileNotFoundException("OWL not found: " + path);
        try (InputStream is = new BufferedInputStream(new FileInputStream(f), 65536)) {
            persistDefinitions(owlParser.parse(is, version, f.getName()));
        }
    }

    private void loadFromMultipleFiles(List<String> paths, String version) throws Exception {
        Map<String, InputStream> streams = new LinkedHashMap<>();
        List<InputStream> opened = new ArrayList<>();
        try {
            for (String path : paths) {
                File f = new File(path);
                if (!f.exists()) throw new FileNotFoundException("OWL not found: " + path);
                InputStream is = new BufferedInputStream(new FileInputStream(f), 65536);
                streams.put(f.getName(), is);
                opened.add(is);
            }
            persistDefinitions(owlParser.parseMultiple(streams, version));
        } finally {
            for (InputStream is : opened) try { is.close(); } catch (IOException ignored) {}
        }
    }

    private void persistDefinitions(List<CimClassDefinition> defs) {
        mongoRepo.deleteAll();
        mongoRepo.saveAll(defs);
        registry.load(defs);
        log.info("Persisted {} class definitions. Registry ready.", defs.size());
    }

    private AdminLoadResult toResult(String version, List<CimClassDefinition> defs) {
        long p = defs.stream().filter(d -> "PHYSICAL".equals(d.getCategory())).count();
        long l = defs.stream().filter(d -> "LOGICAL".equals(d.getCategory())).count();
        return new AdminLoadResult(version, defs.size(), (int)p, (int)l);
    }

    public record AdminLoadResult(String cimVersion, int totalClasses,
                                   int physicalClasses, int logicalClasses) {}
}
