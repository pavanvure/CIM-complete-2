package com.cim.util;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Encodes/decodes CIM attribute map keys for MongoDB storage.
 * MongoDB rejects dots in map keys. CIM uses "ClassName.attr" pattern.
 * U+FF0E (FULLWIDTH FULL STOP) is used as replacement.
 */
public class MapKeySanitizer {

    public static final String DOT_REPLACEMENT = "\uff0e";
    private static final String DOT = ".";

    private MapKeySanitizer() {}

    public static String encodeKey(String key) {
        return key == null ? null : key.replace(DOT, DOT_REPLACEMENT);
    }

    public static String decodeKey(String key) {
        return key == null ? null : key.replace(DOT_REPLACEMENT, DOT);
    }

    public static Map<String, String> encodeKeys(Map<String, String> input) {
        if (input == null || input.isEmpty()) return new LinkedHashMap<>();
        Map<String, String> result = new LinkedHashMap<>(input.size());
        input.forEach((k, v) -> result.put(encodeKey(k), v));
        return result;
    }

    public static Map<String, String> decodeKeys(Map<String, String> input) {
        if (input == null || input.isEmpty()) return new LinkedHashMap<>();
        Map<String, String> result = new LinkedHashMap<>(input.size());
        input.forEach((k, v) -> result.put(decodeKey(k), v));
        return result;
    }
}
