package com.cim.service;

import com.cim.model.mongo.NamespaceConfig;
import com.cim.repository.NamespaceConfigRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Namespace Configuration Service
 *
 * Manages which RDF namespaces are enabled for processing.
 * Controls attribute/reference storage and path validation per namespace.
 *
 * Default namespaces (auto-created on startup):
 *   cim    → enabled=true,  validatePath=true  (standard CIM)
 *   rdfs   → enabled=true,  validatePath=false (RDF schema)
 *   rdf    → enabled=true,  validatePath=false (RDF core)
 *
 * Custom namespaces (user-configured):
 *   caiso  → enabled=true,  validatePath=false (store as-is, no path check)
 *   spc    → enabled=false, validatePath=false (skip, log as UNKNOWN_NAMESPACE)
 *
 * REQ #2 logic in ImportService.toRecord():
 *   getNamespaceForTag("caiso:emsFlag"):
 *     prefix = "caiso"
 *     config = namespaceService.getConfig("caiso")
 *     if config.enabled → store attribute, no path validation
 *     if !config.enabled → log UNKNOWN_NAMESPACE in pathIssues
 *     if config not found → treat as disabled, log UNKNOWN_NAMESPACE
 */
@Service
public class NamespaceService {

    private static final Logger log = LoggerFactory.getLogger(NamespaceService.class);

    private final NamespaceConfigRepository repo;

    // In-memory cache — avoids DB lookup per attribute during parse
    private final Map<String, NamespaceConfig> cache = new ConcurrentHashMap<>();

    public NamespaceService(NamespaceConfigRepository repo) {
        this.repo = repo;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void initDefaults() {
        // ── CIM namespace — the only one that gets path validation ────────
        // All CIM attribute tags ("ACLineSegment.r", "IdentifiedObject.name" etc.)
        // use this namespace. Path validation checks declaring class against
        // OWL inheritance chain.
        createDefault("cim",
                "http://iec.ch/TC57/CIM100#",
                "IEC CIM standard namespace — full path validation applied",
                true,   // enabled
                true);  // validatePath=true ← CIM only

        // ── rdf, rdfs, owl, xsd — handled by parser, NOT stored as attributes ─
        // rdf:ID, rdf:resource, rdf:about → handled by StAX parser as rdfId/references
        // rdfs:label, owl:Class, xsd:* → appear in OWL files only, not in CIM data
        // These do NOT need to be in namespace_configs because they never reach
        // the attribute storage logic as regular attribute keys.
        //
        // If they appear in data files unexpectedly they will be logged as
        // UNKNOWN_NAMESPACE which is correct — they should not be in data files.

        // Load all into cache
        refreshCache();
        log.info("Namespace registry: {} configs loaded (default: cim only)",
                cache.size());
    }

    // ── Public API ────────────────────────────────────────────────────────

    /** Get config for a prefix. Returns null if not configured. */
    public NamespaceConfig getConfig(String prefix) {
        return cache.get(normalizePrefix(prefix));
    }

    /** True if namespace is enabled for storage */
    public boolean isEnabled(String prefix) {
        NamespaceConfig c = cache.get(normalizePrefix(prefix));
        return c != null && c.isEnabled();
    }

    /** True if path validation should run for this namespace */
    public boolean shouldValidatePath(String prefix) {
        NamespaceConfig c = cache.get(normalizePrefix(prefix));
        return c != null && c.isEnabled() && c.isValidatePath();
    }

    /**
     * Extract namespace prefix from an attribute tag.
     * "caiso:emsFlag"           → "caiso"
     * "ACLineSegment.r"         → "cim"   (CIM format without prefix)
     * "IdentifiedObject.name"   → "cim"
     */
    public String extractPrefix(String attributeTag) {
        if (attributeTag == null) return "cim";
        int colon = attributeTag.indexOf(':');
        if (colon > 0) return attributeTag.substring(0, colon);
        // No colon = CIM format (ClassName.attrName)
        return "cim";
    }

    /** Get all configured namespaces */
    public List<NamespaceConfig> getAll()     { return repo.findAll(); }
    public List<NamespaceConfig> getEnabled() { return repo.findByEnabled(true); }

    // ── CRUD ─────────────────────────────────────────────────────────────

    public NamespaceConfig create(NamespaceConfig config, String createdBy) {
        if (repo.existsByPrefix(config.getPrefix()))
            throw new IllegalArgumentException(
                    "Namespace prefix '" + config.getPrefix() + "' already exists.");
        config.setCreatedBy(createdBy);
        config.setCreatedAt(Instant.now());
        config.setUpdatedAt(Instant.now());
        NamespaceConfig saved = repo.save(config);
        cache.put(normalizePrefix(saved.getPrefix()), saved);
        log.info("Namespace added: {} enabled={} validatePath={}",
                saved.getPrefix(), saved.isEnabled(), saved.isValidatePath());
        return saved;
    }

    public NamespaceConfig update(String prefix, boolean enabled,
                                   boolean validatePath) {
        String p = normalizePrefix(prefix);
        NamespaceConfig config = repo.findByPrefix(p)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Namespace prefix '" + p + "' not found."));
        config.setEnabled(enabled);
        config.setValidatePath(validatePath);
        config.setUpdatedAt(Instant.now());
        NamespaceConfig saved = repo.save(config);
        cache.put(p, saved);
        log.info("Namespace updated: {} enabled={} validatePath={}",
                p, enabled, validatePath);
        return saved;
    }

    public void delete(String prefix) {
        String p = normalizePrefix(prefix);
        repo.findByPrefix(p).ifPresent(c -> {
            repo.delete(c);
            cache.remove(p);
            log.info("Namespace removed: {}", p);
        });
    }

    /** Reload cache from DB */
    public void refreshCache() {
        cache.clear();
        repo.findAll().forEach(c -> cache.put(normalizePrefix(c.getPrefix()), c));
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private void createDefault(String prefix, String uri,
                                String desc, boolean enabled, boolean validatePath) {
        if (!repo.existsByPrefix(prefix)) {
            repo.save(new NamespaceConfig(prefix, uri, enabled, validatePath, desc));
            log.info("Default namespace created: {} enabled={}", prefix, enabled);
        }
    }

    private String normalizePrefix(String p) {
        return p == null ? "" : p.toLowerCase().trim();
    }
}
