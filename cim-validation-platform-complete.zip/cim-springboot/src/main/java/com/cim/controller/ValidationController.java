package com.cim.controller;

import com.cim.service.QueryService;
import com.cim.service.ValidationService;
import com.cim.service.ValidationSummary;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

/**
 * REST API — File Upload & Validation
 *
 * POST /api/validate              Upload + validate (sync, for small files)
 * POST /api/validate/async        Upload + validate (async, for large files)
 * GET  /api/jobs                  Recent jobs list
 * GET  /api/jobs/{jobId}          Job status + counts
 * GET  /api/jobs/{jobId}/objects  Parsed CIM objects (common data)
 * GET  /api/jobs/{jobId}/findings Validation findings
 * GET  /api/formats               Supported file formats
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ValidationController {

    private final ValidationService validationService;
    private final QueryService      queryService;
    private final com.cim.adapter.AdapterRegistry adapterRegistry;

    public ValidationController(ValidationService validationService,
                                 QueryService queryService,
                                 com.cim.adapter.AdapterRegistry adapterRegistry) {
        this.validationService = validationService;
        this.queryService      = queryService;
        this.adapterRegistry   = adapterRegistry;
    }

    // ─────────────────────────────────────────────────────────────────────
    // POST /api/validate
    // Upload a CIM file and validate synchronously.
    //
    // curl -X POST http://localhost:8080/api/validate \
    //      -F "file=@network.xml" -H "X-User: admin"
    // ─────────────────────────────────────────────────────────────────────
    @PostMapping("/validate")
    public ResponseEntity<?> validateSync(
            @RequestParam("file") MultipartFile file,
            @RequestHeader(value = "X-User", defaultValue = "anonymous") String user) {

        if (file.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "File is empty."));
        }
        try {
            ValidationSummary summary = validationService.validateSync(file, user);
            return ResponseEntity.ok(buildSummaryResponse(summary));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", "Validation failed: " + e.getMessage()));
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // POST /api/validate/async
    // Upload a large CIM file for async processing.
    // Returns jobId immediately — poll /api/jobs/{jobId} for status.
    // ─────────────────────────────────────────────────────────────────────
    @PostMapping("/validate/async")
    public ResponseEntity<?> validateAsync(
            @RequestParam("file") MultipartFile file,
            @RequestHeader(value = "X-User", defaultValue = "anonymous") String user) {

        if (file.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "File is empty."));
        }
        try {
            String jobId = java.util.UUID.randomUUID().toString();
            validationService.validateAsync(file, user);
            return ResponseEntity.accepted()
                    .body(Map.of(
                        "jobId",   jobId,
                        "status",  "PENDING",
                        "message", "Processing started. Poll GET /api/jobs/" + jobId
                    ));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage()));
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/jobs
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/jobs")
    public ResponseEntity<?> getRecentJobs() {
        return ResponseEntity.ok(
                Map.of("jobs", queryService.getRecentJobs(10)));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}")
    public ResponseEntity<?> getJob(@PathVariable String jobId) {
        return queryService.getJob(jobId)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/objects
    // The parsed common data — all CIM objects stored in MongoDB.
    //
    // Query params:
    //   ?page=0&size=50          pagination
    //   ?type=ACLineSegment      filter by CIM type
    //   ?category=PHYSICAL       filter PHYSICAL or LOGICAL
    //   ?name=CALCME             search by name
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}/objects")
    public ResponseEntity<?> getObjects(
            @PathVariable String jobId,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String name,
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "50") int size) {

        if (type != null && !type.isBlank()) {
            return ResponseEntity.ok(Map.of(
                "jobId", jobId,
                "filter", "type=" + type,
                "objects", queryService.getObjectsByType(jobId, type)
            ));
        }
        if ("PHYSICAL".equalsIgnoreCase(category)) {
            return ResponseEntity.ok(Map.of(
                "jobId", jobId,
                "filter", "PHYSICAL",
                "objects", queryService.getPhysicalObjects(jobId)
            ));
        }
        if ("LOGICAL".equalsIgnoreCase(category)) {
            return ResponseEntity.ok(Map.of(
                "jobId", jobId,
                "filter", "LOGICAL",
                "objects", queryService.getLogicalObjects(jobId)
            ));
        }
        if (name != null && !name.isBlank()) {
            return ResponseEntity.ok(Map.of(
                "jobId", jobId,
                "filter", "name~" + name,
                "objects", queryService.searchByName(jobId, name)
            ));
        }
        // Default: paginated all objects
        Page<?> result = queryService.getObjects(jobId, page, size);
        return ResponseEntity.ok(Map.of(
            "jobId",       jobId,
            "page",        result.getNumber(),
            "totalPages",  result.getTotalPages(),
            "totalItems",  result.getTotalElements(),
            "objects",     result.getContent()
        ));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/objects/stats
    // Type breakdown summary
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}/objects/stats")
    public ResponseEntity<?> getObjectStats(@PathVariable String jobId) {
        return ResponseEntity.ok(queryService.getObjectStats(jobId));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/findings
    // Validation results.
    //
    // Query params:
    //   ?severity=ERROR           filter by ERROR/WARNING/INFO
    //   ?stage=BUSINESS_RULE      filter by pipeline stage
    //   ?objectType=ACLineSegment filter by CIM type
    //   ?page=0&size=50           pagination
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}/findings")
    public ResponseEntity<?> getFindings(
            @PathVariable String jobId,
            @RequestParam(required = false) String severity,
            @RequestParam(required = false) String stage,
            @RequestParam(required = false) String objectType,
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "50") int size) {

        if (severity != null && !severity.isBlank()) {
            return ResponseEntity.ok(Map.of(
                "jobId",    jobId,
                "filter",   "severity=" + severity.toUpperCase(),
                "findings", queryService.getFindingsBySeverity(jobId, severity)
            ));
        }
        if (stage != null && !stage.isBlank()) {
            return ResponseEntity.ok(Map.of(
                "jobId",    jobId,
                "filter",   "stage=" + stage.toUpperCase(),
                "findings", queryService.getFindingsByStage(jobId, stage)
            ));
        }
        if (objectType != null && !objectType.isBlank()) {
            return ResponseEntity.ok(Map.of(
                "jobId",    jobId,
                "filter",   "objectType=" + objectType,
                "findings", queryService.getFindingsByObjectType(jobId, objectType)
            ));
        }
        // Default: paginated all findings
        Page<?> result = queryService.getFindings(jobId, page, size);
        return ResponseEntity.ok(Map.of(
            "jobId",       jobId,
            "page",        result.getNumber(),
            "totalPages",  result.getTotalPages(),
            "totalItems",  result.getTotalElements(),
            "findings",    result.getContent()
        ));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/findings/summary
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}/findings/summary")
    public ResponseEntity<?> getFindingSummary(@PathVariable String jobId) {
        return ResponseEntity.ok(queryService.getFindingSummary(jobId));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/formats
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/formats")
    public ResponseEntity<?> getFormats() {
        return ResponseEntity.ok(Map.of(
            "supported", adapterRegistry.getSupportedFormats(),
            "details", Map.of(
                "RDF_XML",     "IEC CIM RDF/XML — standard CIM serialization (.rdf, .xml)",
                "JSON_LD",     "JSON-LD — modern CIM serialization (.json)",
                "MILSOFT_CSV", "Milsoft WindMil CSV export (.csv, .txt)"
            )
        ));
    }

    // ── Private helper ────────────────────────────────────────────────────

    private Map<String, Object> buildSummaryResponse(ValidationSummary s) {
        return Map.ofEntries(
            Map.entry("jobId",           s.getJobId()),
            Map.entry("fileName",        s.getFileName()),
            Map.entry("format",          s.getFormat()),
            Map.entry("status",          s.getStatus()),
            Map.entry("totalObjects",    s.getTotalObjects()),
            Map.entry("physicalObjects", s.getPhysicalObjects()),
            Map.entry("logicalObjects",  s.getLogicalObjects()),
            Map.entry("errors",          s.getErrorCount()),
            Map.entry("warnings",        s.getWarningCount()),
            Map.entry("info",            s.getInfoCount()),
            Map.entry("elapsedMs",       s.getElapsedMs()),
            Map.entry("links", Map.of(
                "objects",  "/api/jobs/" + s.getJobId() + "/objects",
                "findings", "/api/jobs/" + s.getJobId() + "/findings",
                "errors",   "/api/jobs/" + s.getJobId() + "/findings?severity=ERROR"
            ))
        );
    }
}
