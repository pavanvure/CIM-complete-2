package com.cim;

import com.cim.adapter.*;
import com.cim.model.cim.CIMObject;
import com.cim.model.mongo.CimClassDefinition;
import com.cim.pipeline.result.PipelineFinding;
import com.cim.pipeline.stage.ValidationPipeline;
import com.cim.validation.registry.CIMHierarchyRegistry;
import com.cim.validation.registry.PathValidationResult;
import com.cim.validation.rules.BusinessRuleEngine;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class CIMPlatformIntegrationTest {

    @Autowired MockMvc mvc;
    @Autowired CIMHierarchyRegistry registry;
    @Autowired AdapterRegistry adapterRegistry;
    @Autowired ValidationPipeline pipeline;
    @Autowired BusinessRuleEngine ruleEngine;

    // ═══════════════════════════════════════════════════════════════════
    // 1. REGISTRY TESTS
    // ═══════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("1. CIM Hierarchy Registry")
    class RegistryTests {

        @Test
        @DisplayName("Registry loads on startup")
        void registryLoaded() {
            assertTrue(registry.isLoaded(), "Registry must be loaded on startup");
            assertTrue(registry.size() > 30, "Expected 30+ classes loaded");
        }

        @ParameterizedTest(name = "Chain for {0} contains {1}")
        @CsvSource({
            "ACLineSegment,     ConductingEquipment",
            "ACLineSegment,     Equipment",
            "ACLineSegment,     IdentifiedObject",
            "Breaker,           ProtectedSwitch",
            "Breaker,           Switch",
            "Breaker,           ConductingEquipment",
            "SynchronousMachine,RotatingMachine",
            "SynchronousMachine,RegulatingCondEq",
            "SynchronousMachine,ConductingEquipment",
            "ConformLoad,       EnergyConsumer",
            "ConformLoad,       EnergyConnection",
            "ConformLoad,       ConductingEquipment",
            "LinearShuntCompensator, ShuntCompensator",
            "LinearShuntCompensator, RegulatingCondEq",
        })
        void chainContains(String cls, String ancestor) {
            var chain = registry.getFullChain(cls.trim());
            assertTrue(chain.contains(ancestor.trim()),
                    cls + " chain should contain " + ancestor + ". Got: " + chain);
        }

        @Test
        @DisplayName("Fuse does NOT extend ProtectedSwitch (per PNNL-34946 Section 8)")
        void fuseNotProtectedSwitch() {
            var chain = registry.getFullChain("Fuse");
            assertFalse(chain.contains("ProtectedSwitch"),
                    "Fuse must NOT extend ProtectedSwitch per CIM17 spec");
            assertTrue(chain.contains("Switch"),
                    "Fuse must extend Switch");
        }

        @Test
        @DisplayName("BaseVoltage chain does NOT contain ConductingEquipment")
        void baseVoltageNotConducting() {
            var chain = registry.getFullChain("BaseVoltage");
            assertFalse(chain.contains("ConductingEquipment"));
            assertTrue(chain.contains("IdentifiedObject"));
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    // 2. PATH VALIDATION TESTS
    // ═══════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("2. Attribute Path Validation")
    class PathTests {

        @ParameterizedTest(name = "[{2}] {0} + {1}")
        @CsvSource({
            // objectType,                  tag,                                  expected
            "ACLineSegment,  ConductingEquipment.BaseVoltage,    VALID",
            "ACLineSegment,  ACLineSegment.r,                    VALID",
            "ACLineSegment,  Conductor.length,                   VALID",
            "ACLineSegment,  Equipment.EquipmentContainer,       VALID",
            "ACLineSegment,  IdentifiedObject.name,              VALID",
            "Breaker,        ConductingEquipment.BaseVoltage,    VALID",
            "SynchronousMachine, ConductingEquipment.BaseVoltage, VALID",
            "ConformLoad,    Equipment.EquipmentContainer,       VALID",
            // Invalid paths
            "BaseVoltage,    ConductingEquipment.BaseVoltage,    INVALID",
            "Line,           Equipment.NAFlag,                   INVALID",
            // Vendor extensions
            "ACLineSegment,  caiso.someVendorField,              VENDOR_EXTENSION",
        })
        void pathValidation(String objectType, String tag, String expected) {
            var result = registry.validateAttributePath(
                    objectType.trim(), tag.trim());
            assertEquals(expected.trim(), result.getStatus().name(),
                    "Failed: " + objectType.trim() + " + " + tag.trim());
        }

        @Test
        @DisplayName("Valid path includes full resolved path string")
        void resolvedPathString() {
            var r = registry.validateAttributePath(
                    "ACLineSegment", "ConductingEquipment.BaseVoltage");
            assertTrue(r.isValid());
            assertTrue(r.getExplanation().contains("ConductingEquipment"),
                    "Explanation should show the path: " + r.getExplanation());
            assertTrue(r.getExplanation().contains("BaseVoltage"),
                    "Explanation should mention the field: " + r.getExplanation());
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    // 3. ADAPTER TESTS
    // ═══════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("3. Format Adapters")
    class AdapterTests {

        @Test
        @DisplayName("RDF/XML adapter detects and parses correctly")
        void rdfXmlAdapter() throws Exception {
            String xml = """
                <?xml version="1.0" encoding="UTF-8"?>
                <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
                         xmlns:cim="http://iec.ch/TC57/2010/CIM-schema-cim15#">
                  <cim:ACLineSegment rdf:ID="_test-line-001" cim:mrid="_test-line-001">
                    <cim:IdentifiedObject.name>Test Line 1</cim:IdentifiedObject.name>
                    <cim:ACLineSegment.r>0.618552</cim:ACLineSegment.r>
                    <cim:ACLineSegment.x>1.23456</cim:ACLineSegment.x>
                    <cim:ConductingEquipment.BaseVoltage rdf:resource="#_bv-001"/>
                  </cim:ACLineSegment>
                  <cim:BaseVoltage rdf:ID="_bv-001" cim:mrid="_bv-001">
                    <cim:IdentifiedObject.name>66kV</cim:IdentifiedObject.name>
                    <cim:BaseVoltage.nominalVoltage>66</cim:BaseVoltage.nominalVoltage>
                  </cim:BaseVoltage>
                </rdf:RDF>
                """;

            byte[] bytes = xml.getBytes(StandardCharsets.UTF_8);
            CIMFormatAdapter adapter = adapterRegistry.detect(bytes, "test.xml");
            assertEquals("RDF_XML", adapter.getFormatName());

            List<CIMObject> objects = adapter.parse(
                    new ByteArrayInputStream(bytes), "test.xml");
            assertEquals(2, objects.size());

            CIMObject line = objects.stream()
                    .filter(o -> "ACLineSegment".equals(o.getCimType()))
                    .findFirst().orElseThrow();

            assertEquals("_test-line-001", line.getMrid());
            assertEquals("Test Line 1", line.getName());
            assertEquals("0.618552", line.getAttribute("ACLineSegment.r"));
            assertTrue(line.hasReference("ConductingEquipment.BaseVoltage"));
            assertTrue(line.hasResolved("ConductingEquipment.BaseVoltage"),
                    "BaseVoltage reference should be resolved within the file");
        }

        @Test
        @DisplayName("JSON-LD adapter detects and parses correctly")
        void jsonLdAdapter() throws Exception {
            String json = """
                [
                  { "@type": "cim:ACLineSegment", "@id": "_json-line-001",
                    "cim:IdentifiedObject.name": "JSON Line",
                    "cim:ACLineSegment.r": "0.5",
                    "cim:ConductingEquipment.BaseVoltage": { "@id": "_json-bv-001" } },
                  { "@type": "cim:BaseVoltage", "@id": "_json-bv-001",
                    "cim:IdentifiedObject.name": "138kV",
                    "cim:BaseVoltage.nominalVoltage": "138" }
                ]
                """;

            byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
            CIMFormatAdapter adapter = adapterRegistry.detect(bytes, "network.json");
            assertEquals("JSON_LD", adapter.getFormatName());

            List<CIMObject> objects = adapter.parse(
                    new ByteArrayInputStream(bytes), "network.json");
            assertEquals(2, objects.size());

            CIMObject line = objects.stream()
                    .filter(o -> "ACLineSegment".equals(o.getCimType()))
                    .findFirst().orElseThrow();

            assertEquals("JSON Line", line.getName());
            assertEquals("JSON_LD", line.getSourceFormat());
            assertTrue(line.hasResolved("ConductingEquipment.BaseVoltage"));
        }

        @Test
        @DisplayName("Milsoft CSV adapter detects and parses correctly")
        void milsoftCsvAdapter() throws Exception {
            String csv = """
                rdfId,cimType,attributeKey,attributeValue,isReference,targetRdfId
                _csv-line-001,ACLineSegment,IdentifiedObject.name,CSV Line 1,false,
                _csv-line-001,ACLineSegment,ACLineSegment.r,1.25,false,
                _csv-line-001,ACLineSegment,Conductor.length,2.5,false,
                _csv-line-001,ACLineSegment,ConductingEquipment.BaseVoltage,,true,_csv-bv-001
                _csv-bv-001,BaseVoltage,IdentifiedObject.name,12.47kV,false,
                _csv-bv-001,BaseVoltage,BaseVoltage.nominalVoltage,12.47,false,
                """;

            byte[] bytes = csv.getBytes(StandardCharsets.UTF_8);
            CIMFormatAdapter adapter = adapterRegistry.detect(bytes, "network.csv");
            assertEquals("MILSOFT_CSV", adapter.getFormatName());

            List<CIMObject> objects = adapter.parse(
                    new ByteArrayInputStream(bytes), "network.csv");

            CIMObject line = objects.stream()
                    .filter(o -> "ACLineSegment".equals(o.getCimType()))
                    .findFirst().orElseThrow();

            assertEquals("CSV Line 1", line.getName());
            assertEquals("1.25", line.getAttribute("ACLineSegment.r"));
            assertTrue(line.hasResolved("ConductingEquipment.BaseVoltage"));
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    // 4. PIPELINE TESTS
    // ═══════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("4. Validation Pipeline")
    class PipelineTests {

        @Test
        @DisplayName("Valid ACLineSegment produces zero errors")
        void validLineNoErrors() {
            CIMObject bv = makeBaseVoltage("bv-1", "66");
            CIMObject line = makeACLineSegment("line-1", bv, true);
            CIMObject container = makeLine("line-container-1");
            line.addReference("Equipment.EquipmentContainer", container.getRdfId());
            line.addResolved("Equipment.EquipmentContainer", container);

            var findings = pipeline.run(List.of(line, bv, container), "test-job");
            long errors = findings.stream().filter(PipelineFinding::isError).count();
            assertEquals(0, errors,
                    "Valid objects should have zero errors. Got: " +
                    findings.stream().filter(PipelineFinding::isError)
                            .map(PipelineFinding::getMessage).toList());
        }

        @Test
        @DisplayName("Missing BaseVoltage on ACLineSegment → ERROR")
        void missingBaseVoltage() {
            CIMObject line = new CIMObject("ACLineSegment", "_bad-line");
            line.setMrid("_bad-line");
            line.setAttribute("IdentifiedObject.name", "Bad Line");
            line.setAttribute("ACLineSegment.r", "0.5");

            var findings = pipeline.run(List.of(line), "test-job-bad");
            assertTrue(findings.stream().anyMatch(f ->
                    f.isError() && f.getAttributeTag()
                            .contains("BaseVoltage")),
                    "Missing BaseVoltage must produce an ERROR");
        }

        @Test
        @DisplayName("Terminal (logical) skips business rules")
        void terminalSkipped() {
            CIMObject terminal = new CIMObject("Terminal", "_t-001");
            terminal.setMrid("_t-001");
            terminal.setAttribute("IdentifiedObject.name", "T1");

            var findings = pipeline.run(List.of(terminal), "test-job-terminal");
            // Logical objects should have NO business rule errors
            long businessErrors = findings.stream()
                    .filter(f -> f.isError()
                            && "BUSINESS_RULE".equals(f.getStage()))
                    .count();
            assertEquals(0, businessErrors,
                    "Terminal is logical — no business rule errors expected");
        }

        @Test
        @DisplayName("Duplicate mRID detected across objects")
        void duplicateMrid() {
            CIMObject obj1 = makeBaseVoltage("bv-dup", "66");
            CIMObject obj2 = makeBaseVoltage("bv-dup", "110");
            obj2.setRdfId("_different-rdf-id");

            var findings = pipeline.run(List.of(obj1, obj2), "dup-job");
            assertTrue(findings.stream().anyMatch(f ->
                    f.isError() && f.getMessage().contains("Duplicate mRID")));
        }

        @Test
        @DisplayName("Invalid path tag produces PATH_VALIDATION error")
        void invalidPathError() {
            CIMObject line = makeBaseVoltage("bv-2", "66");
            // Manually inject an invalid path tag
            line.setAttribute("ConductingEquipment.BaseVoltage", "some-val");
            // BaseVoltage doesn't extend ConductingEquipment → INVALID path

            var findings = pipeline.run(List.of(line), "path-test-job");
            assertTrue(findings.stream().anyMatch(f ->
                    f.isError() && "PATH_VALIDATION".equals(f.getStage())),
                    "Invalid path on BaseVoltage should produce PATH_VALIDATION error");
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    // 5. REST API TESTS
    // ═══════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("5. REST API")
    class ApiTests {

        @Test
        @DisplayName("GET /api/formats returns supported formats")
        void formatsEndpoint() throws Exception {
            mvc.perform(get("/api/formats"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.supported").isArray());
        }

        @Test
        @DisplayName("GET /api/admin/cim/stats returns registry stats")
        void adminStats() throws Exception {
            mvc.perform(get("/api/admin/cim/stats"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.registryLoaded").value(true))
               .andExpect(jsonPath("$.totalClasses").isNumber());
        }

        @Test
        @DisplayName("GET /api/admin/cim/chain/ACLineSegment returns chain")
        void chainEndpoint() throws Exception {
            mvc.perform(get("/api/admin/cim/chain/ACLineSegment"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.inheritanceChain").isArray())
               .andExpect(jsonPath("$.inheritanceChain[0]").value("ACLineSegment"));
        }

        @Test
        @DisplayName("POST /api/admin/cim/validate-path returns VALID for correct path")
        void validatePathEndpointValid() throws Exception {
            mvc.perform(post("/api/admin/cim/validate-path")
                .contentType("application/json")
                .content("""
                    {"objectType":"ACLineSegment",
                     "attributeTag":"ConductingEquipment.BaseVoltage"}
                    """))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.valid").value(true))
               .andExpect(jsonPath("$.status").value("VALID"));
        }

        @Test
        @DisplayName("POST /api/admin/cim/validate-path returns INVALID for wrong path")
        void validatePathEndpointInvalid() throws Exception {
            mvc.perform(post("/api/admin/cim/validate-path")
                .contentType("application/json")
                .content("""
                    {"objectType":"BaseVoltage",
                     "attributeTag":"ConductingEquipment.BaseVoltage"}
                    """))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.valid").value(false))
               .andExpect(jsonPath("$.status").value("INVALID"));
        }

        @Test
        @DisplayName("POST /api/validate with RDF/XML file processes end-to-end")
        void fullValidationFlow() throws Exception {
            String xml = """
                <?xml version="1.0" encoding="UTF-8"?>
                <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
                         xmlns:cim="http://iec.ch/TC57/2010/CIM-schema-cim15#">
                  <cim:ACLineSegment rdf:ID="_e2e-line-001" cim:mrid="_e2e-line-001">
                    <cim:IdentifiedObject.name>E2E Test Line</cim:IdentifiedObject.name>
                    <cim:ACLineSegment.r>0.618552</cim:ACLineSegment.r>
                    <cim:ACLineSegment.x>1.2345</cim:ACLineSegment.x>
                    <cim:Conductor.length>5.2</cim:Conductor.length>
                    <cim:ConductingEquipment.BaseVoltage rdf:resource="#_e2e-bv-001"/>
                    <cim:Equipment.EquipmentContainer rdf:resource="#_e2e-line-container"/>
                  </cim:ACLineSegment>
                  <cim:BaseVoltage rdf:ID="_e2e-bv-001" cim:mrid="_e2e-bv-001">
                    <cim:IdentifiedObject.name>66kV</cim:IdentifiedObject.name>
                    <cim:BaseVoltage.nominalVoltage>66</cim:BaseVoltage.nominalVoltage>
                  </cim:BaseVoltage>
                  <cim:Line rdf:ID="_e2e-line-container" cim:mrid="_e2e-line-container">
                    <cim:IdentifiedObject.name>E2E Test Feeder</cim:IdentifiedObject.name>
                  </cim:Line>
                </rdf:RDF>
                """;

            MockMultipartFile file = new MockMultipartFile(
                    "file", "e2e_test.xml",
                    "application/xml", xml.getBytes(StandardCharsets.UTF_8));

            mvc.perform(multipart("/api/validate").file(file)
                    .header("X-User", "test-user"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.jobId").exists())
               .andExpect(jsonPath("$.format").value("RDF_XML"))
               .andExpect(jsonPath("$.totalObjects").value(3))
               .andExpect(jsonPath("$.status").value("PASSED"))
               .andExpect(jsonPath("$.links.objects").exists())
               .andExpect(jsonPath("$.links.findings").exists());
        }

        @Test
        @DisplayName("POST /api/validate with empty file returns 400")
        void emptyFileReturns400() throws Exception {
            MockMultipartFile empty = new MockMultipartFile(
                    "file", "empty.xml",
                    "application/xml", new byte[0]);
            mvc.perform(multipart("/api/validate").file(empty))
               .andExpect(status().isBadRequest());
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    // HELPERS
    // ═══════════════════════════════════════════════════════════════════

    private CIMObject makeBaseVoltage(String id, String nomV) {
        CIMObject bv = new CIMObject("BaseVoltage", "_" + id);
        bv.setMrid("_" + id);
        bv.setAttribute("IdentifiedObject.name", "BV-" + id);
        if (nomV != null) bv.setAttribute("BaseVoltage.nominalVoltage", nomV);
        return bv;
    }

    private CIMObject makeACLineSegment(String id, CIMObject bv, boolean withBv) {
        CIMObject line = new CIMObject("ACLineSegment", "_" + id);
        line.setMrid("_" + id);
        line.setAttribute("IdentifiedObject.name", "Line-" + id);
        line.setAttribute("ACLineSegment.r", "0.5");
        line.setAttribute("ACLineSegment.x", "1.2");
        line.setAttribute("Conductor.length", "3.5");
        if (withBv && bv != null) {
            line.addReference("ConductingEquipment.BaseVoltage", bv.getRdfId());
            line.addResolved("ConductingEquipment.BaseVoltage", bv);
        }
        return line;
    }

    private CIMObject makeLine(String id) {
        CIMObject line = new CIMObject("Line", "_" + id);
        line.setMrid("_" + id);
        line.setAttribute("IdentifiedObject.name", "Container-" + id);
        return line;
    }
}
