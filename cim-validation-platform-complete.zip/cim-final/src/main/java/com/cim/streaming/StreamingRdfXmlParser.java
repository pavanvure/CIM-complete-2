package com.cim.streaming;

import com.cim.model.cim.CIMObject;
import org.springframework.stereotype.Component;

import javax.xml.stream.*;
import java.io.*;
import java.util.function.Consumer;

/** StAX cursor parser — O(1) memory, Java 11 compatible. */
@Component
public class StreamingRdfXmlParser {

    private static final String NS_RDF = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";

    public long stream(InputStream in, String fileName,
                       Consumer<CIMObject> onObject) throws Exception {
        XMLInputFactory fac = XMLInputFactory.newInstance();
        fac.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
        fac.setProperty(XMLInputFactory.SUPPORT_DTD, false);
        fac.setProperty(XMLInputFactory.IS_COALESCING, true);
        XMLStreamReader r = fac.createXMLStreamReader(
                new BufferedInputStream(in, 65536));

        long count=0; int depth=0;
        CIMObject current=null;
        String attrKey=null; boolean inAttr=false;
        StringBuilder buf = new StringBuilder(256);

        try {
            while (r.hasNext()) {
                int ev = r.next();
                switch (ev) {
                    case XMLStreamConstants.START_ELEMENT -> {
                        depth++; buf.setLength(0);
                        if (depth == 2) {
                            current = openObject(r, fileName);
                        } else if (depth == 3 && current != null) {
                            attrKey = r.getLocalName(); inAttr = true;
                            String ref = r.getAttributeValue(NS_RDF, "resource");
                            if (ref != null && !ref.isBlank()) {
                                current.addReference(attrKey, cleanRef(ref));
                                inAttr = false;
                            }
                        }
                    }
                    case XMLStreamConstants.CHARACTERS, XMLStreamConstants.CDATA -> {
                        if (inAttr && current != null) buf.append(r.getText());
                    }
                    case XMLStreamConstants.END_ELEMENT -> {
                        if (depth == 3 && inAttr && current != null) {
                            String v = buf.toString().trim();
                            if (!v.isEmpty()) current.setAttribute(attrKey, v);
                            inAttr = false; attrKey = null; buf.setLength(0);
                        }
                        if (depth == 2 && current != null) {
                            onObject.accept(current); count++; current = null;
                        }
                        depth--;
                    }
                }
            }
        } finally { r.close(); }
        return count;
    }

    private CIMObject openObject(XMLStreamReader r, String fileName) {
        String local = r.getLocalName();
        if (local == null || local.isBlank()) return null;
        String id = r.getAttributeValue(NS_RDF, "ID");
        if (id == null) id = r.getAttributeValue(NS_RDF, "about");
        if (id == null || id.isBlank()) return null;
        CIMObject o = new CIMObject(local.intern(), cleanRef(id));
        o.setSourceFormat("RDF_XML"); o.setSourceFile(fileName);
        return o;
    }

    private String cleanRef(String v) {
        if (v == null) return null;
        v = v.trim();
        return v.startsWith("#") ? v.substring(1) : v;
    }
}
