package com.cim.config;

import com.cim.util.MapKeySanitizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.core.convert.*;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;

@Configuration
public class MongoConfig {

    @Bean
    public MappingMongoConverter mappingMongoConverter(
            MongoDatabaseFactory factory, MongoMappingContext context) {
        DbRefResolver dbRefResolver = new DefaultDbRefResolver(factory);
        MappingMongoConverter converter =
                new MappingMongoConverter(dbRefResolver, context);
        converter.setMapKeyDotReplacement(MapKeySanitizer.DOT_REPLACEMENT);
        converter.setTypeMapper(new DefaultMongoTypeMapper(null));
        return converter;
    }
}
