package com.cim.service;

import com.cim.model.cim.CIMObject;
import com.cim.model.mongo.CimObjectRecord;
import com.cim.model.mongo.ValidationJob;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.repository.ValidationJobRepository;
import com.cim.streaming.ProgressTracker;
import com.cim.streaming.StreamingRdfXmlParser;
import com.cim.streaming.StreamingReferenceResolver;
import com.cim.util.MapKeySanitizer;
import com.cim.validation.registry.CIMHierarchyRegistry;
import com.cim.validation.registry.PathValidationResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

/**
 * Core import pipeline: parse → path-validate → save → resolve-references
 *
 * CATEGORY / isRequired:
 *   Resolved from CIMHierarchyRegistry (loaded from OWL) only.
 *   No hardcoded class lists anywhere in this class.
 *
 * PATH VALIDATION:
 *   Every attribute tag "DeclaringClass.attrName" is validated against
 *   the OWL inheritance chain for each object's cimType.
 *   INVALID path issues are stored inline on the CimObjectRecord.pathIssues.
 *   Unknown types → skip (VENDOR_EXTENSION or missing from CPSM profile).
 *   This runs during save — no separate pass needed.
 */
@Service
public class ImportService {

    private static final Logger log = LoggerFactory.getLogger(ImportService.class);

    @Value("${cim.streaming.chunk-size:500}")  private int chunkSize;
    @Value("${cim.streaming.log-every:10000}") private int logEvery;
    @Value("${cim.upload.temp-dir:/tmp/cim-uploads}") private String tempDir;

    private final StreamingRdfXmlParser      rdfParser;
    private final StreamingReferenceResolver refResolver;
    private final CimObjectRecordRepository  objectRepo;
    private final ValidationJobRepository    jobRepo;
    private final CIMHierarchyRegistry       registry;

    private final Map<String, ProgressTracker> trackers = new ConcurrentHashMap<>();

    public ImportService(StreamingRdfXmlParser rdfParser,
                          StreamingReferenceResolver refResolver,
                          CimObjectRecordRepository objectRepo,
                          ValidationJobRepository jobRepo,
                          CIMHierarchyRegistry registry) {
        this.rdfParser  = rdfParser;
        this.refResolver = refResolver;
        this.objectRepo  = objectRepo;
        this.jobRepo     = jobRepo;
        this.registry    = registry;
    }

    // ── Synchronous (≤50MB) ───────────────────────────────────────────────

    public void processAndResolve(InputStream in, String fileName,
                                   String format, String jobId,
                                   String version) throws Exception {
        ProgressTracker p = new ProgressTracker(jobId, logEvery);
        trackers.put(jobId, p);
        run(in, fileName, format, jobId, version, p);
    }

    // ── Async (>50MB) ─────────────────────────────────────────────────────

    @Async
    public CompletableFuture<Void> processAndResolveAsync(InputStream in,
            String fileName, String format, String jobId, String version) {
        ProgressTracker p = new ProgressTracker(jobId, logEvery);
        trackers.put(jobId, p);
        try { run(in, fileName, format, jobId, version, p); }
        catch (Exception e) { log.error("Async import failed: {}", e.getMessage()); }
        return CompletableFuture.completedFuture(null);
    }

    // ── Core pipeline ─────────────────────────────────────────────────────

    private void run(InputStream in, String fileName, String format,
                      String jobId, String version,
                      ProgressTracker progress) throws Exception {
        ValidationJob job = jobRepo.findByJobId(jobId).orElseThrow();
        job.setStatus("RUNNING");
        job.setNetworkVersion(version);
        jobRepo.save(job);

        try {
            // Step 1: Stream parse + path-validate + save
            progress.setStage(ProgressTracker.Stage.STREAMING_PARSE,
                    "Parsing " + format + "...");
            Path tmp = saveToDisk(in, jobId, fileName);
            try {
                streamValidateAndSave(tmp, fileName, format, jobId, version, progress);
            } finally {
                deleteTempFile(tmp);
            }

            // Step 2: Resolve cross-references (server-side $lookup)
            progress.setStage(ProgressTracker.Stage.RESOLVING_REFERENCES,
                    "Resolving cross-references...");
            long resolved = refResolver.resolveReferencesInMongo(jobId, chunkSize, progress);
            progress.log("References resolved: " + resolved);

            // Done
            job = jobRepo.findByJobId(jobId).orElse(job);
            job.setStatus("RESOLVED");
            job.setTotalObjects((int) progress.getParsed());
            job.setPhysicalObjects((int) countCategory(jobId, "PHYSICAL"));
            job.setLogicalObjects((int)  countCategory(jobId, "LOGICAL"));
            job.setCompletedAt(Instant.now());
            job.setProcessingMs(System.currentTimeMillis() - job.getSubmittedAt().toEpochMilli());
            jobRepo.save(job);
            progress.done();

            log.info("Import done: job={} version={} objects={} resolved={}",
                    jobId, version, progress.getParsed(), resolved);

        } catch (Exception e) {
            log.error("Import failed job={}: {}", jobId, e.getMessage());
            job = jobRepo.findByJobId(jobId).orElse(job);
            job.setStatus("FAILED"); job.setErrorMessage(e.getMessage());
            job.setCompletedAt(Instant.now());
            jobRepo.save(job);
            progress.fail(e.getMessage());
            throw e;
        }
    }

    // ── Stream, path-validate per object, save in batches ─────────────────

    private void streamValidateAndSave(Path tmp, String fileName,
                                        String format, String jobId,
                                        String version,
                                        ProgressTracker progress) throws Exception {
        List<CimObjectRecord> batch = new ArrayList<>(chunkSize);

        try (InputStream fis = Files.newInputStream(tmp)) {
            rdfParser.stream(fis, fileName, obj -> {
                CimObjectRecord rec = toRecord(obj, jobId, version);
                batch.add(rec);
                progress.incrementParsed();

                if (batch.size() >= chunkSize) {
                    objectRepo.saveAll(new ArrayList<>(batch));
                    progress.incrementSaved(batch.size());
                    batch.clear();
                }
            });
        }

        if (!batch.isEmpty()) {
            objectRepo.saveAll(batch);
            progress.incrementSaved(batch.size());
        }
        progress.log("Stream+validate complete: " + progress.getParsed() + " objects saved");
    }

    // ── Build CimObjectRecord — OWL-driven category and isRequired ─────────

    CimObjectRecord toRecord(CIMObject obj, String jobId, String version) {
        CimObjectRecord r = new CimObjectRecord();
        r.setJobId(jobId);
        r.setRdfId(obj.getRdfId());
        r.setMrid(obj.getMrid());
        r.setCimType(obj.getCimType());
        r.setName(obj.getName());

        // ── Category from OWL registry ONLY — no hardcoding ──────────────
        String category = registry.getCategory(obj.getCimType());
        if ("UNKNOWN".equals(category)) {
            // Type not in registry — vendor extension or missing profile
            // Default to PHYSICAL so it appears in queries; can be changed later
            category = "PHYSICAL";
        }
        r.setCategory(category);

        // ── isRequired default from OWL registry ─────────────────────────
        // PHYSICAL classes → true (required field equipment)
        // LOGICAL classes  → false (optional topology construct)
        r.setRequired(registry.getDefaultRequired(obj.getCimType()));

        r.setSourceFormat(obj.getSourceFormat());
        r.setSourceFile(obj.getSourceFile());
        r.setOrgId(obj.getOrgId());
        r.setVersion(version);
        r.setAttributes(MapKeySanitizer.encodeKeys(obj.getAttributes()));
        r.setReferences(MapKeySanitizer.encodeKeys(obj.getReferences()));
        r.setCreatedAt(Instant.now());

        // ── Path validation — inline per object ───────────────────────────
        // Only run path validation if type is registered in OWL
        if (registry.isKnownClass(obj.getCimType())) {
            List<Map<String,String>> issues = new ArrayList<>();
            for (String tag : obj.getAttributes().keySet()) {
                PathValidationResult res =
                        registry.validateAttributePath(obj.getCimType(), tag);
                // Only store INVALID findings — valid and vendor paths are noise
                if (res.isInvalid()) {
                    issues.add(Map.of(
                        "tag",         tag,
                        "status",      res.getStatus().name(),
                        "explanation", res.getExplanation()
                    ));
                }
            }
            if (!issues.isEmpty()) r.setPathIssues(issues);
        }
        // If type is UNKNOWN — skip path validation entirely (no false positives)

        return r;
    }

    // ── Progress ──────────────────────────────────────────────────────────

    public Optional<ProgressTracker> getTracker(String jobId) {
        return Optional.ofNullable(trackers.get(jobId));
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private long countCategory(String jobId, String cat) {
        return objectRepo.countByJobIdAndCategory(jobId, cat);
    }

    private Path saveToDisk(InputStream in, String jobId,
                             String fileName) throws IOException {
        Path dir = Paths.get(tempDir);
        Files.createDirectories(dir);
        Path file = dir.resolve(jobId + "_" + fileName);
        Files.copy(in, file, StandardCopyOption.REPLACE_EXISTING);
        return file;
    }

    private void deleteTempFile(Path p) {
        try { Files.deleteIfExists(p); } catch (IOException ignored) {}
    }

    public static String sha256(byte[] data) throws Exception {
        byte[] h = MessageDigest.getInstance("SHA-256").digest(data);
        StringBuilder sb = new StringBuilder();
        for (byte b : h) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
